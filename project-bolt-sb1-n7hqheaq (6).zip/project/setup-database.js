#!/usr/bin/env node

import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

// Load environment variables
dotenv.config();

console.log('🗄️  Sprawdzanie i konfiguracja bazy danych Supabase...');

const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY;

if (!supabaseUrl || !supabaseServiceKey) {
  console.warn('⚠️  Supabase nie jest skonfigurowany - aplikacja będzie działać bez zapisywania danych');
  console.warn('📝 Aby skonfigurować Supabase, dodaj VITE_SUPABASE_URL i SUPABASE_SERVICE_ROLE_KEY do .env-persistent');
  process.exit(0);
}

console.log('📡 Łączenie z Supabase...');
console.log('🔗 URL:', supabaseUrl);

const supabase = createClient(supabaseUrl, supabaseServiceKey);

async function setupDatabase() {
  try {
    console.log('🔍 Sprawdzanie czy tabele istnieją...');
    
    // Sprawdź czy tabela user_profiles istnieje
    const { data: userProfilesData, error: userProfilesError } = await supabase
      .from('user_profiles')
      .select('count')
      .limit(1);
    
    if (userProfilesError && userProfilesError.code === '42P01') {
      console.log('📋 Tabela user_profiles nie istnieje - tworzenie...');
      
      const { error: createError } = await supabase.rpc('exec_sql', {
        sql: `
          -- Tabela profili użytkowników
          CREATE TABLE IF NOT EXISTS user_profiles (
            id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
            user_id text UNIQUE NOT NULL,
            profile_data jsonb DEFAULT '{}'::jsonb,
            created_at timestamptz DEFAULT now(),
            updated_at timestamptz DEFAULT now()
          );

          -- Indeksy dla wydajności
          CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);

          -- Row Level Security
          ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;

          -- Polityki RLS (pozwalają na wszystko - dla uproszczenia)
          DROP POLICY IF EXISTS "Allow all operations on user_profiles" ON user_profiles;
          CREATE POLICY "Allow all operations on user_profiles" ON user_profiles FOR ALL USING (true);
        `
      });
      
      if (createError) {
        console.error('❌ Błąd tworzenia tabeli user_profiles:', createError);
      } else {
        console.log('✅ Tabela user_profiles utworzona pomyślnie');
      }
    } else if (userProfilesError) {
      console.error('❌ Błąd sprawdzania tabeli user_profiles:', userProfilesError);
    } else {
      console.log('✅ Tabela user_profiles już istnieje');
    }

    // Sprawdź czy tabela conversations istnieje
    const { data: conversationsData, error: conversationsError } = await supabase
      .from('conversations')
      .select('count')
      .limit(1);
    
    if (conversationsError && conversationsError.code === '42P01') {
      console.log('📋 Tabela conversations nie istnieje - tworzenie...');
      
      const { error: createError } = await supabase.rpc('exec_sql', {
        sql: `
          -- Tabela rozmów
          CREATE TABLE IF NOT EXISTS conversations (
            id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
            user_id text NOT NULL,
            message_id text NOT NULL,
            role text NOT NULL CHECK (role IN ('user', 'assistant')),
            content text NOT NULL,
            metadata jsonb DEFAULT '{}'::jsonb,
            created_at timestamptz DEFAULT now()
          );

          -- Indeksy dla wydajności
          CREATE INDEX IF NOT EXISTS idx_conversations_user_id ON conversations(user_id);
          CREATE INDEX IF NOT EXISTS idx_conversations_created_at ON conversations(created_at DESC);

          -- Row Level Security
          ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;

          -- Polityki RLS (pozwalają na wszystko - dla uproszczenia)
          DROP POLICY IF EXISTS "Allow all operations on conversations" ON conversations;
          CREATE POLICY "Allow all operations on conversations" ON conversations FOR ALL USING (true);
        `
      });
      
      if (createError) {
        console.error('❌ Błąd tworzenia tabeli conversations:', createError);
      } else {
        console.log('✅ Tabela conversations utworzona pomyślnie');
      }
    } else if (conversationsError) {
      console.error('❌ Błąd sprawdzania tabeli conversations:', conversationsError);
    } else {
      console.log('✅ Tabela conversations już istnieje');
    }

    // Test końcowy
    console.log('🧪 Testowanie połączenia z bazą danych...');
    
    const { data: testData, error: testError } = await supabase
      .from('user_profiles')
      .select('count')
      .limit(1);
    
    if (testError) {
      console.error('❌ Test połączenia nieudany:', testError);
    } else {
      console.log('✅ Baza danych skonfigurowana i działa poprawnie!');
    }

  } catch (error) {
    console.error('❌ Błąd konfiguracji bazy danych:', error);
    
    if (error.message.includes('exec_sql')) {
      console.log('📝 INSTRUKCJE RĘCZNEJ KONFIGURACJI:');
      console.log('1. Przejdź do Supabase Dashboard: https://supabase.com/dashboard');
      console.log('2. Otwórz SQL Editor');
      console.log('3. Wykonaj SQL z pliku ROZWIAZYWANIE-PROBLEMOW.md sekcja "3. Utwórz tabele w bazie danych"');
    }
  }
}

await setupDatabase();