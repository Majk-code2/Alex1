# 🚀 Instrukcja uruchomienia ALEX Agent

## Wymagania wstępne

1. **Node.js** (wersja 16 lub nowsza)
2. **Klucz API Anthropic** - uzyskaj na https://console.anthropic.com/
3. **Projekt Supabase** - utwórz na https://supabase.com/

## Krok po kroku

### 1. Konfiguracja zmiennych środowiskowych

```bash
# Skopiuj plik przykładowy
cp .env.example .env
```

### 2. Edytuj plik .env

Otwórz plik `.env` i uzupełnij wszystkie wartości:

```env
# Zastąp swoim kluczem API z Anthropic
ANTHROPIC_API_KEY=sk-ant-api-03-TWOJ-PRAWDZIWY-KLUCZ

# Zastąp danymi z Twojego projektu Supabase
SUPABASE_URL=https://twoj-projekt.supabase.co
SUPABASE_SERVICE_ROLE_KEY=twoj-service-role-key

# Opcjonalne - Google Calendar (jeśli chcesz używać kalendarza)
VITE_GOOGLE_CLIENT_ID=twoj-google-client-id
VITE_GOOGLE_CLIENT_SECRET=twoj-google-client-secret
```

### 3. Instalacja zależności

```bash
npm install
```

### 4. Uruchomienie aplikacji

**Opcja A: Automatyczne uruchomienie (zalecane)**
```bash
npm run dev:full
```

**Opcja B: Ręczne uruchomienie**
```bash
# Terminal 1 - Backend
npm run server

# Terminal 2 - Frontend  
npm run dev
```

## Rozwiązywanie problemów

### ❌ Error: connect ECONNREFUSED 127.0.0.1:3002

**Przyczyna:** Backend nie jest uruchomiony lub nie może się uruchomić

**Rozwiązanie:**
1. Sprawdź czy plik `.env` istnieje i zawiera poprawne klucze API
2. Uruchom backend osobno: `npm run server`
3. Sprawdź logi w terminalu

### ❌ API Health Check Failed: HTTP error! status: 500

**Przyczyna:** Niepoprawny klucz API Anthropic

**Rozwiązanie:**
1. Sprawdź czy `ANTHROPIC_API_KEY` w `.env` jest poprawny
2. Klucz powinien zaczynać się od `sk-ant-api-`
3. Nie może zawierać tekstu "your-key-here"

### ❌ Błąd połączenia z Supabase

**Przyczyna:** Niepoprawne dane Supabase

**Rozwiązanie:**
1. Sprawdź `SUPABASE_URL` i `SUPABASE_SERVICE_ROLE_KEY`
2. Upewnij się, że projekt Supabase jest aktywny
3. Sprawdź czy tabele zostały utworzone (patrz schema w kodzie)

## Testowanie

### Test backendu
```bash
curl http://localhost:3002/api/health
```

### Test frontendu
Otwórz http://localhost:5173 w przeglądarce

## Porty

- **Frontend:** http://localhost:5173
- **Backend:** http://localhost:3002

## Wsparcie

Jeśli nadal masz problemy:
1. Sprawdź logi w terminalu
2. Upewnij się, że wszystkie zmienne środowiskowe są poprawnie skonfigurowane
3. Sprawdź czy porty 3002 i 5173 nie są zajęte przez inne aplikacje