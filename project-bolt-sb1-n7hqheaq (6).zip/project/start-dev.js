#!/usr/bin/env node

import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import net from 'net';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

console.log('🚀 Uruchamianie środowiska deweloperskiego...\n');

// Funkcja sprawdzająca czy port jest wolny
function checkPort(port) {
  return new Promise((resolve) => {
    const server = net.createServer();
    server.listen(port, (err) => {
      if (err) {
        resolve(false); // Port zajęty
      } else {
        server.close();
        resolve(true); // Port wolny
      }
    });
  });
}

// Funkcja zabijająca proces na porcie
function killPort(port) {
  return new Promise((resolve) => {
    const killProcess = spawn('npx', ['kill-port', port], {
      stdio: 'pipe',
      shell: true
    });
    
    killProcess.on('close', (code) => {
      if (code === 0) {
        console.log(`✅ Port ${port} cleared successfully`);
        resolve();
      } else {
        console.log(`⚠️  kill-port failed for ${port}, trying fallback...`);
        // Fallback method
        const fallbackKill = process.platform === 'win32' 
          ? spawn('cmd', ['/c', `for /f "tokens=5" %a in ('netstat -aon ^| find ":${port}"') do taskkill /f /pid %a`], { stdio: 'pipe', shell: true })
          : spawn('sh', ['-c', `lsof -ti:${port} | xargs kill -9 2>/dev/null || true`], { stdio: 'pipe', shell: true });
        
        fallbackKill.on('close', () => {
          console.log(`✅ Fallback port clear attempted for ${port}`);
          resolve();
        });
        fallbackKill.on('error', () => resolve());
      }
    });
    
    killProcess.on('error', (err) => {
      console.log(`⚠️  npx kill-port error: ${err.message}, trying fallback...`);
      // Fallback method
      const fallbackKill = process.platform === 'win32' 
        ? spawn('cmd', ['/c', `for /f "tokens=5" %a in ('netstat -aon ^| find ":${port}"') do taskkill /f /pid %a`], { stdio: 'pipe', shell: true })
        : spawn('sh', ['-c', `lsof -ti:${port} | xargs kill -9 2>/dev/null || true`], { stdio: 'pipe', shell: true });
      
      fallbackKill.on('close', () => {
        console.log(`✅ Fallback port clear attempted for ${port}`);
        resolve();
      });
      fallbackKill.on('error', () => resolve());
    });
  });
}

// Sprawdź czy plik .env istnieje
const envPath = path.join(__dirname, '.env');
if (!fs.existsSync(envPath)) {
  console.error('❌ BŁĄD: Plik .env nie istnieje!');
  console.error('\n📝 INSTRUKCJE:');
  console.error('1. Skopiuj plik .env.example do .env:');
  console.error('   cp .env.example .env');
  console.error('2. Edytuj plik .env i uzupełnij wszystkie klucze API');
  console.error('3. Uruchom ponownie: npm run dev:full');
  process.exit(1);
}

// Sprawdź zawartość pliku .env
const envContent = fs.readFileSync(envPath, 'utf8');
const hasPlaceholders = envContent.includes('your-') || envContent.includes('sk-ant-api-your-key-here');

if (hasPlaceholders) {
  console.error('❌ BŁĄD: Plik .env zawiera wartości placeholder!');
  console.error('\n📝 INSTRUKCJE:');
  console.error('1. Edytuj plik .env');
  console.error('2. Zamień wszystkie wartości "your-..." na rzeczywiste klucze API');
  console.error('3. Uruchom ponownie: npm run dev:full');
  process.exit(1);
}

console.log('✅ Plik .env wygląda poprawnie');

// Główna funkcja uruchamiająca
async function startServers() {
  // Sprawdź i wyczyść porty
  console.log('🔍 Sprawdzanie portów...');
  
  const port3002Free = await checkPort(3002);
  const port5173Free = await checkPort(5173);
  
  if (!port3002Free) {
    console.log('🔄 Port 3002 zajęty, próbuję zwolnić...');
    await killPort(3002);
  }
  
  if (!port5173Free) {
    console.log('🔄 Port 5173 zajęty, próbuję zwolnić...');
    await killPort(5173);
  }
  
  // Poczekaj chwilę
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  // Uruchom backend
  console.log('🔧 Uruchamianie serwera backend...');
  const backend = spawn('node', ['server.js'], {
    stdio: 'inherit',
    env: process.env,
    shell: true
  });

  backend.on('error', (err) => {
    console.error('❌ Błąd uruchamiania backendu:', err);
    process.exit(1);
  });

  // Poczekaj na uruchomienie backendu
  await new Promise(resolve => setTimeout(resolve, 3000));

  console.log('\n🎨 Uruchamianie serwera frontend...');
  
  // Uruchom frontend
  const frontend = spawn('npm', ['run', 'dev'], {
    stdio: 'inherit',
    env: process.env,
    shell: true
  });

  frontend.on('error', (err) => {
    console.error('❌ Błąd uruchamiania frontendu:', err);
    backend.kill();
    process.exit(1);
  });

  // Obsługa zamykania
  process.on('SIGINT', () => {
    console.log('\n🛑 Zamykanie serwerów...');
    backend.kill();
    frontend.kill();
    process.exit(0);
  });
}

// Uruchom serwery
startServers().catch(err => {
  console.error('❌ Błąd uruchamiania:', err);
  process.exit(1);
});