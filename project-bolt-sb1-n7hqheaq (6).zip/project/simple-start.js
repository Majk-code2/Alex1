#!/usr/bin/env node

import { spawn } from 'child_process';
import fs from 'fs';

console.log('🚀 ALEX - Prosty launcher (bez kill-port)');

// Sprawdź .env
if (!fs.existsSync('.env')) {
  console.error('❌ Brak pliku .env!');
  console.error('Uruchom: npm run setup-env');
  process.exit(1);
}

console.log('✅ Plik .env istnieje');

let backend = null;
let frontend = null;

// Funkcja uruchamiająca backend
function startBackend() {
  console.log('🔧 Uruchamiam backend...');
  
  backend = spawn('node', ['server.js'], {
    stdio: 'inherit',
    shell: true,
    env: process.env
  });

  backend.on('error', (err) => {
    console.error('❌ Błąd backendu:', err.message);
  });

  backend.on('close', (code) => {
    if (code !== 0) {
      console.log(`⚠️  Backend zakończył się z kodem: ${code}`);
    }
  });
}

// Funkcja uruchamiająca frontend
function startFrontend() {
  console.log('🎨 Uruchamiam frontend...');
  
  frontend = spawn('npm', ['run', 'dev'], {
    stdio: 'inherit',
    shell: true,
    env: process.env
  });

  frontend.on('error', (err) => {
    console.error('❌ Błąd frontendu:', err.message);
  });

  frontend.on('close', (code) => {
    if (code !== 0) {
      console.log(`⚠️  Frontend zakończył się z kodem: ${code}`);
    }
  });
}

// Uruchom backend
startBackend();

// Poczekaj 3 sekundy i uruchom frontend
setTimeout(() => {
  startFrontend();
}, 3000);

// Obsługa zamykania
process.on('SIGINT', () => {
  console.log('\n🛑 Zamykanie serwerów...');
  
  if (backend) {
    backend.kill('SIGTERM');
  }
  
  if (frontend) {
    frontend.kill('SIGTERM');
  }
  
  setTimeout(() => {
    process.exit(0);
  }, 2000);
});

console.log('\n📋 INSTRUKCJE:');
console.log('1. Poczekaj aż oba serwery się uruchomią (około 10 sekund)');
console.log('2. Otwórz http://localhost:5173 w przeglądarce');
console.log('3. Aby zatrzymać, naciśnij Ctrl+C');
console.log('\n⚠️  Jeśli porty są zajęte, zamknij inne aplikacje lub uruchom ponownie terminal');