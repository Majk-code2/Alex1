# 🔐 Uwierzytelnianie Google z Supabase - Instrukcja

## Przegląd

ALEX Agent teraz obsługuje uwierzytelnianie przez Google za pomocą Supabase. Użytkownicy mogą:
- Zalogować się przez Google (zalecane)
- Kontynuować jako gość (ograniczone funkcje)

## Konfiguracja

### 1. Konfiguracja Google Cloud Console

1. Przejdź do [Google Cloud Console](https://console.cloud.google.com/)
2. Utwórz nowy projekt lub wybierz istniejący
3. Włącz Google Calendar API (jeśli planujesz używać kalendarza)
4. Przejdź do "APIs & Services" > "Credentials"
5. Kliknij "Create Credentials" > "OAuth client ID"
6. Wybierz "Web application"
7. Dodaj authorized redirect URIs:
   - `http://localhost:5173/auth/callback` (development)
   - `https://yourdomain.com/auth/callback` (production)
8. Skopiuj Client ID i Client Secret

### 2. Konfiguracja Supabase

1. Przejdź do [Supabase Dashboard](https://supabase.com/dashboard)
2. Wybierz swój projekt
3. Przejdź do Authentication > Providers
4. Włącz Google provider
5. Wklej Google Client ID i Client Secret
6. Dodaj redirect URLs:
   - `http://localhost:5173/auth/callback`
   - `https://yourdomain.com/auth/callback`
7. Zapisz ustawienia

### 3. Zmienne środowiskowe

Dodaj do pliku `.env`:

```env
# Supabase (wymagane dla uwierzytelniania)
VITE_SUPABASE_URL=https://your-project.supabase.co
VITE_SUPABASE_ANON_KEY=your-anon-key

# Google (opcjonalne - tylko dla kalendarza)
VITE_GOOGLE_CLIENT_ID=your-google-client-id
VITE_GOOGLE_CLIENT_SECRET=your-google-client-secret
```

## Jak to działa

### Przepływ uwierzytelniania

1. **Sprawdzenie sesji**: App.tsx sprawdza czy użytkownik jest zalogowany
2. **Ekran logowania**: Jeśli nie - pokazuje komponent Auth
3. **Opcje logowania**:
   - Google OAuth (zalecane)
   - Tryb gościa (bez rejestracji)
4. **Przekierowanie**: Po zalogowaniu przez Google, użytkownik wraca do aplikacji
5. **Sesja**: Supabase automatycznie zarządza sesją

### Różnice między trybami

| Funkcja | Zalogowany użytkownik | Tryb gościa |
|---------|----------------------|-------------|
| Chat z ALEX | ✅ | ✅ |
| Zapisywanie profilu | ✅ | ❌ |
| Historia rozmów | ✅ | ❌ |
| Kalendarz Google | ✅ | ❌ |
| Synchronizacja między urządzeniami | ✅ | ❌ |

## Komponenty

### Auth.tsx
- Ekran logowania z opcjami Google i trybu gościa
- Obsługa błędów uwierzytelniania
- Responsywny design

### App.tsx
- Zarządzanie stanem sesji
- Routing między Auth i główną aplikacją
- Przekazywanie userId do komponentów

### AlexAgent.tsx
- Obsługa zarówno zalogowanych użytkowników jak i gości
- Wyświetlanie statusu użytkownika
- Przycisk wylogowania

## Bezpieczeństwo

### Klucze API
- `VITE_SUPABASE_ANON_KEY` - bezpieczny dla frontendu
- `SUPABASE_SERVICE_ROLE_KEY` - tylko dla backendu (server.js)
- Nigdy nie ujawniaj service role key w kodzie frontendu

### Sesje
- Supabase automatycznie zarządza tokenami
- Tokeny są przechowywane bezpiecznie w localStorage
- Automatyczne odświeżanie tokenów

## Rozwiązywanie problemów

### Błąd: "Invalid redirect URL"
- Sprawdź czy redirect URL jest dodany w Google Cloud Console
- Sprawdź czy redirect URL jest dodany w Supabase Auth settings

### Błąd: "Missing Supabase environment variables"
- Upewnij się że `VITE_SUPABASE_URL` i `VITE_SUPABASE_ANON_KEY` są w `.env`
- Uruchom ponownie serwer deweloperski po dodaniu zmiennych

### Użytkownik nie może się zalogować
- Sprawdź logi w konsoli przeglądarki
- Sprawdź czy Google provider jest włączony w Supabase
- Sprawdź czy domeny są autoryzowane w Google Cloud Console

## Testowanie

### Test lokalny
1. Uruchom aplikację: `npm run dev:full`
2. Otwórz http://localhost:5173
3. Kliknij "Zaloguj się przez Google"
4. Sprawdź czy przekierowanie działa
5. Sprawdź czy sesja jest zachowana po odświeżeniu

### Test trybu gościa
1. Kliknij "Kontynuuj jako gość"
2. Sprawdź czy aplikacja działa
3. Sprawdź czy brak opcji zapisywania

## Przyszłe rozszerzenia

- [ ] Logowanie przez email/hasło
- [ ] Logowanie przez inne providery (GitHub, Discord)
- [ ] Zarządzanie profilem użytkownika
- [ ] Eksport/import danych
- [ ] Ustawienia prywatności