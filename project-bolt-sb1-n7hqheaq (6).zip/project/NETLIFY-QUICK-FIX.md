# 🚀 SZYBKA NAPRAWA NETLIFY

## Problem: ALEX nie odpowiada na Netlify

**Przyczyna:** Brak zmiennej środowiskowej `ANTHROPIC_API_KEY` na Netlify

## ✅ ROZWIĄZANIE (2 minuty):

### 1. **Przejdź do ustawień Netlify:**
https://app.netlify.com/sites/rad-griffin-a37e97/settings/deploys

### 2. **Przewiń do "Environment variables"**

### 3. **Kliknij "Add variable"**

### 4. **Dodaj zmienną:**
- **Key:** `ANTHROPIC_API_KEY`
- **Value:** `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`

### 5. **Kliknij "Create variable"**

### 6. **Redeploy:**
- Przejdź do "Deploys" tab
- Kliknij "Trigger deploy" → "Deploy site"
- Poczekaj 2 minuty

### 7. **Test:**
Otwórz: https://rad-griffin-a37e97.netlify.app/
Napisz "hej" do ALEX - powinien odpowiedzieć! 🎉

## 🔍 Sprawdź czy działa:

**Health Check:** https://rad-griffin-a37e97.netlify.app/.netlify/functions/health

Powinno zwrócić:
```json
{
  "status": "success",
  "anthropic_configured": true
}
```

## 🆘 Jeśli nadal nie działa:

1. **Sprawdź czy zmienna została dodana** w ustawieniach Netlify
2. **Sprawdź logi deployment** - czy build się udał
3. **Przetestuj lokalnie:** `npm run fix`

**TO WSZYSTKO!** 🚀