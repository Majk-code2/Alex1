# 🚀 Konfiguracja Netlify - Krok po kroku

## Problem: Brak połączenia API na Netlify

Aplikacja jest wdrożona, ale **brakuje zmiennych środowiskowych** na Netlify.

## Rozwiązanie:

### 1. Przejdź do ustawień Netlify

1. Otwórz: https://app.netlify.com/sites/rad-griffin-a37e97/settings/deploys
2. Przewiń do sekcji **"Environment variables"**
3. Kliknij **"Add variable"**

### 2. Dodaj zmienne środowiskowe

Dodaj te zmienne **DOKŁADNIE** jak poniżej:

**Zmienna 1:**
- **Key:** `ANTHROPIC_API_KEY`
- **Value:** `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`

**Zmienna 2 (opcjonalna):**
- **Key:** `VITE_SUPABASE_URL`
- **Value:** `https://syislcrmxopvhzcfalft.supabase.co`

**Zmienna 3 (opcjonalna):**
- **Key:** `VITE_SUPABASE_ANON_KEY`
- **Value:** `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InN5aXNsY3JteG9wdmh6Y2ZhbGZ0Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NTIwNjI4NzgsImV4cCI6MjA2NzYzODg3OH0.VtMmQYvjWnNVuYPyJNsTAhJz8yrP4r7xX1I1g4yUkoM`

### 3. Zapisz i redeploy

1. Kliknij **"Save"** po dodaniu każdej zmiennej
2. Przejdź do **"Deploys"** tab
3. Kliknij **"Trigger deploy"** → **"Deploy site"**

### 4. Poczekaj na deployment

- Deployment zajmie 1-2 minuty
- Sprawdź status na stronie deployments

### 5. Test

Po zakończeniu deployment:
1. Otwórz: https://rad-griffin-a37e97.netlify.app/
2. Napisz wiadomość do ALEX
3. Powinno działać! 🎉

## Alternatywne rozwiązanie (jeśli nie masz dostępu do Netlify):

Możesz przetestować lokalnie:

```bash
npm run fix
```

Aplikacja będzie dostępna na: http://localhost:5173

## Sprawdzenie czy działa:

1. **Test API:** https://rad-griffin-a37e97.netlify.app/.netlify/functions/health
2. **Główna aplikacja:** https://rad-griffin-a37e97.netlify.app/

Jeśli health endpoint zwraca `{"status":"success"}` - wszystko działa! ✅