# 🔐 Konfiguracja Google OAuth - Instrukcja krok po kroku

## Problem z logowaniem Google

Jeśli widzisz błąd "Serwer syislcrmxopvhzcfalft.supabase.co odrzucił połączenie", oznacza to problem z konfiguracją OAuth.

## ✅ Rozwiązanie krok po kroku

### 1. Sprawdź status projektu Supabase

```bash
# Otwórz dashboard Supabase
https://supabase.com/dashboard/project/syislcrmxopvhzcfalft
```

**Sprawdź:**
- ✅ Czy projekt jest aktywny (nie wstrzymany)
- ✅ Czy nie przekroczyłeś limitów
- ✅ Czy płatności są aktualne

### 2. Konfiguracja Google Cloud Console

1. **Przejdź do Google Cloud Console:**
   https://console.cloud.google.com/

2. **Utwórz lub wybierz projekt**

3. **Włącz Google+ API:**
   - APIs & Services > Library
   - Wyszukaj "Google+ API"
   - Kliknij "Enable"

4. **Utwórz OAuth 2.0 credentials:**
   - APIs & Services > Credentials
   - Create Credentials > OAuth client ID
   - Application type: Web application
   - Name: "ALEX Agent"

5. **Dodaj authorized redirect URIs:**
   ```
   https://syislcrmxopvhzcfalft.supabase.co/auth/v1/callback
   http://localhost:5173
   ```

6. **Skopiuj Client ID i Client Secret**

### 3. Konfiguracja Supabase Dashboard

1. **Otwórz Supabase Dashboard:**
   https://supabase.com/dashboard/project/syislcrmxopvhzcfalft

2. **Przejdź do Authentication > Providers**

3. **Włącz Google provider:**
   - Toggle: ON
   - Client ID: [wklej z Google Cloud Console]
   - Client Secret: [wklej z Google Cloud Console]

4. **Sprawdź Redirect URLs:**
   ```
   https://syislcrmxopvhzcfalft.supabase.co/auth/v1/callback
   ```

5. **Zapisz ustawienia**

### 4. Aktualizuj zmienne środowiskowe

Edytuj `.env-persistent`:

```env
# Supabase (sprawdź czy są aktualne)
VITE_SUPABASE_URL=https://syislcrmxopvhzcfalft.supabase.co
VITE_SUPABASE_ANON_KEY=eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...

# Google OAuth (dodaj nowe)
VITE_GOOGLE_CLIENT_ID=twoj-google-client-id
VITE_GOOGLE_CLIENT_SECRET=twoj-google-client-secret
```

### 5. Test konfiguracji

```bash
# Uruchom test Supabase
npm run test-supabase

# Jeśli OK, uruchom aplikację
npm run fix
```

## 🔧 Rozwiązywanie problemów

### Problem: "Connection refused"

**Przyczyny:**
- Projekt Supabase wstrzymany
- Niepoprawne klucze API
- Problem z siecią

**Rozwiązanie:**
1. Sprawdź status projektu w dashboard
2. Zweryfikuj klucze w `.env-persistent`
3. Sprawdź połączenie internetowe

### Problem: "Invalid redirect URI"

**Przyczyny:**
- Niepoprawne redirect URI w Google Console
- Niepoprawne redirect URI w Supabase

**Rozwiązanie:**
1. Sprawdź czy redirect URI są identyczne w obu miejscach
2. Upewnij się że używasz HTTPS w produkcji

### Problem: "OAuth not configured"

**Przyczyny:**
- Google provider nie jest włączony w Supabase
- Brak Client ID/Secret

**Rozwiązanie:**
1. Włącz Google provider w Supabase Dashboard
2. Dodaj poprawne Client ID i Secret

## 🎯 Szybki test

Po konfiguracji:

1. **Otwórz aplikację:** http://localhost:5173
2. **Kliknij "Zaloguj się przez Google"**
3. **Sprawdź czy przekierowuje do Google**
4. **Po zalogowaniu sprawdź czy wraca do aplikacji**

## 📞 Jeśli nadal nie działa

1. **Sprawdź logi w konsoli przeglądarki (F12)**
2. **Sprawdź logi w Supabase Dashboard > Logs**
3. **Sprawdź status Google API w Google Cloud Console**

## 🔄 Tryb fallback

Jeśli Google OAuth nie działa, aplikacja automatycznie przełączy się na:
- **Tryb gościa** - pełna funkcjonalność bez zapisywania
- **Lokalne przechowywanie** - dane w przeglądarce

Kliknij "Kontynuuj jako gość" aby używać aplikacji bez logowania.