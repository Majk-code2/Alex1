#!/usr/bin/env node

import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config();

console.log('🔍 TESTOWANIE POŁĄCZENIA Z SUPABASE...\n');

const supabaseUrl = process.env.VITE_SUPABASE_URL || process.env.SUPABASE_URL;
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY;

console.log('📋 Konfiguracja:');
console.log('URL:', supabaseUrl);
console.log('Key:', supabaseKey ? `${supabaseKey.substring(0, 20)}...` : 'BRAK');

if (!supabaseUrl || !supabaseKey) {
  console.error('❌ BŁĄD: Brak zmiennych Supabase w .env');
  console.error('\n📝 INSTRUKCJE:');
  console.error('1. Sprawdź czy .env zawiera:');
  console.error('   VITE_SUPABASE_URL=https://twoj-projekt.supabase.co');
  console.error('   VITE_SUPABASE_ANON_KEY=twoj-anon-key');
  console.error('2. Uruchom: npm run setup-env');
  process.exit(1);
}

// Test podstawowego połączenia
console.log('\n🌐 Test 1: Podstawowe połączenie...');
try {
  const response = await fetch(supabaseUrl + '/rest/v1/', {
    headers: {
      'apikey': supabaseKey,
      'Authorization': `Bearer ${supabaseKey}`
    }
  });
  
  if (response.ok) {
    console.log('✅ Podstawowe połączenie działa');
  } else {
    console.log('❌ Błąd połączenia:', response.status, response.statusText);
  }
} catch (error) {
  console.log('❌ Błąd sieci:', error.message);
}

// Test klienta Supabase
console.log('\n🔧 Test 2: Klient Supabase...');
try {
  const supabase = createClient(supabaseUrl, supabaseKey);
  
  // Test prostego zapytania
  const { data, error } = await supabase
    .from('user_profiles')
    .select('count')
    .limit(1);
    
  if (error) {
    if (error.message.includes('relation "user_profiles" does not exist')) {
      console.log('⚠️  Tabela user_profiles nie istnieje - to normalne przy pierwszym uruchomieniu');
      console.log('📝 Potrzebujesz utworzyć tabele w bazie danych');
    } else {
      console.log('❌ Błąd zapytania:', error.message);
    }
  } else {
    console.log('✅ Klient Supabase działa poprawnie');
  }
} catch (error) {
  console.log('❌ Błąd klienta:', error.message);
}

// Test autoryzacji
console.log('\n🔐 Test 3: Autoryzacja...');
try {
  const supabase = createClient(supabaseUrl, supabaseKey);
  const { data, error } = await supabase.auth.getSession();
  
  if (error) {
    console.log('❌ Błąd autoryzacji:', error.message);
  } else {
    console.log('✅ System autoryzacji działa');
  }
} catch (error) {
  console.log('❌ Błąd testu autoryzacji:', error.message);
}

console.log('\n📋 PODSUMOWANIE:');
console.log('Jeśli widzisz błędy powyżej:');
console.log('1. Sprawdź czy projekt Supabase jest aktywny na https://supabase.com/dashboard');
console.log('2. Sprawdź czy klucze API są aktualne');
console.log('3. Utwórz tabele w bazie danych (patrz ROZWIAZYWANIE-PROBLEMOW.md)');
console.log('4. Aplikacja będzie działać bez Supabase w trybie podstawowym');