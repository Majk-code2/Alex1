import express from 'express';
import cors from 'cors';
import bodyParser from 'body-parser';
import Anthropic from '@anthropic-ai/sdk';
import { createClient } from '@supabase/supabase-js';
import dotenv from 'dotenv';

dotenv.config(); // Ładuje zmienne środowiskowe z pliku .env

console.log('🔧 Uruchamianie serwera backend...');
console.log('📁 Sprawdzanie pliku .env...');

// Sprawdź czy plik .env istnieje i zawiera wymagane zmienne
const requiredEnvVars = ['ANTHROPIC_API_KEY'];
const optionalEnvVars = ['SUPABASE_URL', 'SUPABASE_SERVICE_ROLE_KEY'];
const missingVars = requiredEnvVars.filter(varName => !process.env[varName] || process.env[varName].includes('your-'));

if (missingVars.length > 0) {
  console.error('❌ BŁĄD KONFIGURACJI:');
  console.error('Brakuje lub są niepoprawnie skonfigurowane następujące zmienne środowiskowe:');
  missingVars.forEach(varName => {
    console.error(`  - ${varName}: ${process.env[varName] || 'BRAK'}`);
  });
  console.error('\n📝 INSTRUKCJE:');
  console.error('1. Skopiuj plik .env.example do .env');
  console.error('2. Uzupełnij wszystkie wartości placeholder swoimi rzeczywistymi kluczami API');
  console.error('3. Uruchom ponownie serwer');
  console.error('\nSerwer nie może zostać uruchomiony bez poprawnej konfiguracji.');
  process.exit(1);
}

console.log('✅ Zmienne środowiskowe sprawdzone');

// Sprawdź opcjonalne zmienne Supabase
const missingSupabase = optionalEnvVars.filter(varName => !process.env[varName] || process.env[varName].includes('your-'));
let supabaseEnabled = missingSupabase.length === 0;

if (!supabaseEnabled) {
  console.warn('⚠️  UWAGA: Supabase nie jest skonfigurowany');
  console.warn('Brakuje zmiennych:', missingSupabase.join(', '));
  console.warn('Aplikacja będzie działać w trybie podstawowym (bez zapisywania danych)');
}

console.log('🚀 Inicjalizacja Express...');
const app = express();
const port = process.env.PORT || 3002; // Użyj portu 3002, jak w Twoim frontendzie

// Konfiguracja CORS, aby Twój frontend mógł się łączyć
app.use(cors({
  origin: true, // Zezwala na wszystkie originy w środowisku deweloperskim
  credentials: true
}));
app.use(bodyParser.json());

console.log('🤖 Inicjalizacja klienta Anthropic...');
// Sprawdzenie klucza API przed inicjalizacją
console.log('Sprawdzam klucz Anthropic przed inicjalizacją (serwer):', process.env.ANTHROPIC_API_KEY ? 'Ustawiony' : 'BRAK');
console.log('Długość klucza Anthropic (serwer):', process.env.ANTHROPIC_API_KEY ? process.env.ANTHROPIC_API_KEY.length : 'N/A');
console.log('Pierwsze 5 znaków klucza Anthropic (serwer):', process.env.ANTHROPIC_API_KEY ? process.env.ANTHROPIC_API_KEY.substring(0, 5) : 'N/A');

// Inicjalizacja klienta Anthropic z Twoim kluczem API
let anthropic;
try {
  anthropic = new Anthropic({
    apiKey: process.env.ANTHROPIC_API_KEY,
  });
  console.log('✅ Klient Anthropic zainicjalizowany pomyślnie');
} catch (error) {
  console.error('❌ Błąd inicjalizacji klienta Anthropic:', error.message);
  console.error('⚠️  Serwer będzie działać bez klienta Anthropic - sprawdź konfigurację klucza API');
  anthropic = null;
}

// Dodaj graceful error handling dla wszystkich endpointów
const handleServerError = (error, req, res, next) => {
  console.error('🚨 Nieobsłużony błąd serwera:', error);
  
  // Nie pozwól serwerowi crashować
  if (!res.headersSent) {
    res.status(500).json({
      error: 'Wystąpił błąd wewnętrzny serwera',
      message: 'Serwer napotkał nieoczekiwany problem',
      timestamp: new Date().toISOString(),
      requestId: req.headers['x-request-id'] || 'unknown'
    });
  }
};

// Dodaj middleware do obsługi błędów
app.use(handleServerError);

// Obsłuż nieobsłużone rejections
process.on('unhandledRejection', (reason, promise) => {
  console.error('🚨 Nieobsłużone Promise rejection:', reason);
  console.error('Promise:', promise);
  // Nie zamykaj serwera, tylko zaloguj
});

// Obsłuż nieobsłużone exceptions
process.on('uncaughtException', (error) => {
  console.error('🚨 Nieobsłużony wyjątek:', error);
  // W produkcji można rozważyć graceful shutdown
  // process.exit(1);
});

console.log('🗄️  Inicjalizacja klienta Supabase...');
// Inicjalizacja klienta Supabase
let supabase;
if (supabaseEnabled) {
  try {
    console.log('📡 Testowanie połączenia z Supabase...');
    console.log('URL:', process.env.SUPABASE_URL);
    console.log('Service Role Key:', process.env.SUPABASE_SERVICE_ROLE_KEY ? 'Ustawiony' : 'Brak');
    
    supabase = createClient(
      process.env.SUPABASE_URL,
      process.env.SUPABASE_SERVICE_ROLE_KEY
    );
    
    // Test połączenia
    const testConnection = async () => {
      try {
        // Użyj prostszego testu połączenia, który nie wymaga istniejących tabel
        const { data, error } = await supabase.auth.getSession();
        if (error) {
          console.warn('⚠️  Ostrzeżenie Supabase - problem z połączeniem:', error.message);
          console.warn('Sprawdź czy projekt Supabase jest aktywny i klucze API są poprawne');
        } else {
          console.log('✅ Test połączenia z Supabase pomyślny');
        }
      } catch (err) {
        console.warn('⚠️  Nie można przetestować połączenia z Supabase:', err.message);
        console.warn('To może być normalne przy pierwszym uruchomieniu - aplikacja będzie działać w trybie podstawowym');
      }
    };
    
    // Uruchom test po chwili, ale nie blokuj startu serwera
    setTimeout(() => {
      testConnection().catch(err => {
        console.warn('⚠️  Test połączenia Supabase nie powiódł się:', err.message);
      });
    }, 2000);
    
    console.log('✅ Klient Supabase zainicjalizowany pomyślnie');
  } catch (error) {
    console.error('❌ Błąd inicjalizacji klienta Supabase:', error.message);
    supabaseEnabled = false;
  }
} else {
  console.log('⚠️  Supabase wyłączony - brak konfiguracji');
}

// Health check endpoint
app.get('/', (req, res) => {
  res.json({ 
    status: 'Backend server is running', 
    endpoints: ['/api/chat'],
    port: port,
    anthropic_configured: !!process.env.ANTHROPIC_API_KEY && !process.env.ANTHROPIC_API_KEY.includes('your-')
  });
});

// API health check endpoint - sprawdza połączenie z Anthropic bez marnowania tokenów
app.get('/api/health', async (req, res) => {
  try {
    // Sprawdzamy czy klucz API jest ustawiony
    if (!process.env.ANTHROPIC_API_KEY) {
      return res.status(500).json({ 
        status: 'error',
        message: 'ANTHROPIC_API_KEY nie jest ustawiony w pliku .env',
        fix: 'Ustaw prawidłowy klucz API w pliku .env-persistent'
      });
    }

    // Sprawdzamy czy klucz API ma poprawny format
    if (!process.env.ANTHROPIC_API_KEY.startsWith('sk-ant-api') || process.env.ANTHROPIC_API_KEY.includes('your-')) {
      return res.status(500).json({ 
        status: 'error',
        message: 'ANTHROPIC_API_KEY ma niepoprawny format lub jest placeholderem',
        fix: 'Wygeneruj nowy klucz API na https://console.anthropic.com/ i wstaw go do .env-persistent'
      });
    }

    // Sprawdzamy czy klient Anthropic jest poprawnie zainicjalizowany
    if (!anthropic) {
      return res.status(500).json({ 
        status: 'error',
        message: 'Klient Anthropic nie został poprawnie zainicjalizowany',
        fix: 'Sprawdź czy klucz API jest prawidłowy i uruchom ponownie serwer'
      });
    }

    // Sprawdź status Supabase (opcjonalnie)
    let supabaseStatus = 'disabled';
    if (supabaseEnabled && supabase) {
      try {
        await supabase.auth.getSession();
        supabaseStatus = 'connected';
      } catch (supabaseError) {
        supabaseStatus = 'error';
        console.warn('Supabase connection issue during health check:', supabaseError.message);
      }
    }
    
    // Zwróć status bez testowania Anthropic API (aby uniknąć problemów z siecią)
    res.json({ 
      status: 'success',
      message: 'Backend server is running',
      anthropic_configured: true,
      supabase: supabaseStatus,
      note: 'Anthropic API connection will be tested when first message is sent'
    });

  } catch (error) {
    console.error('Błąd podczas testowania API:', error);
    
    // Bardziej szczegółowe informacje o błędzie
    let errorMessage = 'Błąd połączenia z Anthropic API';
    let fixMessage = 'Sprawdź konfigurację klucza API';
    
    if (error.status === 401) {
      errorMessage = 'Nieprawidłowy klucz API Anthropic';
      fixMessage = 'Wygeneruj nowy klucz API na https://console.anthropic.com/';
    } else if (error.status === 429) {
      errorMessage = 'Przekroczono limit zapytań API';
      fixMessage = 'Poczekaj chwilę i spróbuj ponownie';
    } else if (error.status === 400) {
      errorMessage = 'Nieprawidłowe zapytanie do API';
      fixMessage = 'Sprawdź format zapytania';
    } else if (error.code === 'ENOTFOUND' || error.code === 'ECONNREFUSED') {
      errorMessage = 'Brak połączenia z internetem lub problem z siecią';
      fixMessage = 'Sprawdź połączenie internetowe i spróbuj ponownie';
    } else if (error.message && error.message.includes('fetch')) {
      errorMessage = 'Problem z połączeniem sieciowym';
      fixMessage = 'Sprawdź połączenie internetowe i konfigurację proxy/firewall';
    } else if (error.message && error.message.includes('Connection error')) {
      errorMessage = 'Błąd połączenia sieciowego z Anthropic API';
      fixMessage = 'Sprawdź połączenie internetowe, firewall i status API na https://status.anthropic.com/';
    } else if (error.code === 'UND_ERR_SOCKET') {
      errorMessage = 'Błąd połączenia socket - problem z siecią';
      fixMessage = 'Sprawdź połączenie internetowe i konfigurację sieci';
    } else if (error.message) {
      errorMessage = error.message;
    }
    
    // Nie zwracaj błędu 500 dla problemów z siecią - pozwól aplikacji działać
    res.json({ 
      status: 'error',
      message: errorMessage,
      details: error.message || 'Nieznany błąd',
      fix: fixMessage,
      errorCode: error.code || error.status || 'UNKNOWN',
      note: 'Backend server is running, but Anthropic API connection failed'
    });
  }
});

app.post('/api/chat', async (req, res) => {
  const { message, context } = req.body;

  if (!message) {
    return res.status(400).json({ error: 'Brak wiadomości w zapytaniu.' });
  }

  // Sprawdź czy klient Anthropic jest dostępny
  if (!anthropic) {
    return res.status(500).json({ 
      error: 'Klient Anthropic nie jest dostępny. Sprawdź konfigurację klucza API.',
      fix: 'Ustaw prawidłowy ANTHROPIC_API_KEY w pliku .env-persistent i uruchom ponownie serwer'
    });
  }

  try {
    // Przygotuj system prompt z kontekstem RAG jeśli jest dostępny
    let systemPrompt = "Jesteś ALEX - coach anty-prokrastynacyjny. Odpowiadaj krótko, praktycznie, po polsku. Dawaj konkretne kroki do działania. Bądź motywujący ale rzeczowy.";
    
    if (context && context.trim().length > 0) {
      systemPrompt += `\n\nMasz dostęp do następującej wiedzy specjalistycznej - użyj jej jeśli jest relevantna do pytania użytkownika:\n\n${context}`;
    }

    let response;
    try {
      response = await anthropic.messages.create({
        model: "claude-sonnet-4-20250514",
        max_tokens: 1024,
        system: systemPrompt,
        temperature: 0.7,
        messages: [
          {
            "role": "user", 
            "content": message
          }
        ]
      });
    } catch (apiError) {
      // Obsłuż błędy połączenia z Anthropic API
      if (apiError.message && apiError.message.includes('Connection error')) {
        return res.status(503).json({ 
          error: 'Tymczasowy problem z połączeniem do Anthropic API. Sprawdź połączenie internetowe i spróbuj ponownie za chwilę.',
          details: 'Connection error',
          fix: 'Sprawdź połączenie internetowe i status API na https://status.anthropic.com/'
        });
      } else if (apiError.code === 'UND_ERR_SOCKET') {
        return res.status(503).json({ 
          error: 'Problem z połączeniem sieciowym. Sprawdź konfigurację sieci.',
          details: 'Socket error',
          fix: 'Sprawdź połączenie internetowe, firewall i proxy'
        });
      }
      throw apiError; // Przekaż inne błędy do głównego catch
    }

    // Sprawdzanie, czy odpowiedź zawiera oczekiwany content
    const assistantResponse = response.content?.[0]?.text || "Przepraszam, nie mogłem uzyskać odpowiedzi.";

    // Zwróć więcej informacji o odpowiedzi
    res.json({ 
      content: assistantResponse,
      model: response.model,
      usage: response.usage,
      stop_reason: response.stop_reason
    });

  } catch (error) {
    console.error('Błąd podczas komunikacji z Claude API:', error);
    
    // Lepsze obsługiwanie błędów na podstawie typu błędu
    if (error.status === 401) {
      res.status(401).json({ error: 'Nieprawidłowy klucz API Anthropic.' });
    } else if (error.status === 429) {
      res.status(429).json({ error: 'Przekroczono limit zapytań. Spróbuj ponownie za chwilę.' });
    } else if (error.status === 400) {
      res.status(400).json({ error: 'Nieprawidłowe zapytanie do API.' });
    } else if (error.message && error.message.includes('Connection error')) {
      res.status(503).json({ 
        error: 'Problem z połączeniem do Anthropic API. Sprawdź połączenie internetowe.',
        fix: 'Sprawdź połączenie internetowe i status API na https://status.anthropic.com/'
      });
    } else if (error.code === 'UND_ERR_SOCKET') {
      res.status(503).json({ 
        error: 'Problem z połączeniem sieciowym.',
        fix: 'Sprawdź połączenie internetowe, firewall i proxy'
      });
    } else {
      res.status(500).json({ error: 'Wystąpił błąd podczas przetwarzania Twojej prośby.' });
    }
  }
});

// API endpoint do ładowania profilu użytkownika
app.get('/api/profile/load/:userId', async (req, res) => {
  const { userId } = req.params;

  if (!userId) {
    return res.status(400).json({ error: 'Brak userId w zapytaniu.' });
  }

  if (!supabaseEnabled) {
    return res.json({ profile: null, message: 'Supabase nie jest skonfigurowany' });
  }

  try {
    const { data, error } = await supabase
      .from('user_profiles')
      .select('profile_data')
      .eq('user_id', userId)
      .single();

    if (error && error.code !== 'PGRST116') { // PGRST116 = no rows returned
      console.error('Błąd podczas ładowania profilu:', error.message);
      // Jeśli tabela nie istnieje, zwróć informację o tym
      if (error.code === '42P01') {
        return res.json({ 
          profile: null, 
          message: 'Tabele bazy danych nie zostały jeszcze utworzone. Uruchom: node setup-database.js' 
        });
      }
      return res.status(500).json({ error: 'Błąd podczas ładowania profilu użytkownika.' });
    }

    // Jeśli nie znaleziono profilu, zwróć pusty profil
    if (!data) {
      return res.json({ profile: null });
    }

    res.json({ profile: data.profile_data });

  } catch (error) {
    console.error('Błąd podczas ładowania profilu:', error.message);
    res.status(500).json({ error: 'Wystąpił błąd podczas ładowania profilu użytkownika.' });
  }
});

// API endpoint do zapisywania profilu użytkownika
app.post('/api/profile/save', async (req, res) => {
  const { userId, profile } = req.body;

  if (!userId || !profile) {
    return res.status(400).json({ error: 'Brak userId lub profilu w zapytaniu.' });
  }

  if (!supabaseEnabled) {
    return res.json({ success: false, message: 'Supabase nie jest skonfigurowany' });
  }

  try {
    const { data, error } = await supabase
      .from('user_profiles')
      .upsert({
        user_id: userId,
        profile_data: profile,
        updated_at: new Date().toISOString()
      }, {
        onConflict: 'user_id'
      })
      .select();

    if (error) {
      console.error('Błąd podczas zapisywania profilu:', error.message);
      // Jeśli tabela nie istnieje, zwróć informację o tym
      if (error.code === '42P01') {
        return res.json({ 
          success: false, 
          message: 'Tabele bazy danych nie zostały jeszcze utworzone. Uruchom: node setup-database.js' 
        });
      }
      return res.status(500).json({ error: 'Błąd podczas zapisywania profilu użytkownika.' });
    }

    res.json({ 
      success: true, 
      message: 'Profil użytkownika został zapisany.',
      data: data[0]
    });

  } catch (error) {
    console.error('Błąd podczas zapisywania profilu:', error.message);
    res.status(500).json({ error: 'Wystąpił błąd podczas zapisywania profilu użytkownika.' });
  }
});

// API endpoint do ładowania historii rozmów
app.get('/api/conversations/load/:userId', async (req, res) => {
  const { userId } = req.params;
  const { limit = 50 } = req.query;

  if (!userId) {
    return res.status(400).json({ error: 'Brak userId w zapytaniu.' });
  }

  if (!supabaseEnabled) {
    return res.json({ conversations: [], message: 'Supabase nie jest skonfigurowany' });
  }

  try {
    const { data, error } = await supabase
      .from('conversations')
      .select('*')
      .eq('user_id', userId)
      .order('created_at', { ascending: false })
      .limit(parseInt(limit));

    if (error) {
      console.error('Błąd podczas ładowania rozmów:', error.message);
      // Jeśli tabela nie istnieje, zwróć pustą listę
      if (error.code === '42P01') {
        return res.json({ 
          conversations: [], 
          message: 'Tabele bazy danych nie zostały jeszcze utworzone. Uruchom: node setup-database.js' 
        });
      }
      return res.status(500).json({ error: 'Błąd podczas ładowania historii rozmów.' });
    }

    res.json({ conversations: data || [] });

  } catch (error) {
    console.error('Błąd podczas ładowania rozmów:', error.message);
    res.status(500).json({ error: 'Wystąpił błąd podczas ładowania historii rozmów.' });
  }
});

// API endpoint do zapisywania wiadomości w rozmowie
app.post('/api/conversations/save', async (req, res) => {
  const { userId, messages } = req.body;

  if (!userId || !messages || !Array.isArray(messages)) {
    return res.status(400).json({ error: 'Brak userId lub wiadomości w zapytaniu.' });
  }

  if (!supabaseEnabled) {
    return res.json({ success: false, message: 'Supabase nie jest skonfigurowany' });
  }

  try {
    // Zapisz każdą wiadomość osobno
    const conversationPromises = messages.map(message => 
      supabase
        .from('conversations')
        .insert({
          user_id: userId,
          message_id: message.id,
          role: message.role,
          content: message.content,
          metadata: message.metadata || {},
          created_at: message.timestamp
        })
    );

    const results = await Promise.all(conversationPromises);
    
    // Sprawdź czy wszystkie zapisy się udały
    const errors = results.filter(result => result.error);
    if (errors.length > 0) {
      console.error('Błędy podczas zapisywania wiadomości:', errors.map(e => e.error?.message).join(', '));
      // Sprawdź czy to problem z nieistniejącymi tabelami
      const tableErrors = errors.filter(e => e.error?.code === '42P01');
      if (tableErrors.length > 0) {
        return res.json({ 
          success: false, 
          message: 'Tabele bazy danych nie zostały jeszcze utworzone. Uruchom: node setup-database.js' 
        });
      }
      return res.status(500).json({ error: 'Błąd podczas zapisywania niektórych wiadomości.' });
    }

    res.json({ 
      success: true, 
      message: `Zapisano ${messages.length} wiadomości.`,
      saved_count: messages.length
    });

  } catch (error) {
    console.error('Błąd podczas zapisywania rozmów:', error.message);
    res.status(500).json({ error: 'Wystąpił błąd podczas zapisywania rozmów.' });
  }
});

app.listen(port, () => {
  console.log('\n🚀 SERWER URUCHOMIONY POMYŚLNIE!');
  console.log(`📍 URL: http://localhost:${port}`);
  console.log(`🔑 Anthropic API: ${process.env.ANTHROPIC_API_KEY ? '✅ OK' : '❌ BRAK'}`);
  console.log(`🗄️  Supabase: ${supabaseEnabled ? '✅ OK' : '⚠️  OFF'}`);
  console.log('\n📋 Dostępne endpointy:');
  console.log('  GET  / - Status serwera');
  console.log('  GET  /api/health - Sprawdzenie połączenia z API');
  console.log('  POST /api/chat - Chat z ALEX');
  console.log('\n✅ BACKEND GOTOWY DO PRACY!');
});