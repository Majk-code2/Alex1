import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'

// https://vitejs.dev/config/
export default defineConfig({
  plugins: [react()],
  
  // Stabilizacja serwera deweloperskiego
  server: {
    port: 5173,
    strictPort: true,
    host: true,
    open: false,
    hmr: {
      overlay: false,
    },
    proxy: {
      '/api': {
        target: 'http://localhost:3002',
        changeOrigin: true,
        secure: false,
        timeout: 60000,
        proxyTimeout: 60000,
        configure: (proxy, options) => {
          proxy.on('error', (err, req, res) => {
            console.error('🔧 PROXY ERROR: Backend server nie jest dostępny na porcie 3002');
            console.error('💡 Uruchom backend: npm run fix lub npm run backend');
            console.error('Szczegóły błędu:', err.message);
            
            if (!res.headersSent) {
              res.writeHead(503, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({
                error: 'Backend server niedostępny',
                message: 'Uruchom backend server: npm run fix',
                code: 'BACKEND_UNAVAILABLE'
              }));
            }
          });
          proxy.on('proxyReq', (proxyReq, req, res) => {
            if (process.env.NODE_ENV === 'development') {
              console.log('📡 Proxying request to backend:', proxyReq.path);
            }
          });
        }
      }
    }
  },
  
  // Optymalizacje dla stabilności
  optimizeDeps: {
    include: ['react', 'react-dom', 'lucide-react'],
    exclude: []
  },
  
  // Konfiguracja budowania
  build: {
    sourcemap: true,
    commonjsOptions: {
      include: [/node_modules/],
      transformMixedEsModules: true
    },
    rollupOptions: {
      onwarn(warning, warn) {
        if (warning.code === 'MODULE_LEVEL_DIRECTIVE') return;
        warn(warning);
      }
    }
  },
  
  // POPRAWIONE: Nie override process.env - pozwól na VITE_ variables
  define: {
    global: 'globalThis',
    // Usuń 'process.env': '{}' - to kasowało environment variables!
  },
  
  resolve: {
    alias: {
      util: 'util'
    }
  }
})