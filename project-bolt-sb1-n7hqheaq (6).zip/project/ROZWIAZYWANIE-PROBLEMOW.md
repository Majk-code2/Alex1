# 🔧 Rozwiązywanie problemów ALEX Agent

## Problem: "Serwer syislcrmxopvhzcfalft.supabase.co odrzucił połączenie"

### Przyczyny:
1. **Niepoprawne klucze Supabase** - sprawdź czy są aktualne
2. **Projekt Supabase nieaktywny** - może być wstrzymany
3. **Problemy z siecią** - firewall lub proxy
4. **Brak tabel w bazie danych** - nie utworzono schematu

### Rozwiązania:

#### 1. Sprawdź status projektu Supabase
```bash
# Otwórz dashboard Supabase
https://supabase.com/dashboard/project/syislcrmxopvhzcfalft
```

#### 2. Sprawdź klucze API
1. Przejdź do Settings > API w Supabase Dashboard
2. Sprawdź czy klucze w `.env-persistent` są aktualne:
   - `SUPABASE_URL` = Project URL
   - `VITE_SUPABASE_ANON_KEY` = anon public key
   - `SUPABASE_SERVICE_ROLE_KEY` = service_role key

#### 3. Utwórz tabele w bazie danych
```sql
-- Wykonaj w SQL Editor w Supabase Dashboard

-- Tabela profili użytkowników
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text UNIQUE NOT NULL,
  profile_data jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Tabela rozmów
CREATE TABLE IF NOT EXISTS conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  message_id text NOT NULL,
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  content text NOT NULL,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- Indeksy dla wydajności
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_conversations_user_id ON conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_conversations_created_at ON conversations(created_at DESC);

-- Row Level Security
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;

-- Polityki RLS (pozwalają na wszystko - dla uproszczenia)
CREATE POLICY "Allow all operations on user_profiles" ON user_profiles FOR ALL USING (true);
CREATE POLICY "Allow all operations on conversations" ON conversations FOR ALL USING (true);
```

#### 4. Test połączenia
```bash
# Uruchom aplikację z debugowaniem
npm run setup-env && npm run dev:full
```

#### 5. Tryb bez Supabase
Jeśli Supabase nie działa, aplikacja będzie działać w trybie podstawowym:
- Chat z ALEX ✅
- Zapisywanie danych ❌
- Historia rozmów ❌

## Inne częste problemy

### ❌ "ANTHROPIC_API_KEY nie jest ustawiony"
```bash
# Sprawdź plik .env-persistent
cat .env-persistent | grep ANTHROPIC

# Jeśli zawiera "your-key-here", edytuj plik:
nano .env-persistent

# Zamień na prawdziwy klucz z https://console.anthropic.com/
```

### ❌ "Port 3002 zajęty"
```bash
# Zabij proces na porcie
npx kill-port 3002

# Lub znajdź i zabij ręcznie
lsof -i :3002
kill -9 [PID]
```

### ❌ "Port 5173 zajęty"
```bash
# Zabij proces na porcie
npx kill-port 5173

# Lub uruchom na innym porcie
npm run dev -- --port 5174
```

### ❌ Frontend nie łączy się z backendem
```bash
# Sprawdź czy backend działa
curl http://localhost:3002/api/health

# Jeśli nie odpowiada, sprawdź logi backendu
npm run server
```

### ❌ "Missing Supabase environment variables"
```bash
# Sprawdź czy zmienne są w .env
cat .env | grep SUPABASE

# Jeśli brak, uruchom setup
npm run setup-env
```

## Komendy ratunkowe

### Kompletny restart
```bash
# Zabij wszystkie procesy
npx kill-port 3002
npx kill-port 5173

# Wyczyść cache
rm -rf node_modules/.vite
rm -rf dist

# Reinstaluj i uruchom
npm install
npm run setup-env
npm run dev:full
```

### Reset konfiguracji
```bash
# Usuń .env i utwórz ponownie
rm .env
npm run setup-env
```

### Test bez Supabase
```bash
# Edytuj .env-persistent i usuń/zakomentuj linie Supabase
# SUPABASE_URL=
# SUPABASE_SERVICE_ROLE_KEY=
# VITE_SUPABASE_URL=
# VITE_SUPABASE_ANON_KEY=

npm run setup-env
npm run dev:full
```

## Sprawdzanie logów

### Logi backendu
```bash
npm run server
# Szukaj błędów w terminalu
```

### Logi frontendu
```bash
# Otwórz Developer Tools w przeglądarce (F12)
# Sprawdź zakładkę Console
```

### Logi Supabase
```bash
# W Supabase Dashboard > Logs
# Sprawdź API logs i Database logs
```

## Kontakt z supportem

Jeśli nic nie pomaga:
1. Skopiuj pełne logi błędów
2. Sprawdź czy projekt Supabase jest aktywny
3. Sprawdź czy masz wystarczające limity API
4. Spróbuj utworzyć nowy projekt Supabase

## Szybka diagnostyka

```bash
# Uruchom pełną diagnostykę
echo "=== DIAGNOSTYKA ALEX AGENT ==="
echo "1. Sprawdzanie plików..."
ls -la .env* 2>/dev/null || echo "Brak plików .env"

echo "2. Sprawdzanie portów..."
lsof -i :3002 2>/dev/null || echo "Port 3002 wolny"
lsof -i :5173 2>/dev/null || echo "Port 5173 wolny"

echo "3. Sprawdzanie zmiennych..."
grep -v "^#" .env 2>/dev/null | grep -E "(ANTHROPIC|SUPABASE)" || echo "Brak zmiennych"

echo "4. Test backendu..."
curl -s http://localhost:3002/api/health || echo "Backend nie odpowiada"

echo "=== KONIEC DIAGNOSTYKI ==="
```