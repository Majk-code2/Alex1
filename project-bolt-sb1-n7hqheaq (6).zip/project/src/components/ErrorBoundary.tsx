import React, { Component, ErrorInfo, ReactNode } from 'react';
import { AlertTriangle, RefreshCw, Home, Bug } from 'lucide-react';
import { errorHandler } from '../lib/error-handler';

interface Props {
  children: ReactNode;
  fallback?: ReactNode;
  onError?: (error: Error, errorInfo: ErrorInfo) => void;
}

interface State {
  hasError: boolean;
  error: Error | null;
  errorId: string | null;
  retryCount: number;
}

export class ErrorBoundary extends Component<Props, State> {
  private maxRetries = 3;

  constructor(props: Props) {
    super(props);
    this.state = {
      hasError: false,
      error: null,
      errorId: null,
      retryCount: 0
    };
  }

  static getDerivedStateFromError(error: Error): Partial<State> {
    return {
      hasError: true,
      error
    };
  }

  componentDidCatch(error: Error, errorInfo: ErrorInfo) {
    // Obsłuż błąd przez nasz system
    const errorReport = errorHandler.handleError(error, {
      component: 'ErrorBoundary',
      action: 'componentDidCatch',
      timestamp: new Date(),
      metadata: {
        componentStack: errorInfo.componentStack,
        errorBoundary: true
      }
    });

    this.setState({ errorId: errorReport.id });

    // Wywołaj callback jeśli podany
    if (this.props.onError) {
      this.props.onError(error, errorInfo);
    }

    // Loguj do konsoli dla debugowania
    console.error('ErrorBoundary caught an error:', error);
    console.error('Component stack:', errorInfo.componentStack);
  }

  handleRetry = () => {
    if (this.state.retryCount < this.maxRetries) {
      this.setState(prevState => ({
        hasError: false,
        error: null,
        errorId: null,
        retryCount: prevState.retryCount + 1
      }));
    }
  };

  handleReset = () => {
    this.setState({
      hasError: false,
      error: null,
      errorId: null,
      retryCount: 0
    });
  };

  handleReload = () => {
    window.location.reload();
  };

  render() {
    if (this.state.hasError) {
      // Użyj custom fallback jeśli podany
      if (this.props.fallback) {
        return this.props.fallback;
      }

      // Domyślny UI błędu
      return (
        <div className="min-h-screen bg-gray-50 flex items-center justify-center p-4">
          <div className="max-w-md w-full bg-white rounded-lg shadow-lg p-6">
            <div className="flex items-center gap-3 mb-4">
              <div className="p-2 bg-red-100 rounded-full">
                <AlertTriangle className="w-6 h-6 text-red-600" />
              </div>
              <div>
                <h1 className="text-lg font-semibold text-gray-900">
                  Ups! Coś poszło nie tak
                </h1>
                <p className="text-sm text-gray-600">
                  Wystąpił nieoczekiwany błąd w aplikacji
                </p>
              </div>
            </div>

            {/* Szczegóły błędu */}
            <div className="bg-gray-50 rounded-lg p-4 mb-4">
              <h3 className="text-sm font-medium text-gray-900 mb-2">
                Szczegóły błędu:
              </h3>
              <p className="text-sm text-gray-700 font-mono break-all">
                {this.state.error?.message || 'Nieznany błąd'}
              </p>
              {this.state.errorId && (
                <p className="text-xs text-gray-500 mt-2">
                  ID błędu: {this.state.errorId}
                </p>
              )}
            </div>

            {/* Akcje */}
            <div className="space-y-3">
              {this.state.retryCount < this.maxRetries && (
                <button
                  onClick={this.handleRetry}
                  className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
                >
                  <RefreshCw className="w-4 h-4" />
                  Spróbuj ponownie ({this.maxRetries - this.state.retryCount} pozostało)
                </button>
              )}

              <button
                onClick={this.handleReset}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-gray-600 text-white rounded-lg hover:bg-gray-700 transition-colors"
              >
                <Home className="w-4 h-4" />
                Resetuj komponent
              </button>

              <button
                onClick={this.handleReload}
                className="w-full flex items-center justify-center gap-2 px-4 py-2 bg-green-600 text-white rounded-lg hover:bg-green-700 transition-colors"
              >
                <RefreshCw className="w-4 h-4" />
                Odśwież stronę
              </button>
            </div>

            {/* Informacje pomocnicze */}
            <div className="mt-4 pt-4 border-t border-gray-200">
              <div className="flex items-center gap-2 text-sm text-gray-600">
                <Bug className="w-4 h-4" />
                <span>
                  Jeśli problem się powtarza, sprawdź konsolę przeglądarki (F12)
                </span>
              </div>
            </div>
          </div>
        </div>
      );
    }

    return this.props.children;
  }
}

// Hook do używania w komponentach funkcyjnych
export const useErrorHandler = () => {
  const handleError = React.useCallback((error: Error, context: string) => {
    errorHandler.handleError(error, {
      component: context,
      action: 'manual',
      timestamp: new Date()
    });
  }, []);

  return { handleError };
};

// HOC dla automatycznego wrappowania komponentów
export function withErrorBoundary<P extends object>(
  Component: React.ComponentType<P>,
  fallback?: ReactNode
) {
  const WrappedComponent = (props: P) => (
    <ErrorBoundary fallback={fallback}>
      <Component {...props} />
    </ErrorBoundary>
  );

  WrappedComponent.displayName = `withErrorBoundary(${Component.displayName || Component.name})`;
  
  return WrappedComponent;
}