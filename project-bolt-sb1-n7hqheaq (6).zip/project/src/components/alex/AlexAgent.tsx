import React, { useState, useEffect, useRef } from 'react';
import { Send, MessageCircle, Loader2, AlertCircle, Brain, Target, Zap, Smile, Calendar, LogOut, User } from 'lucide-react';
import { supabase } from '../../lib/supabase';
import type { Session } from '@supabase/supabase-js';
import { apiClient } from '../../lib/api-client';
import CalendarIntegration from '../calendar/CalendarIntegration';
import CalendarDetector, { CalendarIntent } from '../../lib/agent/calendar-detector';

// Import agent components
import ChunkSelector, { ChunkSelectionContext } from '../../lib/agent/chunk-selector';
import ConversationFlowManager from '../../lib/agent/conversation-flow';
import CrisisDetector from '../../lib/agent/crisis-detector';
import UserProfiler from '../../lib/agent/user-profiler';
import PromptBuilder from '../../lib/ai/prompt-builder';
import PersonalityAdapter from '../../agents/alex-personality';

// Import system prompt
import systemPromptContent from '../../agents/alex-system-prompt.md?raw';

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
  metadata?: {
    usedChunks?: string[];
    detectedCrisis?: boolean;
    personalityType?: string;
    conversationStage?: string;
  };
}

interface AlexAgentProps {
  onBackToDashboard?: () => void;
  userId?: string;
  session?: Session | null;
  onLogout?: () => void;
}

const AlexAgent: React.FC<AlexAgentProps> = ({ 
  onBackToDashboard, 
  userId: propUserId, 
  session,
  onLogout 
}) => {
  // Generate or retrieve userId
  const [userId] = useState(() => {
    if (propUserId) {
      return propUserId;
    }
    
    // Fallback dla trybu gościa
    let storedUserId = localStorage.getItem('alex-user-id');
    if (!storedUserId) {
      storedUserId = `guest_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem('alex-user-id', storedUserId);
    }
    return storedUserId;
  });

  // State
  const [messages, setMessages] = useState<Message[]>([
    {
      id: '1',
      role: 'assistant',
      content: 'Cześć! Jestem ALEX, twój coach anty-prokrastynacyjny. Gotowy do działania? Powiedz mi, z czym się zmagasz!',
      timestamp: new Date()
    }
  ]);
  const [inputValue, setInputValue] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [debugMode, setDebugMode] = useState(false);
  const [showCalendar, setShowCalendar] = useState(false);
  const [pendingCalendarEvent, setPendingCalendarEvent] = useState<CalendarIntent | null>(null);

  // Agent components
  const chunkSelector = useRef(new ChunkSelector());
  const conversationFlow = useRef(new ConversationFlowManager());
  const crisisDetector = useRef(new CrisisDetector());
  const userProfiler = useRef(new UserProfiler(userId));
  const promptBuilder = useRef(new PromptBuilder());
  const personalityAdapter = useRef(new PersonalityAdapter());
  const calendarDetector = useRef(new CalendarDetector());

  // Refs
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Load user profile on component mount
  useEffect(() => {
    const loadUserProfile = async () => {
      try {
        await userProfiler.current.loadProfile(userId);
        console.log('Profil użytkownika załadowany dla:', userId);
      } catch (error) {
        console.error('Błąd podczas ładowania profilu użytkownika:', error);
      }
    };

    loadUserProfile();
  }, [userId]);

  // Save conversation to database
  const saveConversation = async (newMessages: Message[]) => {
    try {
      // Zapisz bezpośrednio do Supabase
      const conversationData = newMessages.map(message => ({
        user_id: userId,
        message_id: message.id,
        role: message.role,
        content: message.content,
        metadata: message.metadata || {},
        created_at: message.timestamp.toISOString()
      }));

      const { error } = await supabase
        .from('conversations')
        .insert(conversationData);

      if (error) {
        throw error;
      }

      console.log('Rozmowa zapisana do bazy danych');
    } catch (error) {
      console.error('Błąd podczas zapisywania rozmowy:', error);
    }
  };

  // Load conversation history on component mount
  useEffect(() => {
    const loadConversationHistory = async () => {
      try {
        const { data, error } = await supabase
          .from('conversations')
          .select('*')
          .eq('user_id', userId)
          .order('created_at', { ascending: true })
          .limit(20);

        if (error) {
          console.error('Błąd podczas ładowania historii:', error);
          return;
        }

        if (data && data.length > 0) {
          // Konwertuj dane z bazy na format Message
          const loadedMessages: Message[] = data.map(conv => ({
            id: conv.message_id,
            role: conv.role,
            content: conv.content,
            timestamp: new Date(conv.created_at),
            metadata: conv.metadata
          }));

          // Dodaj załadowane wiadomości do istniejących (bez duplikatów)
          setMessages(prev => {
            const existingIds = prev.map(m => m.id);
            const newMessages = loadedMessages.filter(m => !existingIds.includes(m.id));
            return [...prev, ...newMessages];
          });

          console.log(`Załadowano ${loadedMessages.length} wiadomości z historii`);
        }
      } catch (error) {
        console.error('Błąd podczas ładowania historii rozmów:', error);
      }
    };

    loadConversationHistory();
  }, [userId]);

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  const sendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    const userMessage = inputValue.trim();
    setInputValue('');
    setError(null);

    // Add user message
    const userMessageObj: Message = {
      id: Date.now().toString(),
      role: 'user',
      content: userMessage,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessageObj]);
    setIsLoading(true);

    try {
      // Get conversation history
      const conversationHistory = messages.map(m => 
        `${m.role === 'user' ? 'User' : 'Alex'}: ${m.content}`
      );

      // 1. Detect crisis
      const crisisSignals = crisisDetector.current.detectCrisis(userMessage, conversationHistory);
      
      // 2. Update user profile and detect personality
      const userProfile = userProfiler.current.updateProfile(userMessage, conversationHistory, '');
      const personalityType = personalityAdapter.current.detectPersonality(userMessage, conversationHistory);
      
      // 2.5. Detect calendar intent
      const calendarIntent = calendarDetector.current.detectCalendarIntent(userMessage);

      // 3. Update conversation flow
      const conversationStage = conversationFlow.current.updateContext(userMessage, '');

      // 4. Select relevant chunks
      const chunkContext: ChunkSelectionContext = {
        userMessage,
        conversationHistory,
        personalityType,
        conversationStage,
        isCrisis: crisisSignals.isCrisis
      };
      const relevantChunks = chunkSelector.current.selectRelevantChunks(chunkContext);

      // 5. Build prompt
      const promptContext = {
        userMessage,
        conversationHistory,
        relevantChunks,
        personalityType,
        conversationStage,
        crisisSignals,
        userProfile,
        calendarIntent,
        systemPrompt: systemPromptContent
      };

      if (debugMode) {
        promptBuilder.current.debugPrompt(promptContext);
      }

      const finalPrompt = promptBuilder.current.buildPrompt(promptContext);

      // 6. Send to AI
      let response;
      try {
        const responseData = await apiClient.post('/api/chat', {
          message: finalPrompt,
          context: '' // Context is now built into the prompt
        });
        
        response = { content: responseData.content };
      } catch (fetchError: any) {
        if (fetchError.name === 'TypeError' || fetchError.message?.includes('Failed to fetch')) {
          throw new Error('Nie można połączyć się z serwerem. Sprawdź czy backend działa (npm run fix).');
        } else if (fetchError.name === 'TimeoutError') {
          throw new Error('Timeout - serwer nie odpowiada. Spróbuj ponownie.');
        }
        throw fetchError;
      }

      let alexResponse = response.content;

      // 7. Adapt response based on personality
      if (personalityType) {
        alexResponse = personalityAdapter.current.adaptResponse(alexResponse, personalityType);
      }
      
      // 7.5. Handle calendar intent
      if (calendarIntent.hasCalendarIntent) {
        const calendarSuggestion = calendarDetector.current.generateCalendarSuggestion(calendarIntent);
        
        if (calendarIntent.action === 'add_event') {
          setPendingCalendarEvent(calendarIntent);
          alexResponse += `\n\n📅 ${calendarSuggestion}`;
        } else if (calendarIntent.action === 'check_schedule') {
          alexResponse += `\n\n📅 ${calendarSuggestion}`;
          // Automatycznie pokaż kalendarz
          setShowCalendar(true);
        }
      }

      // 8. Update user profile with Alex's response
      userProfiler.current.updateProfile(userMessage, conversationHistory, alexResponse);

      // 9. Update conversation flow with Alex's response
      conversationFlow.current.updateContext(userMessage, alexResponse);

      // Add Alex response with metadata
      const alexMessageObj: Message = {
        id: (Date.now() + 1).toString(),
        role: 'assistant',
        content: alexResponse,
        timestamp: new Date(),
        metadata: {
          usedChunks: relevantChunks.map(r => r.chunk.title),
          detectedCrisis: crisisSignals.isCrisis,
          personalityType: personalityType?.name,
          conversationStage: conversationStage?.name,
          calendarIntent: calendarIntent.hasCalendarIntent ? calendarIntent.action : undefined
        }
      };

      setMessages(prev => [...prev, alexMessageObj]);

      // Save conversation to database
      await saveConversation([userMessageObj, alexMessageObj]);

      // Save user profile after interaction
      await userProfiler.current.saveProfile(userId);

    } catch (error) {
      setError('Przepraszam, wystąpił problem z połączeniem. Spróbuj ponownie.');
      console.error('Error:', error);
    } finally {
      setIsLoading(false);
      inputRef.current?.focus();
    }
  };
  
  const handleCalendarEventAdded = (event: any) => {
    setPendingCalendarEvent(null);
    
    // Dodaj wiadomość potwierdzającą
    const confirmationMessage: Message = {
      id: (Date.now() + 2).toString(),
      role: 'assistant',
      content: `✅ Świetnie! Dodałem wydarzenie "${event.data.summary}" do Twojego kalendarza. Link: ${event.htmlLink}`,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, confirmationMessage]);
  };
  
  const handleCalendarError = (error: string) => {
    setPendingCalendarEvent(null);
    
    const errorMessage: Message = {
      id: (Date.now() + 2).toString(),
      role: 'assistant',
      content: `❌ Przepraszam, wystąpił problem z kalendarzem: ${error}`,
      timestamp: new Date()
    };
    
    setMessages(prev => [...prev, errorMessage]);
  };
  
  // Handle confirmation for pending calendar events
  useEffect(() => {
    if (pendingCalendarEvent && messages.length > 0) {
      const lastMessage = messages[messages.length - 1];
      if (lastMessage.role === 'user') {
        const isConfirmation = calendarDetector.current.detectConfirmation(lastMessage.content);
        const isRejection = calendarDetector.current.detectRejection(lastMessage.content);
        
        if (isConfirmation) {
          handleAddCalendarEvent(pendingCalendarEvent);
        } else if (isRejection) {
          setPendingCalendarEvent(null);
          const rejectionMessage: Message = {
            id: (Date.now() + 2).toString(),
            role: 'assistant',
            content: 'Okej, nie dodaję wydarzenia do kalendarza. Czy mogę Ci pomóc w czymś innym?',
            timestamp: new Date()
          };
          setMessages(prev => [...prev, rejectionMessage]);
        }
      }
    }
  }, [messages, pendingCalendarEvent]);
  
  const handleAddCalendarEvent = async (intent: CalendarIntent) => {
    // Mock implementation - Google Calendar integration temporarily disabled
    setShowCalendar(true);
    
    // Simulate successful event addition
    setTimeout(() => {
      handleCalendarEventAdded({
        success: true,
        data: { summary: intent.eventText || 'Nowe wydarzenie' },
        htmlLink: '#'
      });
    }, 1000);
  };

  const handleKeyPress = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      sendMessage();
    }
  };

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString('pl-PL', { 
      hour: '2-digit', 
      minute: '2-digit' 
    });
  };

  const resetChat = () => {
    // Generate new userId for new chat session
    if (!session) {
      // Tylko w trybie gościa generuj nowy ID
      const newUserId = `guest_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
      localStorage.setItem('alex-user-id', newUserId);
    }
    
    setMessages([
      {
        id: '1',
        role: 'assistant',
        content: 'Cześć! Jestem ALEX, twój coach anty-prokrastynacyjny. Gotowy do działania? Powiedz mi, z czym się zmagasz!',
        timestamp: new Date()
      }
    ]);
    setError(null);
    
    // Reset all agent components
    conversationFlow.current.reset();
    userProfiler.current.reset();
    if (!session) {
      const newUserId = localStorage.getItem('alex-user-id') || userId;
      userProfiler.current.setUserId(newUserId);
    }
    personalityAdapter.current.reset();
  };

  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 px-4 py-4">
        <div className="max-w-4xl mx-auto flex items-center gap-3">
          <div className="p-2 bg-blue-100 rounded-full">
            <Brain className="w-6 h-6 text-blue-600" />
          </div>
          <div>
            <h1 className="text-xl font-semibold text-gray-800">ALEX Agent</h1>
            <p className="text-sm text-gray-600">
              Inteligentny coach anty-prokrastynacyjny • 
              {session ? (
                <span className="text-green-600">Zalogowany: {session.user?.email}</span>
              ) : (
                <span className="text-gray-500">Tryb gościa • ID: {userId.slice(-8)}</span>
              )}
            </p>
          </div>
          
          {/* Agent Status */}
          <div className="ml-auto flex items-center gap-4">
            {/* Personality Type Indicator */}
            {personalityAdapter.current.getDetectedType() && (
              <div className="flex items-center gap-2 px-3 py-1 bg-green-100 rounded-full">
                <Target className="w-4 h-4 text-green-600" />
                <span className="text-xs font-medium text-green-800">
                  {personalityAdapter.current.getDetectedType()?.name}
                </span>
              </div>
            )}

            {/* Conversation Stage */}
            {conversationFlow.current.getCurrentStage() && (
              <div className="flex items-center gap-2 px-3 py-1 bg-purple-100 rounded-full">
                <MessageCircle className="w-4 h-4 text-purple-600" />
                <span className="text-xs font-medium text-purple-800">
                  {conversationFlow.current.getCurrentStage()?.name}
                </span>
              </div>
            )}

            {/* Debug Toggle */}
            <button
              onClick={() => setDebugMode(!debugMode)}
              className={`p-2 rounded-lg transition-colors ${
                debugMode ? 'bg-yellow-100 text-yellow-600' : 'bg-gray-100 text-gray-600'
              }`}
              title="Toggle Debug Mode"
            >
              <Zap className="w-4 h-4" />
            </button>
            
            {/* Calendar Toggle */}
            <button
              onClick={() => setShowCalendar(!showCalendar)}
              className={`p-2 rounded-lg transition-colors ${
                showCalendar ? 'bg-blue-100 text-blue-600' : 'bg-gray-100 text-gray-600'
              }`}
              title="Toggle Calendar"
            >
              <Calendar className="w-4 h-4" />
            </button>

            {/* Action Buttons */}
            {session && (
              <div className="flex items-center gap-2 px-3 py-1 bg-green-100 rounded-full">
                <User className="w-4 h-4 text-green-600" />
                <span className="text-xs font-medium text-green-800">
                  {session.user?.email?.split('@')[0]}
                </span>
              </div>
            )}
            
            {onBackToDashboard && (
              <button
                onClick={onBackToDashboard}
                className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
              >
                Dashboard
              </button>
            )}
            
            {onLogout && (
              <button
                onClick={onLogout}
                className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
                title="Wyloguj się"
              >
                <LogOut className="w-4 h-4" />
              </button>
            )}
            
            <button
              onClick={resetChat}
              className="px-4 py-2 text-sm font-medium text-white bg-blue-600 rounded-lg hover:bg-blue-700 transition-colors"
            >
              Nowy Chat
            </button>
          </div>
        </div>
      </header>

      <div className="flex-1 flex">
        {/* Messages Area */}
        <div className={`flex-1 overflow-y-auto px-4 py-6 ${showCalendar ? 'pr-2' : ''}`}>
        <div className="max-w-4xl mx-auto space-y-4">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex ${message.role === 'user' ? 'justify-end' : 'justify-start'}`}
            >
              <div
                className={`max-w-xs md:max-w-md lg:max-w-lg xl:max-w-xl rounded-2xl px-4 py-3 shadow-sm ${
                  message.role === 'user'
                    ? 'bg-gray-700 text-white'
                    : 'bg-white text-gray-800 border border-gray-200'
                }`}
              >
                <p className="text-sm leading-relaxed whitespace-pre-wrap">
                  {message.content}
                </p>
                
                {/* Debug Info */}
                {debugMode && message.metadata && message.role === 'assistant' && (
                  <div className="mt-2 pt-2 border-t border-gray-200 text-xs text-gray-500">
                    {message.metadata.usedChunks && (
                      <p>Chunki: {message.metadata.usedChunks.join(', ')}</p>
                    )}
                    {message.metadata.personalityType && (
                      <p>Typ: {message.metadata.personalityType}</p>
                    )}
                    {message.metadata.conversationStage && (
                      <p>Etap: {message.metadata.conversationStage}</p>
                    )}
                    {message.metadata.socraticGuidance && (
                      <p>Metoda: {message.metadata.socraticGuidance}</p>
                    )}
                    {message.metadata.questionCount !== undefined && (
                      <p>Pytania: {message.metadata.questionCount}/2</p>
                    )}
                    {message.metadata.calendarIntent && (
                      <p>Kalendarz: {message.metadata.calendarIntent}</p>
                    )}
                    {message.metadata.detectedCrisis && (
                      <p className="text-red-500">⚠️ Wykryto kryzys</p>
                    )}
                  </div>
                )}
                
                <p className={`text-xs mt-2 ${
                  message.role === 'user' ? 'text-gray-300' : 'text-gray-500'
                }`}>
                  {formatTime(message.timestamp)}
                </p>
              </div>
            </div>
          ))}
          
          {/* Loading indicator */}
          {isLoading && (
            <div className="flex justify-start">
              <div className="bg-white border border-gray-200 rounded-2xl px-4 py-3 shadow-sm">
                <div className="flex items-center gap-2">
                  <Loader2 className="w-4 h-4 animate-spin text-blue-600" />
                  <span className="text-sm text-gray-600">ALEX analizuje...</span>
                </div>
              </div>
            </div>
          )}

          {/* Error message */}
          {error && (
            <div className="flex justify-center">
              <div className="bg-red-50 border border-red-200 rounded-2xl px-4 py-3 shadow-sm">
                <div className="flex items-center gap-2">
                  <AlertCircle className="w-4 h-4 text-red-600" />
                  <span className="text-sm text-red-700">{error}</span>
                </div>
              </div>
            </div>
          )}

          <div ref={messagesEndRef} />
        </div>
      </div>
        
        {/* Calendar Sidebar */}
        {showCalendar && (
          <div className="w-80 border-l border-gray-200 bg-gray-50 p-4 overflow-y-auto">
            <CalendarIntegration
              onEventAdded={handleCalendarEventAdded}
              onError={handleCalendarError}
            />
            {pendingCalendarEvent && (
              <div className="absolute -top-12 left-0 right-0 bg-blue-50 border border-blue-200 rounded-lg p-2 text-sm text-blue-800">
                💡 Odpowiedz "tak" aby dodać wydarzenie do kalendarza lub "nie" aby anulować
              </div>
            )}
          </div>
        )}
      </div>

      {/* Input Area */}
      <div className="bg-white border-t border-gray-200 px-4 py-4">
        <div className="max-w-4xl mx-auto">
          <div className="flex items-end gap-3">
            <div className="flex-1">
              <input
                ref={inputRef}
                type="text"
                value={inputValue}
                onChange={(e) => setInputValue(e.target.value)}
                onKeyPress={handleKeyPress}
                placeholder="Napisz swoją wiadomość..."
                disabled={isLoading}
                className="w-full px-4 py-3 border border-gray-300 rounded-2xl focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent resize-none disabled:opacity-50 disabled:cursor-not-allowed"
              />
            </div>
            <button
              onClick={sendMessage}
              disabled={!inputValue.trim() || isLoading}
              className="p-3 bg-blue-600 text-white rounded-2xl hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-blue-500 focus:ring-offset-2 disabled:opacity-50 disabled:cursor-not-allowed transition-colors"
            >
              <Send className="w-5 h-5" />
            </button>
          </div>
          <p className="text-xs text-gray-500 mt-2 text-center">
            Naciśnij Enter, aby wysłać wiadomość • {debugMode ? 'Debug ON' : 'Debug OFF'} • Spróbuj: "spotkanie jutro o 15:00"
          </p>
        </div>
      </div>
    </div>
  );
};

export default AlexAgent;