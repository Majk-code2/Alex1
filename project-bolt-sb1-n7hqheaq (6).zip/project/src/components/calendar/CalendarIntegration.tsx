import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Plus, Settings, CheckCircle, AlertCircle, ExternalLink } from 'lucide-react';

interface CalendarIntegrationProps {
  onEventAdded?: (event: any) => void;
  onError?: (error: string) => void;
}

const CalendarIntegration: React.FC<CalendarIntegrationProps> = ({ onEventAdded, onError }) => {
  const [isAuthenticated, setIsAuthenticated] = useState(true); // Temporarily set to true to avoid auth flow
  const [isLoading, setIsLoading] = useState(false);
  const [upcomingEvents, setUpcomingEvents] = useState<any[]>([
    {
      summary: 'Przykładowe spotkanie',
      start: { dateTime: new Date(Date.now() + 86400000).toISOString() },
      htmlLink: '#'
    }
  ]); // Mock data
  const [showAddEvent, setShowAddEvent] = useState(false);
  const [eventText, setEventText] = useState('');

  useEffect(() => {
    // Google Calendar integration temporarily disabled due to browser compatibility
    console.log('Google Calendar integration is temporarily disabled');
  }, []);

  const handleLogin = () => {
    onError?.('Google Calendar integration is temporarily disabled');
  };

  const handleLogout = () => {
    onError?.('Google Calendar integration is temporarily disabled');
  };

  const loadUpcomingEvents = async () => {
    // Mock implementation
    console.log('Loading events - temporarily disabled');
  };

  const handleAddEvent = async () => {
    if (!eventText.trim()) return;

    setIsLoading(true);
    
    // Mock implementation - simulate adding event
    setTimeout(() => {
      onEventAdded?.({
        success: true,
        data: { summary: eventText },
        htmlLink: '#'
      });
      setEventText('');
      setShowAddEvent(false);
      setIsLoading(false);
    }, 1000);
  };

  const formatEventTime = (event: any) => {
    const start = new Date(event.start?.dateTime || event.start?.date);
    return start.toLocaleString('pl-PL', {
      weekday: 'short',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    });
  };

  if (!isAuthenticated) {
    return (
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="text-center">
          <Calendar className="w-12 h-12 text-blue-600 mx-auto mb-4" />
          <h3 className="text-lg font-semibold text-gray-900 mb-2">
            Połącz z Google Calendar
          </h3>
          <p className="text-gray-600 mb-4">
            Pozwól ALEX-owi dodawać wydarzenia do Twojego kalendarza
          </p>
          <button
            onClick={handleLogin}
            disabled={isLoading}
            className="px-6 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors"
          >
            {isLoading ? 'Łączę...' : 'Połącz z Google'}
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          <Calendar className="w-5 h-5 text-blue-600" />
          <h3 className="text-lg font-semibold text-gray-900">Google Calendar</h3>
          <CheckCircle className="w-4 h-4 text-green-500" />
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddEvent(!showAddEvent)}
            className="p-2 text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
            title="Dodaj wydarzenie"
          >
            <Plus className="w-4 h-4" />
          </button>
          <button
            onClick={handleLogout}
            className="p-2 text-gray-600 hover:bg-gray-50 rounded-lg transition-colors"
            title="Rozłącz"
          >
            <Settings className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Formularz dodawania wydarzenia */}
      {showAddEvent && (
        <div className="mb-4 p-4 bg-gray-50 rounded-lg">
          <h4 className="text-sm font-medium text-gray-900 mb-2">
            Dodaj wydarzenie językiem naturalnym
          </h4>
          <div className="flex gap-2">
            <input
              type="text"
              value={eventText}
              onChange={(e) => setEventText(e.target.value)}
              placeholder="np. 'Spotkanie z klientem jutro o 14:00' lub 'Trening w piątek o 18:00'"
              className="flex-1 px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              onKeyPress={(e) => e.key === 'Enter' && handleAddEvent()}
            />
            <button
              onClick={handleAddEvent}
              disabled={isLoading || !eventText.trim()}
              className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 disabled:opacity-50 transition-colors"
            >
              {isLoading ? 'Dodaję...' : 'Dodaj'}
            </button>
          </div>
          <p className="text-xs text-gray-500 mt-1">
            Przykłady: "jutro o 15:00", "w poniedziałek o 10:00", "za 2 godziny"
          </p>
        </div>
      )}

      {/* Nadchodzące wydarzenia */}
      <div>
        <h4 className="text-sm font-medium text-gray-900 mb-3 flex items-center gap-2">
          <Clock className="w-4 h-4" />
          Nadchodzące wydarzenia
        </h4>
        
        {upcomingEvents.length === 0 ? (
          <p className="text-gray-500 text-sm">Brak nadchodzących wydarzeń</p>
        ) : (
          <div className="space-y-2">
            {upcomingEvents.map((event, index) => (
              <div key={index} className="flex items-center justify-between p-3 bg-gray-50 rounded-lg">
                <div>
                  <p className="font-medium text-gray-900 text-sm">
                    {event.summary || 'Bez tytułu'}
                  </p>
                  <p className="text-xs text-gray-600">
                    {formatEventTime(event)}
                  </p>
                </div>
                {event.htmlLink && (
                  <a
                    href={event.htmlLink}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="p-1 text-blue-600 hover:bg-blue-50 rounded"
                    title="Otwórz w Google Calendar"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </a>
                )}
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
};

export default CalendarIntegration;