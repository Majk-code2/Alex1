import React, { useState, useEffect } from 'react';
import { 
  CheckCircle, 
  AlertTriangle, 
  XCircle, 
  RefreshCw, 
  Activity,
  Server,
  Database,
  Cpu,
  Wifi
} from 'lucide-react';
import { healthMonitor, HealthCheck, SystemHealth } from '../lib/health-monitor';
import { errorHandler } from '../lib/error-handler';

interface SystemStatusProps {
  showDetails?: boolean;
  autoRefresh?: boolean;
  refreshInterval?: number;
}

const SystemStatus: React.FC<SystemStatusProps> = ({
  showDetails = false,
  autoRefresh = true,
  refreshInterval = 30000
}) => {
  const [systemHealth, setSystemHealth] = useState<SystemHealth | null>(null);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [lastRefresh, setLastRefresh] = useState<Date | null>(null);

  useEffect(() => {
    // Uruchom monitoring
    healthMonitor.startMonitoring(refreshInterval);

    // Dodaj listener na zmiany stanu
    const handleHealthChange = (health: SystemHealth) => {
      setSystemHealth(health);
      setLastRefresh(new Date());
    };

    healthMonitor.addListener(handleHealthChange);

    // Cleanup
    return () => {
      healthMonitor.removeListener(handleHealthChange);
      if (!autoRefresh) {
        healthMonitor.stopMonitoring();
      }
    };
  }, [autoRefresh, refreshInterval]);

  const handleManualRefresh = async () => {
    setIsRefreshing(true);
    try {
      // Wymuszenie sprawdzenia
      healthMonitor.stopMonitoring();
      healthMonitor.startMonitoring(refreshInterval);
    } catch (error) {
      errorHandler.handleError(error as Error, {
        component: 'SystemStatus',
        action: 'manualRefresh',
        timestamp: new Date()
      });
    } finally {
      setIsRefreshing(false);
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'healthy':
        return <CheckCircle className="w-4 h-4 text-green-500" />;
      case 'degraded':
        return <AlertTriangle className="w-4 h-4 text-yellow-500" />;
      case 'unhealthy':
        return <XCircle className="w-4 h-4 text-red-500" />;
      default:
        return <Activity className="w-4 h-4 text-gray-400" />;
    }
  };

  const getServiceIcon = (name: string) => {
    if (name.includes('Backend')) return <Server className="w-4 h-4" />;
    if (name.includes('Database')) return <Database className="w-4 h-4" />;
    if (name.includes('Frontend')) return <Cpu className="w-4 h-4" />;
    if (name.includes('API')) return <Wifi className="w-4 h-4" />;
    return <Activity className="w-4 h-4" />;
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'healthy': return 'text-green-600 bg-green-50 border-green-200';
      case 'degraded': return 'text-yellow-600 bg-yellow-50 border-yellow-200';
      case 'unhealthy': return 'text-red-600 bg-red-50 border-red-200';
      default: return 'text-gray-600 bg-gray-50 border-gray-200';
    }
  };

  if (!systemHealth) {
    return (
      <div className="flex items-center gap-2 text-sm text-gray-500">
        <Activity className="w-4 h-4 animate-pulse" />
        <span>Sprawdzanie stanu systemu...</span>
      </div>
    );
  }

  // Kompaktowy widok
  if (!showDetails) {
    return (
      <div className="flex items-center gap-2">
        {getStatusIcon(systemHealth.overall)}
        <span className={`text-sm font-medium ${
          systemHealth.overall === 'healthy' ? 'text-green-600' :
          systemHealth.overall === 'degraded' ? 'text-yellow-600' :
          'text-red-600'
        }`}>
          {systemHealth.overall === 'healthy' ? 'System OK' :
           systemHealth.overall === 'degraded' ? 'Ograniczona funkcjonalność' :
           'Problemy z systemem'}
        </span>
        <button
          onClick={handleManualRefresh}
          disabled={isRefreshing}
          className="p-1 text-gray-400 hover:text-gray-600 transition-colors"
          title="Odśwież status"
        >
          <RefreshCw className={`w-3 h-3 ${isRefreshing ? 'animate-spin' : ''}`} />
        </button>
      </div>
    );
  }

  // Szczegółowy widok
  return (
    <div className="bg-white rounded-lg border border-gray-200 p-4">
      <div className="flex items-center justify-between mb-4">
        <div className="flex items-center gap-2">
          {getStatusIcon(systemHealth.overall)}
          <h3 className="text-lg font-semibold text-gray-900">Status Systemu</h3>
        </div>
        <div className="flex items-center gap-2">
          {lastRefresh && (
            <span className="text-xs text-gray-500">
              Ostatnia aktualizacja: {lastRefresh.toLocaleTimeString()}
            </span>
          )}
          <button
            onClick={handleManualRefresh}
            disabled={isRefreshing}
            className="p-2 text-gray-400 hover:text-gray-600 transition-colors"
            title="Odśwież status"
          >
            <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
          </button>
        </div>
      </div>

      {/* Ogólny status */}
      <div className={`p-3 rounded-lg border mb-4 ${getStatusColor(systemHealth.overall)}`}>
        <div className="flex items-center gap-2">
          {getStatusIcon(systemHealth.overall)}
          <span className="font-medium">
            {systemHealth.overall === 'healthy' ? 'Wszystkie systemy działają prawidłowo' :
             systemHealth.overall === 'degraded' ? 'Niektóre funkcje mogą być ograniczone' :
             'Wykryto problemy z systemem'}
          </span>
        </div>
      </div>

      {/* Szczegóły poszczególnych serwisów */}
      <div className="space-y-2">
        {systemHealth.checks.map((check, index) => (
          <div
            key={index}
            className="flex items-center justify-between p-3 bg-gray-50 rounded-lg"
          >
            <div className="flex items-center gap-3">
              {getServiceIcon(check.name)}
              <div>
                <div className="flex items-center gap-2">
                  {getStatusIcon(check.status)}
                  <span className="font-medium text-gray-900">{check.name}</span>
                </div>
                {check.error && (
                  <p className="text-xs text-red-600 mt-1">{check.error}</p>
                )}
              </div>
            </div>
            
            <div className="text-right">
              {check.responseTime && (
                <div className="text-xs text-gray-500">
                  {check.responseTime}ms
                </div>
              )}
              <div className="text-xs text-gray-400">
                {check.lastCheck.toLocaleTimeString()}
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Statystyki błędów */}
      <ErrorStats />
    </div>
  );
};

// Komponent statystyk błędów
const ErrorStats: React.FC = () => {
  const [stats, setStats] = useState(errorHandler.getErrorStats());

  useEffect(() => {
    const interval = setInterval(() => {
      setStats(errorHandler.getErrorStats());
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  if (stats.total === 0) {
    return null;
  }

  return (
    <div className="mt-4 pt-4 border-t border-gray-200">
      <h4 className="text-sm font-medium text-gray-900 mb-2">Ostatnie błędy</h4>
      <div className="grid grid-cols-2 gap-2 text-xs">
        <div className="bg-red-50 p-2 rounded">
          <span className="text-red-600 font-medium">Krytyczne: </span>
          <span className="text-red-800">{stats.bySeverity.critical || 0}</span>
        </div>
        <div className="bg-yellow-50 p-2 rounded">
          <span className="text-yellow-600 font-medium">Ostrzeżenia: </span>
          <span className="text-yellow-800">{stats.bySeverity.medium || 0}</span>
        </div>
      </div>
    </div>
  );
};

export default SystemStatus;