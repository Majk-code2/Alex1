import React, { useState, useEffect } from 'react';
import { 
  BarChart3, 
  MessageSquare, 
  Clock, 
  TrendingUp, 
  Settings, 
  Activity,
  Users,
  Zap,
  CheckCircle,
  AlertTriangle,
  RefreshCw,
  ArrowLeft,
  Server,
  Database,
  Cpu,
  LogOut,
  User
} from 'lucide-react';
import type { Session } from '@supabase/supabase-js';

interface DashboardStats {
  totalMessages: number;
  todayMessages: number;
  avgResponseTime: number;
  apiStatus: 'connected' | 'error' | 'checking';
  uptime: string;
}

interface Message {
  id: string;
  role: 'user' | 'assistant';
  content: string;
  timestamp: Date;
}

interface DashboardProps {
  messages: Message[];
  onBackToChat: () => void;
  apiStatus: 'unknown' | 'checking' | 'connected' | 'error';
  onCheckApiConnection: () => void;
  session?: Session | null;
  onLogout?: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ 
  messages, 
  onBackToChat, 
  apiStatus,
  onCheckApiConnection,
  session,
  onLogout
}) => {
  const [stats, setStats] = useState<DashboardStats>({
    totalMessages: 0,
    todayMessages: 0,
    avgResponseTime: 0,
    apiStatus: 'checking',
    uptime: '0m'
  });

  const [startTime] = useState(new Date());

  useEffect(() => {
    calculateStats();
    const interval = setInterval(updateUptime, 60000); // Update every minute
    return () => clearInterval(interval);
  }, [messages]);

  const calculateStats = () => {
    const today = new Date();
    today.setHours(0, 0, 0, 0);
    
    const todayMessages = messages.filter(msg => 
      msg.timestamp >= today
    ).length;

    // Calculate average response time (mock data for now)
    const avgResponseTime = Math.random() * 2000 + 500; // 500-2500ms

    setStats(prev => ({
      ...prev,
      totalMessages: messages.length,
      todayMessages,
      avgResponseTime,
      apiStatus: apiStatus as any
    }));
  };

  const updateUptime = () => {
    const now = new Date();
    const diff = now.getTime() - startTime.getTime();
    const minutes = Math.floor(diff / 60000);
    const hours = Math.floor(minutes / 60);
    const days = Math.floor(hours / 24);

    let uptime = '';
    if (days > 0) uptime += `${days}d `;
    if (hours % 24 > 0) uptime += `${hours % 24}h `;
    uptime += `${minutes % 60}m`;

    setStats(prev => ({ ...prev, uptime }));
  };

  const getRecentActivity = () => {
    return messages
      .slice(-5)
      .reverse()
      .map(msg => ({
        ...msg,
        preview: msg.content.substring(0, 50) + (msg.content.length > 50 ? '...' : '')
      }));
  };

  const StatCard: React.FC<{
    title: string;
    value: string | number;
    icon: React.ReactNode;
    trend?: string;
    color: string;
  }> = ({ title, value, icon, trend, color }) => (
    <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-shadow">
      <div className="flex items-center justify-between">
        <div>
          <p className="text-sm font-medium text-gray-600">{title}</p>
          <p className="text-2xl font-bold text-gray-900 mt-1">{value}</p>
          {trend && (
            <p className="text-sm text-green-600 mt-1 flex items-center gap-1">
              <TrendingUp className="w-3 h-3" />
              {trend}
            </p>
          )}
        </div>
        <div className={`p-3 rounded-lg ${color}`}>
          {icon}
        </div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-4">
            <button
              onClick={onBackToChat}
              className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-gray-700 bg-gray-100 rounded-lg hover:bg-gray-200 transition-colors"
            >
              <ArrowLeft className="w-4 h-4" />
              Powrót do chatu
            </button>
            <div>
              <h1 className="text-2xl font-bold text-gray-900">ALEX Dashboard</h1>
              <p className="text-sm text-gray-600">Panel zarządzania coach'em anty-prokrastynacyjnym</p>
            </div>
          </div>
          <div className="flex items-center gap-3">
            {/* Status użytkownika */}
            {session ? (
              <div className="flex items-center gap-2 px-3 py-1 bg-green-100 rounded-full">
                <User className="w-4 h-4 text-green-600" />
                <span className="text-xs font-medium text-green-800">
                  {session.user?.email?.split('@')[0]}
                </span>
              </div>
            ) : (
              <div className="flex items-center gap-2 px-3 py-1 bg-gray-100 rounded-full">
                <User className="w-4 h-4 text-gray-600" />
                <span className="text-xs font-medium text-gray-800">Gość</span>
              </div>
            )}
            
            <div className={`flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium ${
              apiStatus === 'connected' ? 'bg-green-100 text-green-800' :
              apiStatus === 'checking' ? 'bg-yellow-100 text-yellow-800' :
              apiStatus === 'error' ? 'bg-red-100 text-red-800' :
              'bg-gray-100 text-gray-800'
            }`}>
              <div className={`w-2 h-2 rounded-full ${
                apiStatus === 'connected' ? 'bg-green-500' :
                apiStatus === 'checking' ? 'bg-yellow-500 animate-pulse' :
                apiStatus === 'error' ? 'bg-red-500' :
                'bg-gray-400'
              }`} />
              {apiStatus === 'connected' ? 'API Połączone' :
               apiStatus === 'checking' ? 'Sprawdzam API...' :
               apiStatus === 'error' ? 'Błąd API' :
               'API Nieznane'}
            </div>
            {apiStatus === 'error' && (
              <button
                onClick={onCheckApiConnection}
                className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
                title="Sprawdź połączenie API"
              >
                <RefreshCw className="w-4 h-4" />
              </button>
            )}
            
            {onLogout && (
              <button
                onClick={onLogout}
                className="p-2 text-gray-600 hover:text-gray-800 hover:bg-gray-100 rounded-lg transition-colors"
                title="Wyloguj się"
              >
                <LogOut className="w-4 h-4" />
              </button>
            )}
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="p-6">
        <div className="max-w-7xl mx-auto space-y-6">
          {/* Stats Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            <StatCard
              title="Wszystkie wiadomości"
              value={stats.totalMessages}
              icon={<MessageSquare className="w-6 h-6 text-blue-600" />}
              color="bg-blue-100"
            />
            <StatCard
              title="Dzisiejsze wiadomości"
              value={stats.todayMessages}
              icon={<Clock className="w-6 h-6 text-green-600" />}
              trend="+12% vs wczoraj"
              color="bg-green-100"
            />
            <StatCard
              title="Śr. czas odpowiedzi"
              value={`${Math.round(stats.avgResponseTime)}ms`}
              icon={<Zap className="w-6 h-6 text-yellow-600" />}
              color="bg-yellow-100"
            />
            <StatCard
              title="Czas działania"
              value={stats.uptime}
              icon={<Activity className="w-6 h-6 text-purple-600" />}
              color="bg-purple-100"
            />
          </div>

          {/* Charts and Activity */}
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* API Status */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Status Systemu</h3>
                <Settings className="w-5 h-5 text-gray-400" />
              </div>
              <div className="space-y-4">
                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    {apiStatus === 'connected' ? (
                      <CheckCircle className="w-5 h-5 text-green-500" />
                    ) : (
                      <AlertTriangle className="w-5 h-5 text-red-500" />
                    )}
                    <div>
                      <p className="font-medium text-gray-900">Anthropic Claude API</p>
                      <p className="text-sm text-gray-600">
                        {apiStatus === 'connected' ? 'Połączenie aktywne' : 
                         apiStatus === 'checking' ? 'Sprawdzanie połączenia...' :
                         'Brak połączenia'}
                      </p>
                    </div>
                  </div>
                  <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                    apiStatus === 'connected' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
                  }`}>
                    {apiStatus === 'connected' ? 'Online' : 'Offline'}
                  </span>
                </div>

                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Server className="w-5 h-5 text-blue-500" />
                    <div>
                      <p className="font-medium text-gray-900">Backend Server</p>
                      <p className="text-sm text-gray-600">Node.js + Express</p>
                    </div>
                  </div>
                  <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                    Online
                  </span>
                </div>

                <div className="flex items-center justify-between p-4 bg-gray-50 rounded-lg">
                  <div className="flex items-center gap-3">
                    <Cpu className="w-5 h-5 text-purple-500" />
                    <div>
                      <p className="font-medium text-gray-900">Frontend App</p>
                      <p className="text-sm text-gray-600">React + Vite</p>
                    </div>
                  </div>
                  <span className="px-2 py-1 text-xs font-medium rounded-full bg-green-100 text-green-800">
                    Online
                  </span>
                </div>
              </div>
            </div>

            {/* Recent Activity */}
            <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between mb-4">
                <h3 className="text-lg font-semibold text-gray-900">Ostatnia Aktywność</h3>
                <Activity className="w-5 h-5 text-gray-400" />
              </div>
              <div className="space-y-3">
                {getRecentActivity().length > 0 ? (
                  getRecentActivity().map((msg) => (
                    <div key={msg.id} className="flex items-start gap-3 p-3 bg-gray-50 rounded-lg">
                      <div className={`w-8 h-8 rounded-full flex items-center justify-center ${
                        msg.role === 'user' ? 'bg-blue-100' : 'bg-green-100'
                      }`}>
                        {msg.role === 'user' ? (
                          <Users className="w-4 h-4 text-blue-600" />
                        ) : (
                          <MessageSquare className="w-4 h-4 text-green-600" />
                        )}
                      </div>
                      <div className="flex-1 min-w-0">
                        <p className="text-sm font-medium text-gray-900">
                          {msg.role === 'user' ? 'Użytkownik' : 'ALEX'}
                        </p>
                        <p className="text-sm text-gray-600 truncate">{msg.preview}</p>
                        <p className="text-xs text-gray-500 mt-1">
                          {msg.timestamp.toLocaleTimeString('pl-PL')}
                        </p>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8 text-gray-500">
                    <MessageSquare className="w-12 h-12 mx-auto mb-3 text-gray-300" />
                    <p>Brak aktywności</p>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Performance Metrics */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <div className="flex items-center justify-between mb-6">
              <h3 className="text-lg font-semibold text-gray-900">Metryki Wydajności</h3>
              <BarChart3 className="w-5 h-5 text-gray-400" />
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-3 bg-blue-100 rounded-full flex items-center justify-center">
                  <Zap className="w-8 h-8 text-blue-600" />
                </div>
                <p className="text-2xl font-bold text-gray-900">{Math.round(stats.avgResponseTime)}ms</p>
                <p className="text-sm text-gray-600">Średni czas odpowiedzi</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-3 bg-green-100 rounded-full flex items-center justify-center">
                  <CheckCircle className="w-8 h-8 text-green-600" />
                </div>
                <p className="text-2xl font-bold text-gray-900">99.9%</p>
                <p className="text-sm text-gray-600">Dostępność systemu</p>
              </div>
              <div className="text-center">
                <div className="w-16 h-16 mx-auto mb-3 bg-purple-100 rounded-full flex items-center justify-center">
                  <TrendingUp className="w-8 h-8 text-purple-600" />
                </div>
                <p className="text-2xl font-bold text-gray-900">{stats.totalMessages}</p>
                <p className="text-sm text-gray-600">Łączne interakcje</p>
              </div>
            </div>
          </div>

          {/* Quick Actions */}
          <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Szybkie Akcje</h3>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <button
                onClick={onCheckApiConnection}
                className="flex items-center gap-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <RefreshCw className="w-5 h-5 text-blue-600" />
                <div className="text-left">
                  <p className="font-medium text-gray-900">Sprawdź API</p>
                  <p className="text-sm text-gray-600">Test połączenia z Claude</p>
                </div>
              </button>
              
              <button
                onClick={onBackToChat}
                className="flex items-center gap-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors"
              >
                <MessageSquare className="w-5 h-5 text-green-600" />
                <div className="text-left">
                  <p className="font-medium text-gray-900">Nowa Rozmowa</p>
                  <p className="text-sm text-gray-600">Rozpocznij chat z ALEX</p>
                </div>
              </button>

              <button className="flex items-center gap-3 p-4 border border-gray-200 rounded-lg hover:bg-gray-50 transition-colors">
                <Settings className="w-5 h-5 text-purple-600" />
                <div className="text-left">
                  <p className="font-medium text-gray-900">Ustawienia</p>
                  <p className="text-sm text-gray-600">Konfiguracja systemu</p>
                </div>
              </button>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Dashboard;