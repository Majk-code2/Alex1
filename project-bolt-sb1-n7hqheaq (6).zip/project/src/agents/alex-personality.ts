import { PersonalityType, ResponseStyle } from './alex-config';
import ALEX_CONFIG from './alex-config';

export class PersonalityAdapter {
  private detectedType: PersonalityType | null = null;
  private confidence: number = 0;

  detectPersonality(userMessage: string, conversationHistory: string[]): PersonalityType | null {
    const message = userMessage.toLowerCase();
    const history = conversationHistory.join(' ').toLowerCase();
    
    // Daj większą wagę aktualnej wiadomości
    const recentHistory = conversationHistory.slice(-4).join(' ').toLowerCase();
    const fullText = `${message} ${recentHistory}`;

    let bestMatch: PersonalityType | null = null;
    let highestScore = 0;

    for (const type of ALEX_CONFIG.personalityTypes) {
      let score = 0;
      
      // Sprawdź triggery w aktualnej wiadomości (najwyższa waga)
      for (const trigger of type.triggers) {
        if (message.includes(trigger.toLowerCase())) {
          score += 5; // Zwiększona waga dla aktualnej wiadomości
        }
      }

      // Sprawdź triggery w ostatnich wiadomościach (średnia waga)
      for (const trigger of type.triggers) {
        if (recentHistory.includes(trigger.toLowerCase())) {
          score += 2;
        }
      }

      // Sprawdź czy używa słów których ten typ unika (odejmij punkty)
      for (const avoidWord of type.avoidWords) {
        if (fullText.includes(avoidWord.toLowerCase())) {
          score -= 3; // Większa kara za avoid words
        }
      }

      if (score > highestScore) {
        highestScore = score;
        bestMatch = type;
      }
    }

    // Zwiększony próg pewności dla lepszego rozróżnienia
    if (highestScore >= 4) {
      this.detectedType = bestMatch;
      this.confidence = Math.min(highestScore / 15, 1);
      return bestMatch;
    }

    return null;
  }

  adaptResponse(baseResponse: string, personalityType: PersonalityType | null): string {
    if (!personalityType) {
      return baseResponse;
    }

    const style = personalityType.responseStyle;
    let adaptedResponse = baseResponse;

    // Dostosuj ton
    switch (style.tone) {
      case 'directive':
        adaptedResponse = this.makeDirective(adaptedResponse);
        break;
      case 'supportive':
        adaptedResponse = this.makeSupportive(adaptedResponse);
        break;
      case 'flexible':
        adaptedResponse = this.makeFlexible(adaptedResponse);
        break;
    }

    // Dostosuj strukturę
    switch (style.structure) {
      case 'options':
        adaptedResponse = this.addOptions(adaptedResponse);
        break;
      case 'steps':
        adaptedResponse = this.addStructure(adaptedResponse);
        break;
      case 'encouragement':
        adaptedResponse = this.addEncouragement(adaptedResponse);
        break;
    }

    // Usuń słowa których ten typ unika
    for (const avoidWord of personalityType.avoidWords) {
      const regex = new RegExp(`\\b${avoidWord}\\b`, 'gi');
      adaptedResponse = adaptedResponse.replace(regex, this.getAlternative(avoidWord));
    }

    return adaptedResponse;
  }

  private makeDirective(response: string): string {
    return response.replace(/może spróbuj/gi, 'spróbuj')
                  .replace(/co powiesz na/gi, 'zrób to:');
  }

  private makeSupportive(response: string): string {
    const supportivePhrases = [
      'Rozumiem że to trudne. ',
      'To normalne uczucie. ',
      'Jesteś na dobrej drodze. '
    ];
    const randomPhrase = supportivePhrases[Math.floor(Math.random() * supportivePhrases.length)];
    return randomPhrase + response;
  }

  private makeFlexible(response: string): string {
    return response.replace(/zrób to/gi, 'możesz spróbować')
                  .replace(/musisz/gi, 'możesz')
                  .replace(/powinieneś/gi, 'mógłbyś');
  }

  private addOptions(response: string): string {
    const options = [
      '\n\nMasz 3 opcje:',
      '1. Zacznij od najmniejszego kroku',
      '2. Zrób przerwę i wróć za 15 minut', 
      '3. Poproś kogoś o wsparcie'
    ];
    return response + options.join('\n');
  }

  private addStructure(response: string): string {
    if (!response.includes('1.')) {
      return response + '\n\nKrok po kroku:\n1. Zacznij od 5 minut\n2. Zrób krótką przerwę\n3. Oceń jak się czujesz';
    }
    return response;
  }

  private addEncouragement(response: string): string {
    const encouragements = [
      ' Pamiętaj - postęp to nie perfekcja!',
      ' Każdy mały krok się liczy.',
      ' Jesteś na dobrej drodze, nawet jeśli tak nie czujesz.'
    ];
    const randomEncouragement = encouragements[Math.floor(Math.random() * encouragements.length)];
    return response + randomEncouragement;
  }

  private getAlternative(avoidWord: string): string {
    const alternatives: { [key: string]: string } = {
      'musisz': 'możesz',
      'powinieneś': 'mógłbyś',
      'trzeba': 'warto',
      'masz obowiązek': 'masz możliwość',
      'sztywno': 'systematycznie',
      'dokładnie': 'starannie',
      'precyzyjnie': 'uważnie',
      'szybko': 'w swoim tempie',
      'byle jak': 'na początek',
      'nie przejmuj się': 'bądź łagodny dla siebie'
    };
    return alternatives[avoidWord.toLowerCase()] || avoidWord;
  }

  getDetectedType(): PersonalityType | null {
    return this.detectedType;
  }

  getConfidence(): number {
    return this.confidence;
  }

  // Metoda do resetowania wykrytego typu (np. na początku nowej sesji)
  reset(): void {
    this.detectedType = null;
    this.confidence = 0;
  }
}

export default PersonalityAdapter;