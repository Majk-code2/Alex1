export interface AlexConfig {
  maxChunksPerResponse: number;
  responseMaxLength: number;
  crisisKeywords: string[];
  personalityTypes: PersonalityType[];
  conversationFlow: ConversationStage[];
}

export interface PersonalityType {
  id: 'buntownik' | 'marzyciel' | 'perfekcjonista';
  name: string;
  triggers: string[];
  avoidWords: string[];
  responseStyle: ResponseStyle;
}

export interface ResponseStyle {
  tone: 'directive' | 'supportive' | 'flexible';
  structure: 'options' | 'steps' | 'encouragement';
  maxSentences: number;
}

export interface ConversationStage {
  id: string;
  name: string;
  triggers: string[];
  requiredChunks: string[];
  nextStages: string[];
}

export const ALEX_CONFIG: AlexConfig = {
  maxChunksPerResponse: 2,
  responseMaxLength: 300,
  crisisKeywords: [
    'wszystko się wali',
    'nie mogę się zmusić', 
    'paraliż',
    'blokada',
    'chcę się poddać',
    'nie mam siły',
    'to nie ma sensu',
    'jestem do niczego',
    'nie dam rady'
  ],
  personalityTypes: [
    {
      id: 'buntownik',
      name: 'Buntownik',
      triggers: [
        'nie lubię gdy mi mówią',
        'nie chcę systemu', 
        'po swojemu',
        'nienawidzę deadline',
        'zmuszanie',
        'kontrola',
        'narzucanie',
        'moja sprawa',
        'czuję się zmuszany',
        'nie będę robił bo kazali',
        'sam zdecyduję kiedy'
      ],
      avoidWords: ['musisz', 'powinieneś', 'trzeba', 'masz obowiązek', 'nakazuję', 'wymagam'],
      responseStyle: {
        tone: 'flexible',
        structure: 'options',
        maxSentences: 3
      }
    },
    {
      id: 'marzyciel', 
      name: 'Marzyciel',
      triggers: [
        'boję się że',
        'co jeśli się nie uda',
        'ludzie będą się śmiać',
        'czekam na idealny moment',
        'może lepiej poczekać',
        'nie jestem gotowy',
        'za trudne dla mnie',
        'może nie dam rady',
        'strach przed oceną',
        'bezpieczny moment',
        'nie chcę zawieść',
        'co jeśli wyjdzie źle',
        'może powinienem poczekać'
      ],
      avoidWords: ['szybko', 'natychmiast', 'pilne', 'deadline', 'presja'],
      responseStyle: {
        tone: 'supportive',
        structure: 'steps',
        maxSentences: 4
      }
    },
    {
      id: 'perfekcjonista',
      name: 'Perfekcjonista', 
      triggers: [
        'musi być perfekcyjne',
        'wszystko albo nic',
        'nie lubię robić na szybko',
        'póki nie będę idealnie przygotowany',
        'nie zacznę póki',
        'wysokie standardy',
        'nie może być byle jak',
        'tylko najlepsze',
        'idealna wersja',
        'bez błędów',
        'nie jest wystarczająco dobre',
        'musi być na najwyższym poziomie'
      ],
      avoidWords: ['byle jak', 'na szybko', 'wystarczająco dobre', 'nie przejmuj się', 'szybko zrób'],
      responseStyle: {
        tone: 'supportive',
        structure: 'encouragement', 
        maxSentences: 4
      }
    }
  ],
  conversationFlow: [
    {
      id: 'greeting',
      name: 'Powitanie',
      triggers: ['cześć', 'hej', 'witaj', 'dzień dobry'],
      requiredChunks: [],
      nextStages: ['problem_identification', 'goal_setting']
    },
    {
      id: 'problem_identification',
      name: 'Identyfikacja problemu',
      triggers: ['problem', 'nie mogę', 'trudność', 'prokrastynauje'],
      requiredChunks: ['FUNDAMENT_04_Dziennik_prokrastynacji'],
      nextStages: ['solution_offering', 'crisis_intervention']
    },
    {
      id: 'goal_setting',
      name: 'Ustalanie celów',
      triggers: ['cel', 'chcę osiągnąć', 'planuję', 'marzę'],
      requiredChunks: ['FUNDAMENT_01_Glowna_wartosc', 'FUNDAMENT_02_Test_energii'],
      nextStages: ['action_planning', 'system_setup']
    },
    {
      id: 'crisis_intervention',
      name: 'Interwencja kryzysowa',
      triggers: ['wszystko się wali', 'nie mam siły', 'paraliż'],
      requiredChunks: ['CRISIS_01_Protokol_emocjonalny'],
      nextStages: ['emotional_support', 'gradual_recovery']
    },
    {
      id: 'system_setup',
      name: 'Ustawianie systemu',
      triggers: ['system', 'rutyna', 'organizacja', 'plan'],
      requiredChunks: ['FUEL_01_5_zwyciestwo_dziennie', 'FOKUS_01_System_3_rzeczy'],
      nextStages: ['habit_building', 'progress_tracking']
    }
  ]
};

export default ALEX_CONFIG;