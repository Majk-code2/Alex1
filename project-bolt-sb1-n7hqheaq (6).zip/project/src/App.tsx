import React, { useState, useRef, useEffect } from 'react';
import { MessageCircle, Settings, Loader2 } from 'lucide-react';
import Dashboard from './components/Dashboard';
import AlexAgent from './components/alex/AlexAgent';
import Auth from './components/Auth';
import { ErrorBoundary } from './components/ErrorBoundary';
import SystemStatus from './components/SystemStatus';
import { healthMonitor } from './lib/health-monitor';
import { RetryManager, GracefulDegradation } from './lib/resilience';
import { UserManager } from './lib/user-manager';
import { supabase } from './lib/supabase';
import type { Session } from '@supabase/supabase-js';

function App() {
  const [currentView, setCurrentView] = useState<'chat' | 'dashboard'>('chat');
  const [apiStatus, setApiStatus] = useState<'unknown' | 'checking' | 'connected' | 'error'>('unknown');
  const [session, setSession] = useState<Session | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isGuestMode, setIsGuestMode] = useState(false);
  const [userId, setUserId] = useState<string>('');

  // TYMCZASOWO: Zawsze używaj trybu gościa
  const forceGuestMode = true;

  // Uruchom monitoring systemu
  useEffect(() => {
    healthMonitor.startMonitoring(30000); // Co 30 sekund
    
    return () => {
      healthMonitor.stopMonitoring();
    };
  }, []);

  // Sprawdź połączenie z API przy starcie
  useEffect(() => {
    checkApiConnection();
  }, []);

  // Sprawdź sesję użytkownika i inicjalizuj UserManager
  useEffect(() => {
    const initializeUser = async () => {
      try {
        // TYMCZASOWO: Pomiń sprawdzanie Supabase
        if (forceGuestMode) {
          const userManager = UserManager.getInstance();
          const currentUserId = await userManager.getCurrentUserId();
          setUserId(currentUserId);
          setIsGuestMode(true);
          setIsLoading(false);
          return;
        }

        // Sprawdź czy użytkownik wybrał wcześniej tryb gościa
        const hasSkippedAuth = localStorage.getItem('alex-skip-auth') === 'true';
        
        if (hasSkippedAuth) {
          // Użytkownik wcześniej wybrał tryb gościa - przejdź od razu do aplikacji
          const userManager = UserManager.getInstance();
          const currentUserId = await userManager.getCurrentUserId();
          setUserId(currentUserId);
          setIsGuestMode(true);
          setIsLoading(false);
          return;
        }

        // Sprawdź sesję Supabase
        try {
          const { data: { session: supabaseSession } } = await supabase.auth.getSession();
          if (supabaseSession) {
            setSession(supabaseSession);
            setUserId(supabaseSession.user.id);
            setIsGuestMode(false);
            setIsLoading(false);
            return;
          }
        } catch (supabaseError) {
          console.warn('Supabase nie jest dostępny:', supabaseError);
        }

        // Brak sesji i nie wybrano trybu gościa - pokaż ekran logowania
        setSession(null);
        setIsGuestMode(false);
        setIsLoading(false);

      } catch (error) {
        console.error('Błąd inicjalizacji użytkownika:', error);
        // W przypadku błędu pokaż ekran logowania
        setSession(null);
        setIsGuestMode(false);
        setIsLoading(false);
      }
    };

    initializeUser();

    // Nasłuchuj zmian stanu autoryzacji Supabase
    let subscription: any = null;
    
    try {
      const {
        data: { subscription: authSubscription },
      } = supabase.auth.onAuthStateChange(async (_event, session) => {
        console.log('🔄 Auth state changed:', _event, session?.user?.email);
        
        if (session) {
          // Użytkownik się zalogował przez Google
          setSession(session);
          setUserId(session.user.id);
          setIsGuestMode(false);
          localStorage.setItem('alex-skip-auth', 'true'); // Zapamiętaj wybór
        } else {
          // Użytkownik się wylogował
          setSession(null);
          setIsGuestMode(false);
          localStorage.removeItem('alex-skip-auth');
          
          // Wygeneruj nowy ID gościa dla przyszłego użycia
          const userManager = UserManager.getInstance();
          const guestId = await userManager.getCurrentUserId();
          setUserId(guestId);
        }
        setIsLoading(false);
      });
      subscription = authSubscription;
    } catch (error) {
      console.warn('Nie można nasłuchiwać zmian auth:', error);
    }

    return () => {
      if (subscription) {
        subscription.unsubscribe();
      }
    };
  }, []);

  const checkApiConnection = async (): Promise<void> => {
    setApiStatus('checking');
    
    try {
      const { apiClient } = await import('./lib/api-client');
      const data = await apiClient.get('/api/health');
      
      if (data.status === 'success' || data.status === 'error') {
        setApiStatus('connected');
        console.log('✅ API Health Check Success:', data);
        if (data.status === 'error' && data.message) {
          console.warn('⚠️ Backend warning:', data.message);
        }
      } else {
        setApiStatus('error');
        console.error('API Health Check Error:', data.message || 'Nieznany błąd');
        if (data.fix) {
          console.error('Sugerowane rozwiązanie:', data.fix);
        }
      }
    } catch (error: any) {
      setApiStatus('error');
      console.error('API Health Check Failed:', error.message || error);
      
      // Sprawdź czy to błąd połączenia
      if (error.name === 'TypeError' ||
          error.message?.includes('Failed to fetch') || 
          error.message?.includes('ECONNREFUSED') || 
          error.message?.includes('fetch')) {
        console.error('🔧 BŁĄD POŁĄCZENIA: Backend server nie działa lub nie jest dostępny');
        console.error('💡 Rozwiązania:');
        console.error('   1. Uruchom auto-fix: npm run fix');
        console.error('   2. Lub uruchom backend ręcznie: npm run backend');
        console.error('   3. Sprawdź czy port 3002 nie jest zajęty');
        console.error('   4. Sprawdź czy plik .env-persistent zawiera prawidłowy ANTHROPIC_API_KEY');
      } else if (error.name === 'TimeoutError') {
        console.error('🔧 TIMEOUT: Backend server nie odpowiada w czasie');
        console.error('💡 Sprawdź czy backend się uruchamia poprawnie');
      }
    }
  };

  const handleAuthSuccess = () => {
    // Użytkownik wybrał tryb gościa
    localStorage.setItem('alex-skip-auth', 'true');
    
    // Inicjalizuj UserManager dla gościa
    const initializeGuest = async () => {
      const userManager = UserManager.getInstance();
      const guestId = await userManager.getCurrentUserId();
      setUserId(guestId);
      setIsGuestMode(true);
      setIsLoading(false);
    };
    
    initializeGuest();
  };

  const handleLogout = async () => {
    // Wyloguj z Supabase jeśli to możliwe
    try {
      const { error } = await supabase.auth.signOut();
      if (error) {
        console.error('Błąd wylogowania:', error);
      }
    } catch (error) {
      console.warn('Nie można wylogować z Supabase:', error);
    }
    
    // Wyczyść lokalną sesję i wróć do ekranu logowania
    localStorage.removeItem('alex-skip-auth');
    setSession(null);
    setIsGuestMode(false);
    setUserId('');
  };

  // Funkcja do resetowania stanu auth (dla debugowania)
  const resetAuthState = () => {
    localStorage.removeItem('alex-skip-auth');
    setSession(null);
    setIsGuestMode(false);
    setIsLoading(false);
  };

  // Dodaj przycisk reset w trybie development
  const isDevelopment = import.meta.env.DEV;
  
  // Debug: pokaż obecny stan
  if (isDevelopment) {
    console.log('🔍 Auth Debug State:', {
      session: !!session,
      isGuestMode,
      isLoading,
      userId: userId.slice(-8),
      hasSkippedAuth: localStorage.getItem('alex-skip-auth') === 'true'
    });
  }

  // Pokaż loader podczas inicjalizacji
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="w-8 h-8 animate-spin text-blue-600 mx-auto mb-4" />
          <p className="text-gray-600">Inicjalizacja ALEX...</p>
          <p className="text-xs text-gray-500 mt-2">Sprawdzanie sesji użytkownika...</p>
          {isDevelopment && (
            <button
              onClick={resetAuthState}
              className="mt-4 px-3 py-1 text-xs bg-red-100 text-red-600 rounded hover:bg-red-200"
            >
              [DEV] Reset Auth State
            </button>
          )}
        </div>
      </div>
    );
  }

  // ZAWSZE pokaż ekran logowania jeśli nie ma sesji I nie jest w trybie gościa
  if (!session && !isGuestMode) {
    console.log('🔍 Showing Auth screen - no session and not guest mode');
    return <Auth onAuthSuccess={handleAuthSuccess} />;
  }

  // Render based on current view
  if (currentView === 'dashboard') {
    return (
      <Dashboard
        messages={[]} // Dashboard will get its own message state
        onBackToChat={() => setCurrentView('chat')}
        apiStatus={apiStatus}
        onCheckApiConnection={checkApiConnection}
        session={session}
        onLogout={handleLogout}
      />
    );
  }

  // Default view is the new AlexAgent
  return (
    <ErrorBoundary>
      <div className="min-h-screen bg-gray-50">
        {/* Status bar */}
        <div className="bg-white border-b border-gray-200 px-4 py-2">
          <div className="max-w-7xl mx-auto flex items-center justify-between">
            <SystemStatus showDetails={false} />
            <div className="flex items-center gap-4">
              <div className="text-xs text-gray-500">
                ALEX Agent v1.0 - {session ? 'Zalogowany' : 'Tryb gościa'}
              </div>
              {session && (
                <div className="text-xs text-green-600">
                  {session.user?.email}
                </div>
              )}
              {!session && (
                <div className="text-xs text-gray-400">
                  ID: {userId.slice(-8)}
                </div>
              )}
            </div>
          </div>
        </div>
        
        <AlexAgent 
          onBackToDashboard={() => setCurrentView('dashboard')} 
          userId={userId}
          session={session}
          onLogout={handleLogout}
        />
      </div>
    </ErrorBoundary>
  );
}

export default App;