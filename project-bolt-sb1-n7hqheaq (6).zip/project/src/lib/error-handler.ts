export interface ErrorContext {
  component: string;
  action: string;
  timestamp: Date;
  userId?: string;
  metadata?: any;
}

export interface ErrorReport {
  id: string;
  error: Error;
  context: ErrorContext;
  severity: 'low' | 'medium' | 'high' | 'critical';
  recoverable: boolean;
  userMessage: string;
  technicalMessage: string;
}

export class ErrorHandler {
  private static instance: ErrorHandler;
  private errorQueue: ErrorReport[] = [];
  private maxQueueSize = 100;

  static getInstance(): ErrorHandler {
    if (!ErrorHandler.instance) {
      ErrorHandler.instance = new ErrorHandler();
    }
    return ErrorHandler.instance;
  }

  // Główna metoda obsługi błędów
  handleError(error: Error, context: ErrorContext): ErrorReport {
    const errorReport: ErrorReport = {
      id: this.generateErrorId(),
      error,
      context,
      severity: this.determineSeverity(error, context),
      recoverable: this.isRecoverable(error),
      userMessage: this.generateUserMessage(error, context),
      technicalMessage: this.generateTechnicalMessage(error, context)
    };

    // Dodaj do kolejki
    this.addToQueue(errorReport);

    // Loguj błąd
    this.logError(errorReport);

    // Wyślij powiadomienie jeśli krytyczny
    if (errorReport.severity === 'critical') {
      this.notifyCriticalError(errorReport);
    }

    return errorReport;
  }

  private determineSeverity(error: Error, context: ErrorContext): 'low' | 'medium' | 'high' | 'critical' {
    // API connection errors
    if (error.message.includes('ECONNREFUSED') || error.message.includes('fetch')) {
      return context.component === 'backend' ? 'critical' : 'high';
    }

    // Authentication errors
    if (error.message.includes('401') || error.message.includes('unauthorized')) {
      return 'high';
    }

    // Configuration errors
    if (error.message.includes('API_KEY') || error.message.includes('configuration')) {
      return 'medium';
    }

    // UI errors
    if (context.component.includes('component') || context.component.includes('UI')) {
      return 'low';
    }

    return 'medium';
  }

  private isRecoverable(error: Error): boolean {
    const recoverableErrors = [
      'ECONNREFUSED',
      'timeout',
      'rate limit',
      '429',
      '503',
      'network'
    ];

    return recoverableErrors.some(pattern => 
      error.message.toLowerCase().includes(pattern.toLowerCase())
    );
  }

  private generateUserMessage(error: Error, context: ErrorContext): string {
    if (error.message.includes('ECONNREFUSED')) {
      return 'Nie można połączyć się z serwerem. Sprawdź czy backend działa.';
    }

    if (error.message.includes('API_KEY')) {
      return 'Problem z kluczem API. Sprawdź konfigurację w pliku .env-persistent.';
    }

    if (error.message.includes('401')) {
      return 'Problem z autoryzacją. Sprawdź czy klucz API jest aktualny.';
    }

    if (error.message.includes('429')) {
      return 'Przekroczono limit zapytań. Spróbuj ponownie za chwilę.';
    }

    return 'Wystąpił nieoczekiwany błąd. Spróbuj odświeżyć stronę.';
  }

  private generateTechnicalMessage(error: Error, context: ErrorContext): string {
    return `[${context.component}:${context.action}] ${error.name}: ${error.message}\nStack: ${error.stack}`;
  }

  private generateErrorId(): string {
    return `err_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
  }

  private addToQueue(errorReport: ErrorReport): void {
    this.errorQueue.push(errorReport);
    
    // Ogranicz rozmiar kolejki
    if (this.errorQueue.length > this.maxQueueSize) {
      this.errorQueue.shift();
    }
  }

  private logError(errorReport: ErrorReport): void {
    const logLevel = this.getLogLevel(errorReport.severity);
    const message = `[${errorReport.severity.toUpperCase()}] ${errorReport.technicalMessage}`;
    
    console[logLevel](message);
    
    // W produkcji można dodać wysyłanie do zewnętrznego serwisu logowania
    if (process.env.NODE_ENV === 'production') {
      this.sendToExternalLogger(errorReport);
    }
  }

  private getLogLevel(severity: string): 'log' | 'warn' | 'error' {
    switch (severity) {
      case 'low': return 'log';
      case 'medium': return 'warn';
      case 'high':
      case 'critical': return 'error';
      default: return 'warn';
    }
  }

  private notifyCriticalError(errorReport: ErrorReport): void {
    // W przyszłości można dodać powiadomienia email, Slack, etc.
    console.error('🚨 CRITICAL ERROR DETECTED:', errorReport);
  }

  private sendToExternalLogger(errorReport: ErrorReport): void {
    // Placeholder dla zewnętrznych serwisów jak Sentry, LogRocket, etc.
    console.log('📤 Sending error to external logger:', errorReport.id);
  }

  // Publiczne metody dla komponentów
  getRecentErrors(limit: number = 10): ErrorReport[] {
    return this.errorQueue.slice(-limit);
  }

  clearErrors(): void {
    this.errorQueue = [];
  }

  getErrorStats(): { total: number; bySeverity: Record<string, number> } {
    const bySeverity = this.errorQueue.reduce((acc, error) => {
      acc[error.severity] = (acc[error.severity] || 0) + 1;
      return acc;
    }, {} as Record<string, number>);

    return {
      total: this.errorQueue.length,
      bySeverity
    };
  }
}

// Singleton instance
export const errorHandler = ErrorHandler.getInstance();

// Helper functions for components
export const handleApiError = (error: Error, action: string) => {
  return errorHandler.handleError(error, {
    component: 'api',
    action,
    timestamp: new Date()
  });
};

export const handleUIError = (error: Error, component: string, action: string) => {
  return errorHandler.handleError(error, {
    component: `ui-${component}`,
    action,
    timestamp: new Date()
  });
};