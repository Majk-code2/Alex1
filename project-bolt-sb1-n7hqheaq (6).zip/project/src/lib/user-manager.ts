export interface UserSession {
  userId: string;
  createdAt: Date;
  lastActive: Date;
  sessionCount: number;
  preferences: {
    theme?: 'light' | 'dark';
    language?: string;
    notifications?: boolean;
  };
}

export interface ConversationHistory {
  id: string;
  userId: string;
  messages: Array<{
    id: string;
    role: 'user' | 'assistant';
    content: string;
    timestamp: Date;
    metadata?: any;
  }>;
  createdAt: Date;
  updatedAt: Date;
  title?: string;
}

export class UserManager {
  private static instance: UserManager;
  private currentSession: UserSession | null = null;
  private storageKey = 'alex-user-session';
  private historyKey = 'alex-conversation-history';
  private maxHistoryItems = 50; // Maksymalnie 50 rozmów w historii

  static getInstance(): UserManager {
    if (!UserManager.instance) {
      UserManager.instance = new UserManager();
    }
    return UserManager.instance;
  }

  // Pobierz lub utwórz ID użytkownika
  async getCurrentUserId(): Promise<string> {
    // Sprawdź czy użytkownik jest zalogowany przez Supabase
    try {
      const { supabase } = await import('./supabase');
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session?.user) {
        // Użytkownik zalogowany - użyj jego ID
        return session.user.id;
      }
    } catch (error) {
      console.warn('Nie można sprawdzić sesji Supabase:', error);
    }

    // Fallback - użyj lokalnej sesji
    if (this.currentSession) {
      return this.currentSession.userId;
    }

    // Spróbuj załadować z localStorage
    const savedSession = this.loadSessionFromStorage();
    
    if (savedSession) {
      // Aktualizuj ostatnią aktywność
      savedSession.lastActive = new Date();
      savedSession.sessionCount += 1;
      this.currentSession = savedSession;
      this.saveSessionToStorage();
      return savedSession.userId;
    }

    // Utwórz nową sesję gościa
    const newSession = this.createNewSession();
    this.currentSession = newSession;
    this.saveSessionToStorage();
    
    return newSession.userId;
  }

  // Utwórz nową sesję użytkownika
  private createNewSession(): UserSession {
    const userId = this.generateUserId();
    
    return {
      userId,
      createdAt: new Date(),
      lastActive: new Date(),
      sessionCount: 1,
      preferences: {
        theme: 'light',
        language: 'pl',
        notifications: true
      }
    };
  }

  // Wygeneruj unikalny ID użytkownika
  private generateUserId(): string {
    const timestamp = Date.now();
    const random = Math.random().toString(36).substr(2, 9);
    const prefix = 'guest';
    
    return `${prefix}_${timestamp}_${random}`;
  }

  // Zapisz rozmowę do localStorage
  async saveConversation(messages: any[], title?: string): Promise<string> {
    const userId = await this.getCurrentUserId();
    const conversationId = `conv_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
    
    const conversation: ConversationHistory = {
      id: conversationId,
      userId,
      messages,
      createdAt: new Date(),
      updatedAt: new Date(),
      title: title || `Rozmowa ${new Date().toLocaleDateString()}`
    };

    // Pobierz istniejące rozmowy
    const existingConversations = this.loadConversationsFromStorage();
    
    // Dodaj nową rozmowę
    existingConversations.push(conversation);
    
    // Ogranicz liczbę rozmów
    if (existingConversations.length > this.maxHistoryItems) {
      existingConversations.splice(0, existingConversations.length - this.maxHistoryItems);
    }
    
    // Zapisz do localStorage
    localStorage.setItem(this.historyKey, JSON.stringify(existingConversations));
    
    return conversationId;
  }

  // Załaduj rozmowy z localStorage
  async loadConversations(): Promise<ConversationHistory[]> {
    const userId = await this.getCurrentUserId();
    const allConversations = this.loadConversationsFromStorage();
    
    // Filtruj rozmowy dla obecnego użytkownika
    return allConversations.filter(conv => conv.userId === userId);
  }

  // Usuń rozmowę
  async deleteConversation(conversationId: string): Promise<boolean> {
    try {
      const conversations = this.loadConversationsFromStorage();
      const filteredConversations = conversations.filter(conv => conv.id !== conversationId);
      
      localStorage.setItem(this.historyKey, JSON.stringify(filteredConversations));
      return true;
    } catch (error) {
      console.error('Błąd podczas usuwania rozmowy:', error);
      return false;
    }
  }

  // Wyczyść wszystkie dane użytkownika
  async clearUserData(): Promise<void> {
    const userId = await this.getCurrentUserId();
    
    // Usuń rozmowy użytkownika
    const conversations = this.loadConversationsFromStorage();
    const filteredConversations = conversations.filter(conv => conv.userId !== userId);
    localStorage.setItem(this.historyKey, JSON.stringify(filteredConversations));
    
    // Usuń sesję
    this.currentSession = null;
    localStorage.removeItem(this.storageKey);
  }

  // Eksportuj dane użytkownika
  async exportUserData(): Promise<string> {
    const userId = await this.getCurrentUserId();
    const conversations = await this.loadConversations();
    const session = this.currentSession;
    
    const exportData = {
      userId,
      session,
      conversations,
      exportDate: new Date().toISOString(),
      version: '1.0'
    };
    
    return JSON.stringify(exportData, null, 2);
  }

  // Importuj dane użytkownika
  async importUserData(jsonData: string): Promise<boolean> {
    try {
      const importData = JSON.parse(jsonData);
      
      if (!importData.conversations || !Array.isArray(importData.conversations)) {
        throw new Error('Nieprawidłowy format danych');
      }
      
      // Wczytaj rozmowy
      const existingConversations = this.loadConversationsFromStorage();
      const newConversations = [...existingConversations, ...importData.conversations];
      
      localStorage.setItem(this.historyKey, JSON.stringify(newConversations));
      
      return true;
    } catch (error) {
      console.error('Błąd podczas importu danych:', error);
      return false;
    }
  }

  // Prywatne metody pomocnicze
  private loadSessionFromStorage(): UserSession | null {
    try {
      const saved = localStorage.getItem(this.storageKey);
      if (saved) {
        const session = JSON.parse(saved);
        return {
          ...session,
          createdAt: new Date(session.createdAt),
          lastActive: new Date(session.lastActive)
        };
      }
    } catch (error) {
      console.error('Błąd podczas ładowania sesji:', error);
    }
    return null;
  }

  private saveSessionToStorage(): void {
    if (this.currentSession) {
      try {
        localStorage.setItem(this.storageKey, JSON.stringify(this.currentSession));
      } catch (error) {
        console.error('Błąd podczas zapisywania sesji:', error);
      }
    }
  }

  private loadConversationsFromStorage(): ConversationHistory[] {
    try {
      const saved = localStorage.getItem(this.historyKey);
      if (saved) {
        const conversations = JSON.parse(saved);
        return conversations.map((conv: any) => ({
          ...conv,
          createdAt: new Date(conv.createdAt),
          updatedAt: new Date(conv.updatedAt),
          messages: conv.messages.map((msg: any) => ({
            ...msg,
            timestamp: new Date(msg.timestamp)
          }))
        }));
      }
    } catch (error) {
      console.error('Błąd podczas ładowania rozmów:', error);
    }
    return [];
  }

  // Sprawdź czy użytkownik jest zalogowany przez Google
  async isGoogleAuthenticated(): Promise<boolean> {
    try {
      const { supabase } = await import('./supabase');
      const { data: { session } } = await supabase.auth.getSession();
      return !!(session?.user && session.user.app_metadata?.provider === 'google');
    } catch (error) {
      return false;
    }
  }

  // Pobierz informacje o zalogowanym użytkowniku
  async getUserInfo(): Promise<{ id: string; email?: string; name?: string; isGuest: boolean } | null> {
    try {
      const { supabase } = await import('./supabase');
      const { data: { session } } = await supabase.auth.getSession();
      
      if (session?.user) {
        return {
          id: session.user.id,
          email: session.user.email,
          name: session.user.user_metadata?.full_name || session.user.user_metadata?.name,
          isGuest: false
        };
      }
    } catch (error) {
      console.warn('Nie można pobrać informacji o użytkowniku:', error);
    }

    // Fallback - informacje o gościu
    const userId = await this.getCurrentUserId();
    return {
      id: userId,
      isGuest: true
    };
  }
}