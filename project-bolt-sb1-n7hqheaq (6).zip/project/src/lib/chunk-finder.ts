import { Chunk, SearchResult, ChunkDatabase } from '../types/chunks';
import chunksData from '../data/chunks.json';

class ChunkFinder {
  private chunks: Chunk[];
  private categories: string[];
  private tags: string[];

  constructor() {
    const data = chunksData as ChunkDatabase;
    this.chunks = data.chunks.map(chunk => ({
      ...chunk,
      lastUpdated: new Date(chunk.lastUpdated)
    }));
    this.categories = data.categories;
    this.tags = data.tags;
  }

  /**
   * Główna funkcja wyszukiwania chunków na podstawie zapytania użytkownika
   */
  searchChunks(query: string, limit: number = 3): SearchResult[] {
    if (!query || query.trim().length === 0) {
      return [];
    }

    const normalizedQuery = this.normalizeText(query);
    const queryWords = normalizedQuery.split(' ').filter(word => word.length > 2);
    
    const results: SearchResult[] = [];

    for (const chunk of this.chunks) {
      const score = this.calculateRelevanceScore(chunk, normalizedQuery, queryWords);
      const matchedTerms = this.findMatchedTerms(chunk, queryWords);
      
      if (score > 0.1) { // Próg relevancji
        results.push({
          chunk,
          score,
          matchedTerms
        });
      }
    }

    // Sortuj według score (malejąco) i priority (malejąco)
    results.sort((a, b) => {
      if (Math.abs(a.score - b.score) < 0.05) {
        return b.chunk.priority - a.chunk.priority;
      }
      return b.score - a.score;
    });

    return results.slice(0, limit);
  }

  /**
   * Wyszukiwanie chunków według kategorii
   */
  searchByCategory(category: string): Chunk[] {
    return this.chunks
      .filter(chunk => chunk.category === category)
      .sort((a, b) => b.priority - a.priority);
  }

  /**
   * Wyszukiwanie chunków według tagów
   */
  searchByTags(tags: string[]): Chunk[] {
    return this.chunks
      .filter(chunk => tags.some(tag => chunk.tags.includes(tag)))
      .sort((a, b) => b.priority - a.priority);
  }

  /**
   * Pobierz najważniejsze chunki (wysokie priority)
   */
  getTopChunks(limit: number = 5): Chunk[] {
    return this.chunks
      .sort((a, b) => b.priority - a.priority)
      .slice(0, limit);
  }

  /**
   * Normalizacja tekstu - usuwa polskie znaki, zmienia na małe litery
   */
  private normalizeText(text: string): string {
    return text
      .toLowerCase()
      .replace(/ą/g, 'a')
      .replace(/ć/g, 'c')
      .replace(/ę/g, 'e')
      .replace(/ł/g, 'l')
      .replace(/ń/g, 'n')
      .replace(/ó/g, 'o')
      .replace(/ś/g, 's')
      .replace(/ź/g, 'z')
      .replace(/ż/g, 'z')
      .replace(/[^\w\s]/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  /**
   * Oblicza score relevancji chunka do zapytania
   */
  private calculateRelevanceScore(chunk: Chunk, normalizedQuery: string, queryWords: string[]): number {
    let score = 0;
    
    const normalizedTitle = this.normalizeText(chunk.title);
    const normalizedContent = this.normalizeText(chunk.content);
    const normalizedTags = chunk.tags.map(tag => this.normalizeText(tag));
    const normalizedCategory = this.normalizeText(chunk.category);
    
    // Sprawdź trigger_words jeśli istnieją
    if ('trigger_words' in chunk && Array.isArray(chunk.trigger_words)) {
      const triggerWords = chunk.trigger_words.map(word => this.normalizeText(word));
      for (const trigger of triggerWords) {
        if (normalizedQuery.includes(trigger)) {
          score += 1.2; // Wysoki bonus za trigger words
        }
        for (const word of queryWords) {
          if (trigger.includes(word)) {
            score += 0.9;
          }
        }
      }
    }
    
    // Sprawdź anti_trigger_words - zmniejsz score jeśli pasują
    if ('anti_trigger_words' in chunk && Array.isArray(chunk.anti_trigger_words)) {
      const antiTriggerWords = chunk.anti_trigger_words.map(word => this.normalizeText(word));
      for (const antiTrigger of antiTriggerWords) {
        if (normalizedQuery.includes(antiTrigger)) {
          score -= 0.5; // Penalty za anti-trigger words
        }
      }
    }

    // Dopasowanie w tytule (najwyższa waga)
    if (normalizedTitle.includes(normalizedQuery)) {
      score += 1.2;
    }
    
    // Dopasowanie słów w tytule
    for (const word of queryWords) {
      if (normalizedTitle.includes(word)) {
        score += 0.9;
      }
    }

    // Dopasowanie w tagach
    for (const tag of normalizedTags) {
      if (tag.includes(normalizedQuery)) {
        score += 0.8;
      }
      for (const word of queryWords) {
        if (tag.includes(word)) {
          score += 0.7;
        }
      }
    }

    // Dopasowanie w kategorii
    if (normalizedCategory.includes(normalizedQuery)) {
      score += 0.5;
    }
    for (const word of queryWords) {
      if (normalizedCategory.includes(word)) {
        score += 0.4;
      }
    }

    // Dopasowanie w treści (najniższa waga, ale ważne dla kontekstu)
    if (normalizedContent.includes(normalizedQuery)) {
      score += 0.4;
    }
    for (const word of queryWords) {
      if (normalizedContent.includes(word)) {
        score += 0.3;
      }
    }

    // Bonus za wysokie priority
    score += (chunk.priority / 10) * 0.1;

    return Math.min(score, 2.0); // Maksymalny score = 2.0
  }

  /**
   * Znajduje które terminy z zapytania zostały dopasowane
   */
  private findMatchedTerms(chunk: Chunk, queryWords: string[]): string[] {
    const matched: string[] = [];
    const normalizedTitle = this.normalizeText(chunk.title);
    const normalizedContent = this.normalizeText(chunk.content);
    const normalizedTags = chunk.tags.map(tag => this.normalizeText(tag));

    for (const word of queryWords) {
      if (normalizedTitle.includes(word) || 
          normalizedContent.includes(word) || 
          normalizedTags.some(tag => tag.includes(word))) {
        matched.push(word);
      }
    }

    return matched;
  }

  /**
   * Pobierz wszystkie dostępne kategorie
   */
  getCategories(): string[] {
    return [...this.categories];
  }

  /**
   * Pobierz wszystkie dostępne tagi
   */
  getTags(): string[] {
    return [...this.tags];
  }

  /**
   * Pobierz statystyki bazy chunków
   */
  getStats() {
    return {
      totalChunks: this.chunks.length,
      categories: this.categories.length,
      tags: this.tags.length,
      avgPriority: this.chunks.reduce((sum, chunk) => sum + chunk.priority, 0) / this.chunks.length
    };
  }
}

// Singleton instance
export const chunkFinder = new ChunkFinder();

// Funkcja pomocnicza do użycia w App.tsx
export const searchChunks = (query: string): string => {
  const results = chunkFinder.searchChunks(query, 2); // Maksymalnie 2 chunki
  
  if (results.length === 0) {
    return "";
  }

  // Formatuj chunki do kontekstu dla Claude
  const context = results.map(result => {
    return `[WIEDZA: ${result.chunk.title}]\n${result.chunk.content}`;
  }).join('\n\n');

  return context;
};