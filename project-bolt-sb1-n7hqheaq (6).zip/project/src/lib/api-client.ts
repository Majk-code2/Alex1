// API client that works with both local backend and Netlify Functions

const getApiBaseUrl = (): string => {
  // Check if we're running on Netlify
  if (window.location.hostname.includes('netlify.app')) {
    return window.location.origin;
  }
  
  // Local development
  return 'http://localhost:3002';
};

const isNetlify = (): boolean => {
  return window.location.hostname.includes('netlify.app');
};

export const apiClient = {
  async post(endpoint: string, data: any) {
    const baseUrl = getApiBaseUrl();
    
    // Different URL structure for Netlify vs local
    const url = isNetlify() 
      ? `${baseUrl}/.netlify/functions${endpoint.replace('/api/', '/')}`
      : `${baseUrl}${endpoint}`;

    console.log('API Request:', { url, isNetlify: isNetlify(), endpoint });

    try {
      const response = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(data),
      });

      console.log('API Response status:', response.status);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.error('API Error:', errorData);
        
        let errorMessage = `API Error: ${response.status}`;
        if (errorData.error) {
          errorMessage = errorData.error;
        } else if (response.status === 500) {
          errorMessage = 'Błąd serwera - sprawdź konfigurację';
        } else if (response.status === 503) {
          errorMessage = 'Serwer tymczasowo niedostępny';
        }
        
        throw new Error(errorMessage);
      }

      return response.json();
    } catch (fetchError: any) {
      console.error('Fetch error:', fetchError);
      
      if (fetchError.name === 'TypeError' || fetchError.message?.includes('Failed to fetch')) {
        throw new Error('Nie można połączyć się z serwerem. Sprawdź połączenie internetowe.');
      } else if (fetchError.name === 'TimeoutError') {
        throw new Error('Timeout - serwer nie odpowiada. Spróbuj ponownie.');
      }
      throw fetchError;
    }
  },

  async get(endpoint: string) {
    const baseUrl = getApiBaseUrl();
    
    const url = isNetlify() 
      ? `${baseUrl}/.netlify/functions${endpoint.replace('/api/', '/')}`
      : `${baseUrl}${endpoint}`;

    console.log('API GET Request:', { url, isNetlify: isNetlify(), endpoint });

    try {
      const response = await fetch(url, {
      });

      console.log('API GET Response status:', response.status);

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        console.error('API GET Error:', errorData);
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      return response.json();
    } catch (fetchError: any) {
      console.error('GET Fetch error:', fetchError);
      
      if (fetchError.name === 'TypeError' || fetchError.message?.includes('Failed to fetch')) {
        throw new Error('Nie można połączyć się z serwerem.');
      }
      throw fetchError;
    }
  }
};