import { ConversationStage } from '../../agents/alex-config';
import ALEX_CONFIG from '../../agents/alex-config';

export class SocraticMethodDetector {
  
  detectUserHasIdeas(userMessage: string): boolean {
    const message = userMessage.toLowerCase();
    
    const ideaIndicators = [
      'myślę że', 'może to przez', 'chyba powinienem',
      'mam pomysł', 'zastanawiam się czy', 'może spróbuję',
      'nie wiem czy to dobry pomysł', 'może by tak',
      'wydaje mi się że', 'prawdopodobnie to przez',
      'może gdybym', 'spróbowałbym', 'pomyślałem że'
    ];
    
    return ideaIndicators.some(indicator => message.includes(indicator));
  }
  
  detectUserLost(userMessage: string): boolean {
    const message = userMessage.toLowerCase();
    
    const lostIndicators = [
      'nie wiem od czego zacząć', 'chaos totalny', 'kompletnie nie wiem',
      'jestem zagubiony', 'nie mam pojęcia', 'bez planu',
      'totalny bałagan', 'nie ogarniam', 'gdzie zacząć',
      'kompletnie się pogubiłem', 'nie wiem co robić'
    ];
    
    return lostIndicators.some(indicator => message.includes(indicator));
  }
  
  detectCrisis(userMessage: string): boolean {
    const message = userMessage.toLowerCase();
    
    const crisisIndicators = [
      'wszystko się wali', 'nie mogę się zmusić', 'paraliż',
      'chcę się poddać', 'nie mam siły', 'to nie ma sensu',
      'jestem do niczego', 'nie dam rady', 'blokada'
    ];
    
    return crisisIndicators.some(indicator => message.includes(indicator));
  }
  
  detectDontKnowResponse(userMessage: string): boolean {
    const message = userMessage.toLowerCase();
    
    const dontKnowIndicators = [
      'nie wiem', 'bez pojęcia', 'nie mam pojęcia',
      'nie jestem pewny', 'trudno powiedzieć', 'ciężko stwierdzić'
    ];
    
    return dontKnowIndicators.some(indicator => message.includes(indicator));
  }
  
  shouldAskQuestion(userMessage: string, questionCount: number): boolean {
    // Nigdy więcej niż 2 pytania z rzędu
    if (questionCount >= 2) return false;
    
    // Nie pytaj w kryzysie
    if (this.detectCrisis(userMessage)) return false;
    
    // Nie pytaj jeśli user zagubiony
    if (this.detectUserLost(userMessage)) return false;
    
    // Nie pytaj jeśli user odpowiada "nie wiem"
    if (this.detectDontKnowResponse(userMessage)) return false;
    
    // Pytaj jeśli user ma pomysły
    return this.detectUserHasIdeas(userMessage);
  }
  
  generateSocraticQuestion(userMessage: string, personalityType?: string): string {
    const message = userMessage.toLowerCase();
    
    // Pytania dostosowane do typu osobowości
    const questionTemplates = {
      buntownik: [
        'Co sprawia że wątpisz w ten pomysł?',
        'Który sposób wydaje ci się najbardziej "twój"?',
        'Jak myślisz, co by się stało gdybyś spróbował na swój sposób?'
      ],
      marzyciel: [
        'Co konkretnie cię niepokoi w tym pomyśle?',
        'Jaki byłby najmniejszy, bezpieczny krok do sprawdzenia tego?',
        'Co by musiało się stać, żebyś poczuł się pewniejszy?'
      ],
      perfekcjonista: [
        'Co by oznaczało "wystarczająco dobre" w tym przypadku?',
        'Jak myślisz, co jest najważniejsze w tym pomyśle?',
        'Jaka wersja byłaby "okropnym pierwszym szkicem"?'
      ],
      universal: [
        'Co sprawia że wątpisz w ten pomysł?',
        'Który z tych sposobów wydaje ci się najbardziej realny?',
        'Jak myślisz, co by się stało gdybyś spróbował?',
        'Co konkretnie cię w tym niepokoi?',
        'Jaki byłby pierwszy, mały krok?'
      ]
    };
    
    const questions = questionTemplates[personalityType as keyof typeof questionTemplates] || questionTemplates.universal;
    return questions[Math.floor(Math.random() * questions.length)];
  }
}

export interface ConversationContext {
  currentStage: ConversationStage | null;
  stageHistory: string[];
  messageCount: number;
  lastUserMessage: string;
  conversationHistory: string[];
}

export class ConversationFlowManager {
  private context: ConversationContext;

  constructor() {
    this.context = {
      currentStage: null,
      stageHistory: [],
      messageCount: 0,
      lastUserMessage: '',
      conversationHistory: []
    };
  }

  updateContext(userMessage: string, alexResponse: string): ConversationStage | null {
    this.context.messageCount++;
    this.context.lastUserMessage = userMessage;
    this.context.conversationHistory.push(`User: ${userMessage}`, `Alex: ${alexResponse}`);

    // Wykryj nowy etap na podstawie wiadomości użytkownika
    const newStage = this.detectStage(userMessage);
    
    if (newStage && newStage.id !== this.context.currentStage?.id) {
      this.transitionToStage(newStage);
    }

    return this.context.currentStage;
  }

  private detectStage(userMessage: string): ConversationStage | null {
    const message = userMessage.toLowerCase();
    let bestMatch: ConversationStage | null = null;
    let highestScore = 0;

    for (const stage of ALEX_CONFIG.conversationFlow) {
      let score = 0;

      // Sprawdź triggery
      for (const trigger of stage.triggers) {
        if (message.includes(trigger.toLowerCase())) {
          score += 1;
        }
      }

      // Bonus jeśli to naturalny następny etap
      if (this.context.currentStage?.nextStages.includes(stage.id)) {
        score += 0.5;
      }

      // Penalty jeśli już byliśmy w tym etapie (unikaj zapętlenia)
      if (this.context.stageHistory.includes(stage.id)) {
        score -= 0.3;
      }

      if (score > highestScore && score > 0.5) {
        highestScore = score;
        bestMatch = stage;
      }
    }

    return bestMatch;
  }

  private transitionToStage(newStage: ConversationStage): void {
    if (this.context.currentStage) {
      this.context.stageHistory.push(this.context.currentStage.id);
    }
    
    this.context.currentStage = newStage;
    console.log(`Conversation stage transition: ${newStage.id} (${newStage.name})`);
  }

  getCurrentStage(): ConversationStage | null {
    return this.context.currentStage;
  }

  getContext(): ConversationContext {
    return { ...this.context };
  }

  // Sprawdź czy rozmowa powinna przejść do następnego etapu
  suggestNextStage(): ConversationStage | null {
    if (!this.context.currentStage) return null;

    const nextStageIds = this.context.currentStage.nextStages;
    const availableStages = ALEX_CONFIG.conversationFlow.filter(
      stage => nextStageIds.includes(stage.id) && !this.context.stageHistory.includes(stage.id)
    );

    // Zwróć pierwszy dostępny następny etap
    return availableStages[0] || null;
  }

  // Sprawdź czy użytkownik potrzebuje wskazówki co do następnego kroku
  shouldProvideGuidance(): boolean {
    // Jeśli użytkownik wysłał więcej niż 3 wiadomości w tym samym etapie
    const currentStageMessages = this.context.conversationHistory
      .filter((_, index) => index >= this.getStageStartIndex())
      .filter((msg, index) => index % 2 === 0).length; // Tylko wiadomości użytkownika

    return currentStageMessages >= 3;
  }

  private getStageStartIndex(): number {
    // Znajdź indeks gdzie rozpoczął się obecny etap
    // Uproszczona implementacja - w rzeczywistości trzeba by śledzić to dokładniej
    return Math.max(0, this.context.conversationHistory.length - 6);
  }

  // Generuj kontekstową wskazówkę dla ALEX-a
  generateStageGuidance(): string {
    const stage = this.context.currentStage;
    if (!stage) return '';

    const guidanceMap: { [key: string]: string } = {
      'greeting': 'Użytkownik się przywitał. Zapytaj o jego główny problem z prokrastynacją.',
      'problem_identification': 'Użytkownik opisuje problem. Pomóż mu zidentyfikować wzorce i przyczyny.',
      'goal_setting': 'Użytkownik mówi o celach. Sprawdź czy są to jego prawdziwe cele (test energii).',
      'crisis_intervention': 'KRYZYS! Użyj protokołu emocjonalnego. Nie dawaj standardowych rad.',
      'system_setup': 'Użytkownik chce system. Zaproponuj System 3 Rzeczy lub 5 Zwycięstw.',
      'action_planning': 'Czas na konkretne działania. Pomóż zaplanować następne kroki.',
      'habit_building': 'Skup się na budowaniu nawyków. Małe kroki, konsekwencja.',
      'progress_tracking': 'Pomóż śledzić postępy. Świętuj małe zwycięstwa.'
    };

    return guidanceMap[stage.id] || '';
  }

  // Reset dla nowej sesji
  reset(): void {
    this.context = {
      currentStage: null,
      stageHistory: [],
      messageCount: 0,
      lastUserMessage: '',
      conversationHistory: []
    };
    this.questionCount = 0;
    this.lastResponseWasQuestion = false;
  }
}

export default ConversationFlowManager;