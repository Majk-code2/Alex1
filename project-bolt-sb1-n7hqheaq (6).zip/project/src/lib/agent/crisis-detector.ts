import ALEX_CONFIG from '../../agents/alex-config';

export interface CrisisSignals {
  isCrisis: boolean;
  severity: 'low' | 'medium' | 'high';
  detectedKeywords: string[];
  emotionalState: string;
  recommendedAction: 'protocol' | 'support' | 'redirect';
}

export class CrisisDetector {
  private crisisKeywords = [
    'wszystko się wali',
    'nie mogę się zmusić', 
    'paraliż',
    'blokada',
    'chcę się poddać',
    'nie mam siły',
    'to nie ma sensu',
    'jestem do niczego',
    'nie dam rady'
  ];
  
  // Dodatkowe wzorce kryzysowe
  private severityPatterns = {
    high: [
      'chcę się poddać',
      'nie mam siły',
      'wszystko się wali',
      'nie dam rady',
      'jestem do niczego',
      'to nie ma sensu'
    ],
    medium: [
      'paraliż',
      'blokada',
      'nie mogę się zmusić',
      'czuję się przytłoczony',
      'wszystko idzie nie tak'
    ],
    low: [
      'trudno mi się zmotywować',
      'brak energii',
      'nie wiem co robić',
      'czuję się zagubiony',
      'nie chce mi się'
    ]
  };

  detectCrisis(userMessage: string, conversationHistory: string[] = []): CrisisSignals {
    const message = userMessage.toLowerCase();
    const history = conversationHistory.join(' ').toLowerCase();
    const fullText = `${message} ${history}`;

    const detectedKeywords: string[] = [];
    let severity: 'low' | 'medium' | 'high' = 'low';
    let isCrisis = false;

    // Sprawdź główne słowa kluczowe kryzysu
    for (const keyword of this.crisisKeywords) {
      if (message.includes(keyword.toLowerCase())) {
        detectedKeywords.push(keyword);
        isCrisis = true;
      }
    }

    // Określ poziom nasilenia
    for (const [level, patterns] of Object.entries(this.severityPatterns)) {
      for (const pattern of patterns) {
        if (message.includes(pattern.toLowerCase())) {
          severity = level as 'low' | 'medium' | 'high';
          detectedKeywords.push(pattern);
          isCrisis = true;
          break;
        }
      }
      if (severity === level) break; // Zatrzymaj się na pierwszym dopasowaniu
    }

    // Sprawdź wzorce emocjonalne w historii
    const emotionalState = this.detectEmotionalState(fullText);
    
    // Jeśli wykryto negatywne emocje w historii, zwiększ czułość
    if (emotionalState === 'despair' || emotionalState === 'overwhelm') {
      isCrisis = true;
      if (severity === 'low') severity = 'medium';
    }

    const recommendedAction = this.getRecommendedAction(severity, emotionalState);

    return {
      isCrisis,
      severity,
      detectedKeywords,
      emotionalState,
      recommendedAction
    };
  }

  private detectEmotionalState(text: string): string {
    const emotionalPatterns = {
      despair: ['beznadziejne', 'bez sensu', 'po co', 'nie ma znaczenia', 'daremne'],
      overwhelm: ['za dużo', 'przytłaczające', 'nie ogarniam', 'chaos', 'wszystko naraz'],
      anxiety: ['stres', 'niepokój', 'lęk', 'boję się', 'martwię się'],
      frustration: ['wkurza mnie', 'irytuje', 'denerwuje', 'mam dość', 'już nie mogę'],
      sadness: ['smutny', 'przygnębiony', 'zły na siebie', 'rozczarowany'],
      fatigue: ['zmęczony', 'wyczerpany', 'bez energii', 'nie mam siły']
    };

    for (const [emotion, patterns] of Object.entries(emotionalPatterns)) {
      for (const pattern of patterns) {
        if (text.includes(pattern)) {
          return emotion;
        }
      }
    }

    return 'neutral';
  }

  private getRecommendedAction(severity: 'low' | 'medium' | 'high', emotionalState: string): 'protocol' | 'support' | 'redirect' {
    if (severity === 'high' || emotionalState === 'despair') {
      return 'protocol'; // Użyj protokołu kryzysowego
    }
    
    if (severity === 'medium' || ['overwhelm', 'anxiety'].includes(emotionalState)) {
      return 'support'; // Wsparcie emocjonalne + łagodne techniki
    }
    
    return 'redirect'; // Przekieruj na pozytywne działania
  }

  // Sprawdź czy użytkownik wychodzi z kryzysu
  detectRecovery(userMessage: string, previousCrisisLevel: 'low' | 'medium' | 'high'): boolean {
    const message = userMessage.toLowerCase();
    
    const recoverySignals = [
      'czuję się lepiej',
      'pomogło',
      'dziękuję',
      'spróbuję',
      'może masz rację',
      'ok, zrobię to',
      'brzmi sensownie'
    ];

    const hasRecoverySignal = recoverySignals.some(signal => 
      message.includes(signal.toLowerCase())
    );

    // Sprawdź czy nie ma już słów kryzysowych
    const hasCrisisWords = this.crisisKeywords.some(keyword => 
      message.includes(keyword.toLowerCase())
    );

    return hasRecoverySignal && !hasCrisisWords;
  }

  // Generuj kontekst dla ALEX-a o stanie kryzysu
  generateCrisisContext(signals: CrisisSignals): string {
    if (!signals.isCrisis) return '';

    let context = `WYKRYTO KRYZYS (${signals.severity.toUpperCase()}): `;
    context += `Słowa kluczowe: ${signals.detectedKeywords.join(', ')}. `;
    context += `Stan emocjonalny: ${signals.emotionalState}. `;
    
    switch (signals.recommendedAction) {
      case 'protocol':
        context += 'UŻYJ PROTOKOŁU KRYZYSOWEGO - nie dawaj standardowych rad!';
        break;
      case 'support':
        context += 'Skup się na wsparciu emocjonalnym i prostych technikach.';
        break;
      case 'redirect':
        context += 'Łagodnie przekieruj na pozytywne działania.';
        break;
    }

    return context;
  }
}

export default CrisisDetector;