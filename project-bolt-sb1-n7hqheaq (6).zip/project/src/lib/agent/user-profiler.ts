import { PersonalityType } from '../../agents/alex-config';
import PersonalityAdapter from '../../agents/alex-personality';

export interface UserProfile {
  personalityType: PersonalityType | null;
  confidence: number;
  preferredCommunicationStyle: 'direct' | 'supportive' | 'flexible';
  commonTriggers: string[];
  successfulStrategies: string[];
  avoidancePatterns: string[];
  progressLevel: 'beginner' | 'intermediate' | 'advanced';
  lastActive: Date;
}

export interface UserBehaviorPattern {
  messageLength: 'short' | 'medium' | 'long';
  responseTime: 'immediate' | 'delayed' | 'sporadic';
  questionTypes: ('problem' | 'goal' | 'system' | 'crisis')[];
  engagementLevel: 'high' | 'medium' | 'low';
}

export class UserProfiler {
  private personalityAdapter: PersonalityAdapter;
  private profile: UserProfile;
  private userId: string | null = null;
  private behaviorHistory: UserBehaviorPattern[] = [];

  constructor(userId?: string) {
    this.personalityAdapter = new PersonalityAdapter();
    this.profile = this.initializeProfile();
    this.userId = userId || null;
  }

  private initializeProfile(): UserProfile {
    return {
      personalityType: null,
      confidence: 0,
      preferredCommunicationStyle: 'supportive',
      commonTriggers: [],
      successfulStrategies: [],
      avoidancePatterns: [],
      progressLevel: 'beginner',
      lastActive: new Date()
    };
  }

  // Załaduj profil z bazy danych
  async loadProfile(userId: string): Promise<UserProfile> {
    this.userId = userId;
    
    try {
      const { supabase } = await import('../../lib/supabase');
      
      const { data, error } = await supabase
        .from('user_profiles')
        .select('profile_data')
        .eq('user_id', userId)
        .maybeSingle();

      if (error && error.code !== 'PGRST116') { // PGRST116 = no rows returned
        throw error;
      }

      if (data) {
        // Przywróć profil z bazy danych
        this.profile = {
          ...this.initializeProfile(),
          ...data.profile_data,
          lastActive: new Date(data.profile_data.lastActive)
        };
        
        // Przywróć typ osobowości w personalityAdapter
        if (this.profile.personalityType) {
          // Symuluj wykrycie typu osobowości
          this.personalityAdapter.detectPersonality('', []);
        }
      }
      
      return this.profile;
    } catch (error) {
      console.error('Błąd podczas ładowania profilu:', error);
      // Zwróć domyślny profil w przypadku błędu
      return this.profile;
    }
  }

  // Zapisz profil do bazy danych
  async saveProfile(userId?: string): Promise<boolean> {
    const targetUserId = userId || this.userId;
    
    if (!targetUserId) {
      console.error('Brak userId do zapisania profilu');
      return false;
    }

    try {
      const { supabase } = await import('../../lib/supabase');
      
      const { error } = await supabase
        .from('user_profiles')
        .upsert({
          user_id: targetUserId,
          profile_data: {
            ...this.profile,
            behaviorHistory: this.behaviorHistory.slice(-10)
          },
          updated_at: new Date().toISOString()
        }, {
          onConflict: 'user_id'
        });

      if (error) {
        throw error;
      }

      return true;
    } catch (error) {
      console.error('Błąd podczas zapisywania profilu:', error);
      return false;
    }
  }

  updateProfile(userMessage: string, conversationHistory: string[], alexResponse: string): UserProfile {
    this.profile.lastActive = new Date();

    // Aktualizuj typ osobowości
    const detectedType = this.personalityAdapter.detectPersonality(userMessage, conversationHistory);
    if (detectedType) {
      this.profile.personalityType = detectedType;
      this.profile.confidence = this.personalityAdapter.getConfidence();
      this.profile.preferredCommunicationStyle = this.mapToCommStyle(detectedType);
    }

    // Analizuj wzorce zachowań
    const behaviorPattern = this.analyzeBehaviorPattern(userMessage, conversationHistory);
    this.behaviorHistory.push(behaviorPattern);

    // Aktualizuj triggery i wzorce
    this.updateTriggers(userMessage);
    this.updateAvoidancePatterns(userMessage);
    this.updateProgressLevel(conversationHistory);

    // Oceń skuteczność strategii
    this.evaluateStrategySuccess(userMessage, alexResponse);

    // Automatycznie zapisz profil po aktualizacji (jeśli mamy userId)
    if (this.userId) {
      this.saveProfile().catch(error => {
        console.error('Błąd podczas automatycznego zapisywania profilu:', error);
      });
    }

    return { ...this.profile };
  }

  private mapToCommStyle(personalityType: PersonalityType): 'direct' | 'supportive' | 'flexible' {
    switch (personalityType.id) {
      case 'buntownik': return 'flexible';
      case 'marzyciel': return 'supportive';
      case 'perfekcjonista': return 'supportive';
      default: return 'supportive';
    }
  }

  private analyzeBehaviorPattern(userMessage: string, history: string[]): UserBehaviorPattern {
    const messageLength = userMessage.length < 50 ? 'short' : 
                         userMessage.length < 200 ? 'medium' : 'long';

    const questionTypes: ('problem' | 'goal' | 'system' | 'crisis')[] = [];
    const message = userMessage.toLowerCase();

    if (message.includes('problem') || message.includes('nie mogę') || message.includes('trudno')) {
      questionTypes.push('problem');
    }
    if (message.includes('cel') || message.includes('chcę') || message.includes('planuję')) {
      questionTypes.push('goal');
    }
    if (message.includes('system') || message.includes('jak') || message.includes('metoda')) {
      questionTypes.push('system');
    }
    if (message.includes('wszystko się wali') || message.includes('nie mam siły')) {
      questionTypes.push('crisis');
    }

    const engagementLevel = this.calculateEngagementLevel(userMessage, history);

    return {
      messageLength,
      responseTime: 'immediate', // Można rozszerzyć o rzeczywiste śledzenie czasu
      questionTypes,
      engagementLevel
    };
  }

  private calculateEngagementLevel(userMessage: string, history: string[]): 'high' | 'medium' | 'low' {
    let score = 0;

    // Długość wiadomości
    if (userMessage.length > 100) score += 2;
    else if (userMessage.length > 50) score += 1;

    // Pytania i szczegóły
    if (userMessage.includes('?')) score += 1;
    if (userMessage.includes('jak') || userMessage.includes('dlaczego')) score += 1;

    // Osobiste szczegóły
    if (userMessage.includes('ja') || userMessage.includes('mnie') || userMessage.includes('mój')) score += 1;

    // Historia rozmowy
    if (history.length > 5) score += 1;

    if (score >= 4) return 'high';
    if (score >= 2) return 'medium';
    return 'low';
  }

  private updateTriggers(userMessage: string): void {
    const message = userMessage.toLowerCase();
    const potentialTriggers = [
      'deadline', 'presja', 'stres', 'ocena', 'perfekcja', 'chaos', 
      'za dużo', 'nie zdążę', 'trudne', 'nuda', 'brak motywacji'
    ];

    for (const trigger of potentialTriggers) {
      if (message.includes(trigger) && !this.profile.commonTriggers.includes(trigger)) {
        this.profile.commonTriggers.push(trigger);
      }
    }

    // Ogranicz do 10 najczęstszych
    if (this.profile.commonTriggers.length > 10) {
      this.profile.commonTriggers = this.profile.commonTriggers.slice(-10);
    }
  }

  private updateAvoidancePatterns(userMessage: string): void {
    const message = userMessage.toLowerCase();
    const avoidanceSignals = [
      'odkładam', 'prokrastynauje', 'nie mogę zacząć', 'scrolluję', 
      'oglądam', 'sprzątam zamiast', 'jem zamiast', 'myślę zamiast robić'
    ];

    for (const pattern of avoidanceSignals) {
      if (message.includes(pattern) && !this.profile.avoidancePatterns.includes(pattern)) {
        this.profile.avoidancePatterns.push(pattern);
      }
    }
  }

  private updateProgressLevel(history: string[]): void {
    const totalMessages = history.length;
    const systemUsage = history.filter(msg => 
      msg.includes('system') || msg.includes('rutyna') || msg.includes('plan')
    ).length;

    if (totalMessages > 20 && systemUsage > 5) {
      this.profile.progressLevel = 'advanced';
    } else if (totalMessages > 10 && systemUsage > 2) {
      this.profile.progressLevel = 'intermediate';
    } else {
      this.profile.progressLevel = 'beginner';
    }
  }

  private evaluateStrategySuccess(userMessage: string, alexResponse: string): void {
    const message = userMessage.toLowerCase();
    const response = alexResponse.toLowerCase();

    // Pozytywne sygnały
    const positiveSignals = [
      'pomogło', 'działa', 'spróbuję', 'dobry pomysł', 'dzięki', 
      'lepiej się czuję', 'zrobiłem', 'udało się'
    ];

    // Negatywne sygnały
    const negativeSignals = [
      'nie działa', 'za trudne', 'nie mogę', 'nie pasuje mi', 'nie rozumiem'
    ];

    // Znajdź strategię w odpowiedzi ALEX-a
    const strategies = [
      'pomodoro', '5-4-3-2-1', 'system 3 rzeczy', 'protokół emocjonalny',
      'test energii', 'eat the frog', 'matryca eisenhowera'
    ];

    const usedStrategy = strategies.find(strategy => response.includes(strategy));

    if (usedStrategy) {
      const isPositive = positiveSignals.some(signal => message.includes(signal));
      const isNegative = negativeSignals.some(signal => message.includes(signal));

      if (isPositive && !this.profile.successfulStrategies.includes(usedStrategy)) {
        this.profile.successfulStrategies.push(usedStrategy);
      } else if (isNegative) {
        // Usuń z udanych strategii jeśli nie działa
        this.profile.successfulStrategies = this.profile.successfulStrategies
          .filter(s => s !== usedStrategy);
      }
    }
  }

  getProfile(): UserProfile {
    return { ...this.profile };
  }

  // Generuj rekomendacje dla ALEX-a na podstawie profilu
  generateRecommendations(): string {
    const profile = this.profile;
    let recommendations = '';

    if (profile.personalityType) {
      recommendations += `Typ użytkownika: ${profile.personalityType.name} (pewność: ${Math.round(profile.confidence * 100)}%). `;
    }

    if (profile.successfulStrategies.length > 0) {
      recommendations += `Skuteczne strategie: ${profile.successfulStrategies.join(', ')}. `;
    }

    if (profile.commonTriggers.length > 0) {
      recommendations += `Główne triggery: ${profile.commonTriggers.slice(0, 3).join(', ')}. `;
    }

    recommendations += `Poziom: ${profile.progressLevel}. `;
    recommendations += `Styl komunikacji: ${profile.preferredCommunicationStyle}.`;

    return recommendations;
  }

  // Reset profilu dla nowej sesji
  reset(): void {
    this.profile = this.initializeProfile();
    this.behaviorHistory = [];
    this.userId = null;
    this.personalityAdapter.reset();
  }

  // Eksport profilu do localStorage (opcjonalne)
  exportProfile(): string {
    return JSON.stringify({
      profile: this.profile,
      behaviorHistory: this.behaviorHistory.slice(-10) // Ostatnie 10 wzorców
    });
  }

  // Import profilu z localStorage (opcjonalne)
  importProfile(profileData: string): void {
    try {
      const data = JSON.parse(profileData);
      this.profile = { ...this.initializeProfile(), ...data.profile };
      this.behaviorHistory = data.behaviorHistory || [];
    } catch (error) {
      console.error('Error importing profile:', error);
    }
  }

  // Ustaw userId
  setUserId(userId: string): void {
    this.userId = userId;
  }

  // Pobierz userId
  getUserId(): string | null {
    return this.userId;
  }
}

export default UserProfiler;