import { Chunk, SearchResult } from '../../types/chunks';
import { chunkFinder } from '../chunk-finder';
import { PersonalityType, ConversationStage } from '../../agents/alex-config';

export interface ChunkSelectionContext {
  userMessage: string;
  conversationHistory: string[];
  personalityType: PersonalityType | null;
  conversationStage: ConversationStage | null;
  isCrisis: boolean;
}

export class ChunkSelector {
  selectRelevantChunks(context: ChunkSelectionContext): SearchResult[] {
    const { userMessage, personalityType, conversationStage, isCrisis } = context;

    // Sprawdź czy pytanie dotyczy systemu 3F
    if (this.isSystem3FQuery(userMessage)) {
      return this.selectSystem3FChunks(userMessage);
    }

    // W sytuacji kryzysowej priorytet dla chunków kryzysowych
    if (isCrisis) {
      return this.selectCrisisChunks(userMessage);
    }

    // Jeśli mamy zidentyfikowany etap rozmowy, użyj wymaganych chunków
    if (conversationStage?.requiredChunks.length) {
      return this.selectStageChunks(conversationStage, userMessage);
    }

    // Standardowe wyszukiwanie z dostosowaniem do typu osobowości
    let results = chunkFinder.searchChunks(userMessage, 3);

    // Filtruj i dostosuj do typu osobowości
    if (personalityType) {
      results = this.filterByPersonality(results, personalityType);
    }
    
    // Filtruj według user_personas jeśli chunk ma to pole
    results = this.filterByUserPersonas(results, personalityType);

    // Zawsze zwróć maksymalnie 2 chunki dla czytelności
    return results.slice(0, 2);
  }
  
  private isSystem3FQuery(userMessage: string): boolean {
    const message = userMessage.toLowerCase();
    const system3fKeywords = [
      'system 3f', 'system 3-f', '3f', 'system 3 f',
      'foundation', 'fundament', 'fuel', 'focus', 'fokus',
      'wartość', 'wartosci', 'misja', 'małe kroki', 'male kroki',
      'supermoc', 'rakieta', 'działania'
    ];
    
    return system3fKeywords.some(keyword => message.includes(keyword));
  }
  
  private selectSystem3FChunks(userMessage: string): SearchResult[] {
    const system3fChunkIds = [
      'FUNDAMENT_01_Twoja_supermoc',
      'FUEL_01_Misja_zyciowa',
      'FOKUS_01_Male_kroki'
    ];
    
    const results: SearchResult[] = [];
    const allChunks = chunkFinder.getTopChunks(50);
    
    // Znajdź chunki systemu 3F
    for (const chunkId of system3fChunkIds) {
      const chunk = allChunks.find(c => c.id === chunkId);
      if (chunk) {
        // Oblicz score na podstawie dopasowania do wiadomości użytkownika
        const score = this.calculateRelevanceScore(chunk, userMessage);
        results.push({
          chunk,
          score: score + 0.5, // Dodatkowy bonus dla chunków 3F
          matchedTerms: this.findMatchedTerms(chunk, userMessage)
        });
      }
    }
    
    // Posortuj według score i zwróć najlepsze
    return results.sort((a, b) => b.score - a.score);
  }
  
  private filterByUserPersonas(results: SearchResult[], personalityType: PersonalityType | null): SearchResult[] {
    return results.map(result => {
      const chunk = result.chunk as any;
      let adjustedScore = result.score;
      
      // Sprawdź czy chunk ma user_personas
      if (chunk.user_personas && Array.isArray(chunk.user_personas)) {
        const personas = chunk.user_personas;
        
        // Jeśli chunk jest universal, zawsze pasuje
        if (personas.includes('universal')) {
          adjustedScore += 0.1;
        }
        
        // Jeśli mamy wykryty typ osobowości, sprawdź dopasowanie
        if (personalityType) {
          const personalityId = personalityType.id;
          if (personas.includes(personalityId)) {
            adjustedScore += 0.3; // Bonus za dopasowanie do typu
          }
        }
      }
      
      return {
        ...result,
        score: adjustedScore
      };
    }).sort((a, b) => b.score - a.score);
  }

  private selectCrisisChunks(userMessage: string): SearchResult[] {
    // Priorytet dla chunków kryzysowych
    const crisisChunkIds = [
      'CRISIS_01_Protokol_emocjonalny',
      'MADROSC_01_Tysiac_mil_jeden_krok',
      'INTRO_03_Mechanizm_obronny'
    ];

    const results: SearchResult[] = [];
    
    // Najpierw spróbuj znaleźć dokładne dopasowanie
    const searchResults = chunkFinder.searchChunks(userMessage, 5);
    
    for (const crisisId of crisisChunkIds) {
      const crisisChunk = searchResults.find(r => r.chunk.id === crisisId);
      if (crisisChunk) {
        results.push(crisisChunk);
        break; // W kryzysie jeden chunk wystarczy
      }
    }

    // Jeśli nie znaleziono chunka kryzysowego, użyj protokołu emocjonalnego jako fallback
    if (results.length === 0) {
      const allChunks = chunkFinder.getTopChunks(20);
      const fallbackChunk = allChunks.find(c => c.id === 'CRISIS_01_Protokol_emocjonalny');
      if (fallbackChunk) {
        results.push({
          chunk: fallbackChunk,
          score: 1.0,
          matchedTerms: ['kryzys']
        });
      }
    }

    return results;
  }

  private selectStageChunks(stage: ConversationStage, userMessage: string): SearchResult[] {
    const results: SearchResult[] = [];
    const allChunks = chunkFinder.getTopChunks(50);

    // Znajdź chunki wymagane dla tego etapu
    for (const chunkId of stage.requiredChunks) {
      const chunk = allChunks.find(c => c.id === chunkId);
      if (chunk) {
        // Oblicz score na podstawie dopasowania do wiadomości użytkownika
        const score = this.calculateRelevanceScore(chunk, userMessage);
        results.push({
          chunk,
          score,
          matchedTerms: this.findMatchedTerms(chunk, userMessage)
        });
      }
    }

    // Posortuj według score i zwróć najlepsze
    return results.sort((a, b) => b.score - a.score).slice(0, 2);
  }

  private filterByPersonality(results: SearchResult[], personalityType: PersonalityType): SearchResult[] {
    return results.map(result => {
      let adjustedScore = result.score;

      // Zwiększ score dla chunków pasujących do typu osobowości
      const chunkContent = result.chunk.content.toLowerCase();
      const chunkTags = result.chunk.tags.join(' ').toLowerCase();
      const fullChunkText = `${chunkContent} ${chunkTags}`;

      // Sprawdź czy chunk zawiera triggery dla tego typu
      for (const trigger of personalityType.triggers) {
        if (fullChunkText.includes(trigger.toLowerCase())) {
          adjustedScore += 0.2;
        }
      }

      // Zmniejsz score jeśli chunk zawiera słowa których ten typ unika
      for (const avoidWord of personalityType.avoidWords) {
        if (fullChunkText.includes(avoidWord.toLowerCase())) {
          adjustedScore -= 0.3;
        }
      }

      return {
        ...result,
        score: Math.max(0, adjustedScore) // Nie pozwól na ujemny score
      };
    }).sort((a, b) => b.score - a.score);
  }

  private calculateRelevanceScore(chunk: Chunk, userMessage: string): number {
    const normalizedMessage = userMessage.toLowerCase();
    const normalizedContent = chunk.content.toLowerCase();
    const normalizedTitle = chunk.title.toLowerCase();
    const normalizedTags = chunk.tags.join(' ').toLowerCase();

    let score = 0;

    // Dopasowanie w tytule (najwyższa waga)
    if (normalizedTitle.includes(normalizedMessage)) score += 1.0;

    // Dopasowanie w tagach
    if (normalizedTags.includes(normalizedMessage)) score += 0.8;

    // Dopasowanie w treści
    if (normalizedContent.includes(normalizedMessage)) score += 0.6;

    // Bonus za wysokie priority
    score += (chunk.priority / 10) * 0.2;

    return Math.min(score, 2.0);
  }

  private findMatchedTerms(chunk: Chunk, userMessage: string): string[] {
    const messageWords = userMessage.toLowerCase().split(' ').filter(word => word.length > 2);
    const chunkText = `${chunk.title} ${chunk.content} ${chunk.tags.join(' ')}`.toLowerCase();
    
    return messageWords.filter(word => chunkText.includes(word));
  }

  // Metoda pomocnicza do debugowania
  explainSelection(context: ChunkSelectionContext): string {
    const { isCrisis, conversationStage, personalityType } = context;
    
    let explanation = 'Wybór chunków: ';
    
    if (isCrisis) {
      explanation += 'Wykryto kryzys - priorytet dla protokołów ratunkowych';
    } else if (conversationStage) {
      explanation += `Etap rozmowy: ${conversationStage.name} - używam wymaganych chunków`;
    } else if (personalityType) {
      explanation += `Typ osobowości: ${personalityType.name} - dostosowuję wybór`;
    } else {
      explanation += 'Standardowe wyszukiwanie semantyczne';
    }
    
    return explanation;
  }
}

export default ChunkSelector;