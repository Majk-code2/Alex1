export interface CalendarIntent {
  hasCalendarIntent: boolean;
  action: 'add_event' | 'check_schedule' | 'remind' | null;
  eventText?: string;
  confidence: number;
}

export class CalendarDetector {
  private addEventTriggers = [
    'dodaj do kalendarza',
    'zaplanuj',
    'umów',
    'zapisz w kalendarzu',
    'dodaj wydarzenie',
    'zarezerwuj czas',
    'blokuj czas',
    'spotkanie',
    'termin',
    'deadline',
    'przypomnienie'
  ];

  private timeExpressions = [
    'jutro', 'dziś', 'pojutrze',
    'w poniedziałek', 'we wtorek', 'w środę', 'w czwartek', 'w piątek', 'w sobotę', 'w niedzielę',
    'za godzinę', 'za 2 godziny', 'za tydzień',
    'o 14:00', 'o 15:30', 'rano', 'wieczorem',
    'następny tydzień', 'w przyszłym tygodniu'
  ];

  private checkScheduleTriggers = [
    'co mam dziś',
    'co mam jutro',
    'jaki mam plan',
    'sprawdź kalendarz',
    'co mam zaplanowane',
    'wolny termin',
    'kiedy mam czas'
  ];

  detectCalendarIntent(userMessage: string): CalendarIntent {
    const message = userMessage.toLowerCase();
    let confidence = 0;
    let action: 'add_event' | 'check_schedule' | 'remind' | null = null;
    let eventText = '';

    // Sprawdź czy to dodawanie wydarzenia
    const hasAddTrigger = this.addEventTriggers.some(trigger => {
      if (message.includes(trigger)) {
        confidence += 0.4;
        return true;
      }
      return false;
    });

    // Sprawdź czy to sprawdzanie kalendarza
    const hasCheckTrigger = this.checkScheduleTriggers.some(trigger => {
      if (message.includes(trigger)) {
        confidence += 0.4;
        action = 'check_schedule';
        return true;
      }
      return false;
    });

    // Sprawdź wyrażenia czasowe
    const hasTimeExpression = this.timeExpressions.some(expr => {
      if (message.includes(expr)) {
        confidence += 0.3;
        return true;
      }
      return false;
    });

    // Sprawdź wzorce godzinowe
    const timePattern = /\b(\d{1,2}):(\d{2})\b/;
    if (timePattern.test(message)) {
      confidence += 0.3;
    }

    // Określ akcję jeśli nie została jeszcze określona
    if (!action && hasAddTrigger) {
      action = 'add_event';
      eventText = this.extractEventText(userMessage);
    }

    // Sprawdź kontekst przypomnienia
    if (message.includes('przypomnij') || message.includes('przypomnienie')) {
      action = 'remind';
      confidence += 0.2;
    }

    // Specjalne wzorce dla dodawania wydarzeń
    const eventPatterns = [
      /spotkanie.*?(jutro|dziś|w \w+).*?o \d{1,2}:\d{2}/i,
      /termin.*?(jutro|dziś|w \w+)/i,
      /(jutro|dziś|w \w+).*?o \d{1,2}:\d{2}/i,
      /za \d+ godzin/i
    ];

    for (const pattern of eventPatterns) {
      if (pattern.test(message)) {
        confidence += 0.4;
        action = 'add_event';
        eventText = userMessage;
        break;
      }
    }

    return {
      hasCalendarIntent: confidence >= 0.4,
      action,
      eventText: eventText || userMessage,
      confidence: Math.min(confidence, 1.0)
    };
  }

  private extractEventText(message: string): string {
    // Usuń typowe frazy wprowadzające
    let eventText = message
      .replace(/dodaj do kalendarza/gi, '')
      .replace(/zaplanuj/gi, '')
      .replace(/umów/gi, '')
      .replace(/zapisz w kalendarzu/gi, '')
      .trim();

    return eventText || message;
  }

  // Generuj sugestie dla ALEX-a
  generateCalendarSuggestion(intent: CalendarIntent): string {
    if (!intent.hasCalendarIntent) return '';

    switch (intent.action) {
      case 'add_event':
        return `Wykryto chęć dodania wydarzenia: "${intent.eventText}". Czy mam dodać to do Twojego kalendarza?`;
      
      case 'check_schedule':
        return 'Sprawdzam Twój kalendarz...';
      
      case 'remind':
        return 'Ustawiam przypomnienie w kalendarzu...';
      
      default:
        return 'Wykryto intencję związaną z kalendarzem. Czy chcesz dodać wydarzenie czy sprawdzić plan?';
    }
  }

  // Sprawdź czy wiadomość zawiera potwierdzenie
  detectConfirmation(message: string): boolean {
    const confirmationWords = [
      'tak', 'yes', 'ok', 'okej', 'zgoda', 'dodaj', 'zapisz',
      'potwierdź', 'zrób to', 'tak, dodaj', 'tak, zapisz'
    ];

    const lowerMessage = message.toLowerCase().trim();
    return confirmationWords.some(word => lowerMessage.includes(word));
  }

  // Sprawdź czy wiadomość zawiera odmowę
  detectRejection(message: string): boolean {
    const rejectionWords = [
      'nie', 'no', 'nie dziękuję', 'nie trzeba', 'anuluj',
      'nie dodawaj', 'nie zapisuj', 'rezygnuję'
    ];

    const lowerMessage = message.toLowerCase().trim();
    return rejectionWords.some(word => lowerMessage.includes(word));
  }
}

export default CalendarDetector;