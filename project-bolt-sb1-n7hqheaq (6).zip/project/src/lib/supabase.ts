import { createClient } from '@supabase/supabase-js';

const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY;

console.log('🔧 Inicjalizacja Supabase...');
console.log('URL:', supabaseUrl ? '✅ Ustawiony' : '❌ Brak');
console.log('Anon Key:', supabaseAnonKey ? '✅ Ustawiony' : '❌ Brak');

// TYMCZASOWO WYŁĄCZ SUPABASE - użyj trybu offline
const forceOfflineMode = true;

// Sprawdź czy zmienne są rzeczywiście ustawione (nie placeholder)
const isSupabaseConfigured = !forceOfflineMode && supabaseUrl && 
  supabaseAnonKey && 
  !supabaseUrl.includes('your-') && 
  !supabaseAnonKey.includes('your-') &&
  supabaseUrl.includes('.supabase.co');

if (forceOfflineMode) {
  console.warn('🔧 TRYB OFFLINE: Supabase wyłączony - aplikacja będzie działać bez zapisywania danych');
} else if (!supabaseUrl || !supabaseAnonKey) {
  console.warn('⚠️  Brak zmiennych Supabase. Niektóre funkcje mogą nie działać.');
  console.warn('Sprawdź czy VITE_SUPABASE_URL i VITE_SUPABASE_ANON_KEY są w .env');
} else if (!isSupabaseConfigured) {
  console.warn('⚠️  Zmienne Supabase zawierają placeholder values lub są niepoprawne.');
  console.warn('Sprawdź czy wartości w .env-persistent są prawdziwe.');
}

// Utwórz klienta tylko jeśli konfiguracja jest poprawna
export const supabase = isSupabaseConfigured 
  ? createClient(supabaseUrl!, supabaseAnonKey!, {
      auth: {
        autoRefreshToken: true,
        persistSession: true,
        detectSessionInUrl: true,
        flowType: 'pkce',
        debug: false
      },
      global: {
        headers: {
          'X-Client-Info': 'alex-agent'
        }
      },
      db: {
        schema: 'public'
      }
    })
  : createClient('https://placeholder.supabase.co', 'placeholder-key', {
      auth: { persistSession: false }
    });

// Test połączenia tylko jeśli konfiguracja jest poprawna
if (isSupabaseConfigured) {
  // Test z timeout i retry
  Promise.race([
    testSupabaseConnection(),
    new Promise((_, reject) => 
      setTimeout(() => reject(new Error('Timeout')), 5000)
    )
  ])
    .then((result) => {
      if (result.success) {
        console.log('✅ Połączenie z Supabase działa');
      } else {
        console.error('❌ Błąd połączenia z Supabase:', result.error);
        console.error('🔧 Sprawdź:');
        console.error('   1. Czy projekt Supabase jest aktywny na https://supabase.com/dashboard');
        console.error('   2. Czy URL i klucze są poprawne w .env-persistent');
        console.error('   3. Czy masz połączenie z internetem');
        console.error('   4. Czy projekt nie jest wstrzymany z powodu limitów');
      }
    })
    .catch(err => {
      console.error('❌ Błąd testu Supabase:', err.message);
      if (err.message === 'Timeout') {
        console.error('⏱️  Timeout połączenia - sprawdź sieć i status Supabase');
        console.error('🌐 Sprawdź status na: https://status.supabase.com/');
      }
    });
} else {
  console.warn('⚠️  Supabase nie jest skonfigurowany - aplikacja będzie działać w trybie offline');
}

// Funkcja testująca połączenie
async function testSupabaseConnection(): Promise<{ success: boolean; error?: string }> {
  try {
    // Test 1: Sprawdź czy endpoint odpowiada
    const healthResponse = await fetch(`${supabaseUrl}/rest/v1/`, {
      method: 'GET',
      headers: {
        'apikey': supabaseAnonKey!,
        'Authorization': `Bearer ${supabaseAnonKey!}`
      }
    });

    if (!healthResponse.ok) {
      return { 
        success: false, 
        error: `HTTP ${healthResponse.status}: ${healthResponse.statusText}` 
      };
    }

    // Test 2: Sprawdź auth
    const { data, error } = await supabase.auth.getSession();
    
    if (error) {
      return { 
        success: false, 
        error: `Auth error: ${error.message}` 
      };
    }

    return { success: true };
  } catch (error: any) {
    return { 
      success: false, 
      error: error.message || 'Unknown connection error' 
    };
  }
}

// Eksportuj funkcję sprawdzania konfiguracji
export const isSupabaseReady = () => isSupabaseConfigured;

// Eksportuj funkcję testową
export const testConnection = testSupabaseConnection;

// Typy dla bazy danych
export interface UserProfile {
  id: string;
  user_id: string;
  profile_data: any;
  created_at: string;
  updated_at: string;
}

export interface Conversation {
  id: string;
  user_id: string;
  message_id: string;
  role: 'user' | 'assistant';
  content: string;
  metadata: any;
  created_at: string;
}

// Eksportuj typy Supabase
export type { Session, User } from '@supabase/supabase-js';