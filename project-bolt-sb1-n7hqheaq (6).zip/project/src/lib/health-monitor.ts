export interface HealthCheck {
  name: string;
  status: 'healthy' | 'degraded' | 'unhealthy';
  lastCheck: Date;
  responseTime?: number;
  error?: string;
  metadata?: any;
}

export interface SystemHealth {
  overall: 'healthy' | 'degraded' | 'unhealthy';
  checks: HealthCheck[];
  timestamp: Date;
}

export class HealthMonitor {
  private static instance: HealthMonitor;
  private checks: Map<string, HealthCheck> = new Map();
  private checkInterval: NodeJS.Timeout | null = null;
  private listeners: ((health: SystemHealth) => void)[] = [];

  static getInstance(): HealthMonitor {
    if (!HealthMonitor.instance) {
      HealthMonitor.instance = new HealthMonitor();
    }
    return HealthMonitor.instance;
  }

  // Uruchom monitoring
  startMonitoring(intervalMs: number = 30000): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
    }

    this.checkInterval = setInterval(() => {
      this.runAllChecks();
    }, intervalMs);

    // Uruchom pierwszy check od razu
    this.runAllChecks();
  }

  // Zatrzymaj monitoring
  stopMonitoring(): void {
    if (this.checkInterval) {
      clearInterval(this.checkInterval);
      this.checkInterval = null;
    }
  }

  // Dodaj listener na zmiany stanu
  addListener(callback: (health: SystemHealth) => void): void {
    this.listeners.push(callback);
  }

  // Usuń listener
  removeListener(callback: (health: SystemHealth) => void): void {
    const index = this.listeners.indexOf(callback);
    if (index > -1) {
      this.listeners.splice(index, 1);
    }
  }

  // Uruchom wszystkie sprawdzenia
  private async runAllChecks(): Promise<void> {
    const promises = [
      this.checkBackendHealth(),
      this.checkAnthropicAPI(),
      this.checkSupabaseConnection(),
      this.checkFrontendHealth()
    ];

    await Promise.allSettled(promises);
    this.notifyListeners();
  }

  // Sprawdź backend
  private async checkBackendHealth(): Promise<void> {
    const startTime = Date.now();
    
    try {
      const response = await fetch('/api/health', {
        method: 'GET',
        timeout: 5000
      } as any);

      const responseTime = Date.now() - startTime;
      
      if (response.ok) {
        this.updateCheck('backend', {
          name: 'Backend Server',
          status: 'healthy',
          lastCheck: new Date(),
          responseTime,
          metadata: { port: 3002 }
        });
      } else {
        throw new Error(`HTTP ${response.status}`);
      }
    } catch (error) {
      this.updateCheck('backend', {
        name: 'Backend Server',
        status: 'unhealthy',
        lastCheck: new Date(),
        error: error.message,
        metadata: { port: 3002 }
      });
    }
  }

  // Sprawdź Anthropic API
  private async checkAnthropicAPI(): Promise<void> {
    try {
      const response = await fetch('/api/health');
      const data = await response.json();
      
      if (data.anthropic_configured) {
        this.updateCheck('anthropic', {
          name: 'Anthropic API',
          status: 'healthy',
          lastCheck: new Date(),
          metadata: { configured: true }
        });
      } else {
        this.updateCheck('anthropic', {
          name: 'Anthropic API',
          status: 'degraded',
          lastCheck: new Date(),
          error: 'API not configured',
          metadata: { configured: false }
        });
      }
    } catch (error) {
      this.updateCheck('anthropic', {
        name: 'Anthropic API',
        status: 'unhealthy',
        lastCheck: new Date(),
        error: error.message
      });
    }
  }

  // Sprawdź Supabase
  private async checkSupabaseConnection(): Promise<void> {
    try {
      const { supabase } = await import('../lib/supabase');
      const { data, error } = await supabase.auth.getSession();
      
      if (error) {
        throw error;
      }

      this.updateCheck('supabase', {
        name: 'Supabase Database',
        status: 'healthy',
        lastCheck: new Date(),
        metadata: { connected: true }
      });
    } catch (error) {
      this.updateCheck('supabase', {
        name: 'Supabase Database',
        status: 'degraded',
        lastCheck: new Date(),
        error: error.message,
        metadata: { connected: false }
      });
    }
  }

  // Sprawdź frontend
  private checkFrontendHealth(): void {
    // Sprawdź czy główne komponenty są załadowane
    const hasReact = typeof React !== 'undefined';
    const hasDOM = typeof document !== 'undefined';
    
    if (hasReact && hasDOM) {
      this.updateCheck('frontend', {
        name: 'Frontend App',
        status: 'healthy',
        lastCheck: new Date(),
        metadata: { 
          react: hasReact,
          dom: hasDOM,
          url: window.location.href
        }
      });
    } else {
      this.updateCheck('frontend', {
        name: 'Frontend App',
        status: 'unhealthy',
        lastCheck: new Date(),
        error: 'Missing dependencies',
        metadata: { react: hasReact, dom: hasDOM }
      });
    }
  }

  // Aktualizuj sprawdzenie
  private updateCheck(key: string, check: HealthCheck): void {
    this.checks.set(key, check);
  }

  // Powiadom listenerów
  private notifyListeners(): void {
    const health = this.getSystemHealth();
    this.listeners.forEach(callback => callback(health));
  }

  // Pobierz ogólny stan systemu
  getSystemHealth(): SystemHealth {
    const checks = Array.from(this.checks.values());
    
    // Określ ogólny stan
    let overall: 'healthy' | 'degraded' | 'unhealthy' = 'healthy';
    
    const unhealthyCount = checks.filter(c => c.status === 'unhealthy').length;
    const degradedCount = checks.filter(c => c.status === 'degraded').length;
    
    if (unhealthyCount > 0) {
      overall = 'unhealthy';
    } else if (degradedCount > 0) {
      overall = 'degraded';
    }

    return {
      overall,
      checks,
      timestamp: new Date()
    };
  }

  // Pobierz konkretne sprawdzenie
  getCheck(name: string): HealthCheck | undefined {
    return this.checks.get(name);
  }

  // Sprawdź czy system jest zdrowy
  isHealthy(): boolean {
    return this.getSystemHealth().overall === 'healthy';
  }
}

// Singleton instance
export const healthMonitor = HealthMonitor.getInstance();