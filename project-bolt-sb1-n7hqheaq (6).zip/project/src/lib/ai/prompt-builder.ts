import { SearchResult } from '../../types/chunks';
import { PersonalityType, ConversationStage } from '../../agents/alex-config';
import { CrisisSignals } from '../agent/crisis-detector';
import { UserProfile } from '../agent/user-profiler';
import { CalendarIntent } from '../agent/calendar-detector';

export interface PromptContext {
  userMessage: string;
  conversationHistory: string[];
  relevantChunks: SearchResult[];
  personalityType: PersonalityType | null;
  conversationStage: ConversationStage | null;
  crisisSignals: CrisisSignals;
  userProfile: UserProfile;
  calendarIntent?: CalendarIntent;
  systemPrompt: string;
}

export class PromptBuilder {
  buildPrompt(context: PromptContext): string {
    const {
      userMessage,
      conversationHistory,
      relevantChunks,
      personalityType,
      conversationStage,
      crisisSignals,
      userProfile,
      calendarIntent,
      systemPrompt
    } = context;

    let prompt = systemPrompt + '\n\n';

    // Dodaj kontekst kryzysu jeśli wykryty
    if (crisisSignals.isCrisis) {
      prompt += this.buildCrisisContext(crisisSignals);
    }

    // Dodaj kontekst profilu użytkownika
    prompt += this.buildUserContext(userProfile, personalityType);

    // Dodaj kontekst etapu rozmowy
    if (conversationStage) {
      prompt += this.buildStageContext(conversationStage);
    }
    
    // Dodaj kontekst kalendarza jeśli wykryty
    if (calendarIntent?.hasCalendarIntent) {
      prompt += this.buildCalendarContext(calendarIntent);
    }

    // Dodaj relevantną wiedzę z chunków
    if (relevantChunks.length > 0) {
      prompt += this.buildKnowledgeContext(relevantChunks);
    }

    // Dodaj historię rozmowy (ostatnie 6 wiadomości)
    if (conversationHistory.length > 0) {
      prompt += this.buildConversationContext(conversationHistory);
    }

    // Dodaj wskazówki metody sokratejskiej
    prompt += this.buildSocraticGuidance(context);

    // Dodaj aktualną wiadomość użytkownika
    prompt += `\n### AKTUALNA WIADOMOŚĆ UŻYTKOWNIKA ###\n${userMessage}\n\n`;

    // Dodaj instrukcje odpowiedzi
    prompt += this.buildResponseInstructions(crisisSignals, personalityType);
    
    // Sprawdź czy pytanie dotyczy systemu 3F
    if (this.isSystem3FQuery(userMessage)) {
      prompt += this.buildSystem3FInstructions();
    }

    return prompt;
  }
  
  private isSystem3FQuery(userMessage: string): boolean {
    const message = userMessage.toLowerCase();
    const system3fKeywords = [
      'system 3f', 'system 3-f', '3f', 'system 3 f',
      'foundation', 'fundament', 'fuel', 'focus', 'fokus',
      'wartość', 'wartosci', 'misja', 'małe kroki', 'male kroki',
      'supermoc', 'rakieta', 'działania'
    ];
    
    return system3fKeywords.some(keyword => message.includes(keyword));
  }
  
  private buildSystem3FInstructions(): string {
    return `\n### INSTRUKCJE DOTYCZĄCE SYSTEMU 3F ###
Użytkownik pyta o System 3F. Wyjaśnij go jasno i zwięźle:

1. FOUNDATION (Fundament): Główna wartość życiowa, która daje energię i sens
   - Jedna wartość (nie wiele), np. Wolność, Tworzenie, Pomaganie, Rozwój
   - Działa jak kompas życiowy i źródło motywacji

2. FUEL (Paliwo): Misja życiowa łącząca wartość z konkretnym obszarem
   - Formuła: "[Wartość] + [Obszar życia]"
   - Np. "Wolność + Kariera = Tworzę biznes dający niezależność"

3. FOCUS (Fokus): Małe, codzienne działania prowadzące do realizacji misji
   - Małe kroki, które są wykonywalne codziennie
   - System 5 Zwycięstw Dziennie - małe sukcesy budujące momentum

Podkreśl, że system działa tylko gdy wszystkie 3 elementy są spójne i połączone.
`;
  }

  private buildCrisisContext(crisisSignals: CrisisSignals): string {
    if (!crisisSignals.isCrisis) return '';

    return `### ALERT KRYZYSOWY ###
WYKRYTO KRYZYS - POZIOM: ${crisisSignals.severity.toUpperCase()}
Słowa kluczowe: ${crisisSignals.detectedKeywords.join(', ')}
Stan emocjonalny: ${crisisSignals.emotionalState}
Zalecane działanie: ${crisisSignals.recommendedAction}

INSTRUKCJA KRYZYSOWA:
- NIE dawaj standardowych rad produktywności
- Użyj Protokołu Emocjonalnego (STOP-BREATHE-GROUND-CHOOSE-ACT)
- Bądź wspierający, nie motywujący
- Skup się na stabilizacji emocjonalnej
- Krótkie, łagodne odpowiedzi

`;
  }

  private buildUserContext(userProfile: UserProfile, personalityType: PersonalityType | null): string {
    let context = '### PROFIL UŻYTKOWNIKA ###\n';
    
    if (personalityType) {
      context += `Typ osobowości: ${personalityType.name}\n`;
      context += `Preferowany styl: ${userProfile.preferredCommunicationStyle}\n`;
      context += `Unikaj słów: ${personalityType.avoidWords.join(', ')}\n`;
    }

    context += `Poziom zaawansowania: ${userProfile.progressLevel}\n`;

    if (userProfile.successfulStrategies.length > 0) {
      context += `Skuteczne strategie: ${userProfile.successfulStrategies.join(', ')}\n`;
    }

    if (userProfile.commonTriggers.length > 0) {
      context += `Główne triggery: ${userProfile.commonTriggers.slice(0, 3).join(', ')}\n`;
    }

    return context + '\n';
  }

  private buildStageContext(stage: ConversationStage): string {
    return `### ETAP ROZMOWY ###
Obecny etap: ${stage.name}
Opis: ${stage.id}
Możliwe następne etapy: ${stage.nextStages.join(', ')}

`;
  }
  
  private buildSocraticGuidance(context: PromptContext): string {
    // Import ConversationFlowManager dynamically to avoid circular dependency
    const { conversationHistory, userMessage, personalityType } = context;
    
    // Symuluj logikę SocraticMethodDetector
    const message = userMessage.toLowerCase();
    
    // Sprawdź czy user ma pomysły
    const hasIdeas = [
      'myślę że', 'może to przez', 'chyba powinienem',
      'mam pomysł', 'zastanawiam się czy', 'może spróbuję',
      'nie wiem czy to dobry pomysł', 'może by tak'
    ].some(indicator => message.includes(indicator));
    
    // Sprawdź czy user zagubiony
    const isLost = [
      'nie wiem od czego zacząć', 'chaos totalny', 'kompletnie nie wiem',
      'jestem zagubiony', 'nie mam pojęcia', 'bez planu'
    ].some(indicator => message.includes(indicator));
    
    // Sprawdź kryzys
    const isCrisis = [
      'wszystko się wali', 'nie mogę się zmusić', 'paraliż',
      'chcę się poddać', 'nie mam siły', 'to nie ma sensu'
    ].some(indicator => message.includes(indicator));
    
    // Sprawdź "nie wiem" response
    const isDontKnow = [
      'nie wiem', 'bez pojęcia', 'nie mam pojęcia',
      'nie jestem pewny', 'trudno powiedzieć'
    ].some(indicator => message.includes(indicator));
    
    // Policz pytania w ostatnich odpowiedziach ALEX-a
    const recentAlexResponses = conversationHistory
      .filter((msg, index) => index % 2 === 1) // Nieparzyste indeksy = Alex
      .slice(-2); // Ostatnie 2 odpowiedzi
    
    const questionCount = recentAlexResponses.filter(response => 
      response.includes('?') || response.includes('co myślisz') || response.includes('jak sądzisz')
    ).length;
    
    let guidance = '\n### METODA SOKRATEJSKA ###\n';
    
    if (isCrisis) {
      guidance += 'KRYZYS! Zero pytań, tylko protokół ratunkowy i wsparcie.\n';
    } else if (isLost) {
      guidance += 'User zagubiony. Dawaj konkretną pomoc z chunków, nie pytaj.\n';
    } else if (isDontKnow && questionCount > 0) {
      guidance += 'User odpowiedział "nie wiem" na pytanie. Przejdź do dawania konkretnej pomocy.\n';
    } else if (hasIdeas && questionCount < 2) {
      guidance += 'User ma pomysły! Zadaj pytanie prowadzące do odkrycia.\n';
      guidance += 'Przykłady pytań:\n';
      guidance += '- "Co sprawia że wątpisz w ten pomysł?"\n';
      guidance += '- "Który sposób wydaje ci się najbardziej realny?"\n';
      guidance += '- "Jak myślisz, co by się stało gdybyś spróbował?"\n';
    } else if (questionCount >= 2) {
      guidance += 'Już 2 pytania zadane. Teraz dawaj konkretną pomoc z chunków.\n';
    } else {
      guidance += 'Standardowa odpowiedź z chunkami i konkretną pomocą.\n';
    }
    
    guidance += `Licznik pytań: ${questionCount}/2\n`;
    
    return guidance + '\n';
  }
  
  private buildCalendarContext(calendarIntent: CalendarIntent): string {
    let context = '\n### INTENCJA KALENDARZOWA ###\n';
    context += `Wykryto intencję kalendarzową: ${calendarIntent.action}\n`;
    context += `Pewność: ${Math.round(calendarIntent.confidence * 100)}%\n`;
    
    if (calendarIntent.eventText) {
      context += `Tekst wydarzenia: "${calendarIntent.eventText}"\n`;
    }
    
    switch (calendarIntent.action) {
      case 'add_event':
        context += '\nINSTRUKCJA: Zapytaj czy user chce dodać to wydarzenie do kalendarza.\n';
        context += 'Przykład: "Czy mam dodać to do Twojego kalendarza?"\n';
        break;
      case 'check_schedule':
        context += '\nINSTRUKCJA: Poinformuj że sprawdzasz kalendarz.\n';
        break;
      case 'remind':
        context += '\nINSTRUKCJA: Potwierdź ustawienie przypomnienia.\n';
        break;
    }
    
    return context + '\n';
  }

  private buildKnowledgeContext(chunks: SearchResult[]): string {
    let context = '### DOSTĘPNA WIEDZA SPECJALISTYCZNA ###\n';
    
    // Sprawdź czy mamy chunki systemu 3F
    const hasSystem3F = chunks.some(result => 
      result.chunk.tags.includes('system_3F') || 
      result.chunk.id.includes('FUNDAMENT') || 
      result.chunk.id.includes('FUEL') || 
      result.chunk.id.includes('FOKUS')
    );
    
    // Jeśli mamy chunki systemu 3F, dodaj specjalny opis
    if (hasSystem3F) {
      context += `\n### SYSTEM 3F ###\nSystem 3F to framework do walki z prokrastynacją oparty na trzech filarach:\n`;
      context += `- FOUNDATION (Fundament): Twoja główna wartość, która daje ci energię i sens\n`;
      context += `- FUEL (Paliwo): Twoja misja życiowa, łącząca wartość z konkretnym obszarem\n`;
      context += `- FOCUS (Fokus): Małe, codzienne działania prowadzące do realizacji misji\n\n`;
    }
    
    chunks.forEach((result, index) => {
      const chunk = result.chunk;
      context += `\n[CHUNK ${index + 1}: ${chunk.title}]\n`;
      context += `Kategoria: ${chunk.category}\n`;
      context += `Tagi: ${chunk.tags.join(', ')}\n`;
      context += `Treść: ${chunk.content}\n`;
    });
    
    return context + '\n';
  }

  private buildConversationContext(conversationHistory: string[]): string {
    if (conversationHistory.length === 0) return '';

    let context = '### HISTORIA ROZMOWY ###\n';
    
    // Weź ostatnie 6 wiadomości
    const recentHistory = conversationHistory.slice(-6);
    
    recentHistory.forEach((message, index) => {
      context += `${index + 1}. ${message}\n`;
    });
    
    return context + '\n';
  }

  private buildResponseInstructions(crisisSignals: CrisisSignals, personalityType: PersonalityType | null): string {
    let instructions = '### INSTRUKCJE ODPOWIEDZI ###\n';

    if (crisisSignals.isCrisis) {
      instructions += `TRYB KRYZYSOWY - użyj protokołu emocjonalnego, bądź wspierający.\n`;
    } else {
      instructions += `TRYB STANDARDOWY - dawaj praktyczne rady i konkretne kroki.\n`;
    }

    if (personalityType) {
      switch (personalityType.id) {
        case 'buntownik':
          instructions += `Typ: BUNTOWNIK - dawaj opcje do wyboru, unikaj nakazów.\n`;
          break;
        case 'marzyciel':
          instructions += `Typ: MARZYCIEL - struktura + elastyczność, przypominaj o celach.\n`;
          break;
        case 'perfekcjonista':
          instructions += `Typ: PERFEKCJONISTA - podkreślaj postęp, nie perfekcję.\n`;
          break;
      }
    }

    instructions += `
STRUKTURA ODPOWIEDZI:
1. Zrozumienie problemu (1 zdanie)
2. Konkretna rada z wykorzystaniem wiedzy (1-2 zdania)
3. Następny krok do wykonania TERAZ (1 zdanie)
4. Motywacja/wsparcie (1 zdanie)

MAKSYMALNIE 4 zdania. Bądź konkretny, praktyczny i wspierający.`;

    return instructions;
  }

  private buildEmotionalContext(emotionalState: EmotionalState): string {
    if (!emotionalState.needsResponse || emotionalState.primary === 'neutralny') {
      return '';
    }

    let context = `### STAN EMOCJONALNY UŻYTKOWNIKA ###\n`;
    context += `Emocja główna: ${emotionalState.primary} (intensywność: ${Math.round(emotionalState.intensity * 10)}/10)\n`;
    
    if (emotionalState.secondary) {
      context += `Emocja drugorzędna: ${emotionalState.secondary}\n`;
    }
    
    if (emotionalState.trigger) {
      context += `Wyzwalacz: "${emotionalState.trigger}"\n`;
    }

    // Add response guidance based on emotion
    context += this.getEmotionalResponseGuidance(emotionalState);

    return context + '\n';
  }

  // Metoda do budowania promptu dla ćwiczeń
  buildExercisePrompt(exerciseChunk: SearchResult, userMessage: string): string {
    const chunk = exerciseChunk.chunk;
    
    return `### PROWADZENIE PRZEZ ĆWICZENIE ###

Użytkownik chce wykonać ćwiczenie: "${chunk.title}"

ĆWICZENIE:
${chunk.content}

WIADOMOŚĆ UŻYTKOWNIKA: ${userMessage}

INSTRUKCJE:
- Przeprowadź użytkownika przez ćwiczenie krok po kroku
- Nie dawaj wszystkich kroków naraz - tylko następny krok
- Sprawdzaj czy użytkownik wykonał krok przed przejściem dalej
- Bądź cierpliwy i wspierający
- Dostosuj tempo do użytkownika

Zacznij od pierwszego kroku ćwiczenia.`;
  }

  // Metoda do debugowania - pokazuje zbudowany prompt
  debugPrompt(context: PromptContext): void {
    const prompt = this.buildPrompt(context);
    console.log('=== ZBUDOWANY PROMPT ===');
    console.log(prompt);
    console.log('=== KONIEC PROMPTU ===');
  }
}

export default PromptBuilder;