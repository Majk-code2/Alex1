export interface RetryConfig {
  maxAttempts: number;
  baseDelay: number;
  maxDelay: number;
  backoffMultiplier: number;
  retryCondition?: (error: Error) => boolean;
}

export interface CircuitBreakerConfig {
  failureThreshold: number;
  resetTimeout: number;
  monitoringPeriod: number;
}

// Retry mechanism z exponential backoff
export class RetryManager {
  static async withRetry<T>(
    operation: () => Promise<T>,
    config: Partial<RetryConfig> = {}
  ): Promise<T> {
    const {
      maxAttempts = 3,
      baseDelay = 1000,
      maxDelay = 10000,
      backoffMultiplier = 2,
      retryCondition = (error) => this.isRetryableError(error)
    } = config;

    let lastError: Error;
    
    for (let attempt = 1; attempt <= maxAttempts; attempt++) {
      try {
        return await operation();
      } catch (error) {
        lastError = error as Error;
        
        // Nie retry jeśli to ostatnia próba lub błąd nie jest retryable
        if (attempt === maxAttempts || !retryCondition(lastError)) {
          throw lastError;
        }

        // Oblicz delay z exponential backoff
        const delay = Math.min(
          baseDelay * Math.pow(backoffMultiplier, attempt - 1),
          maxDelay
        );

        console.warn(`Retry attempt ${attempt}/${maxAttempts} after ${delay}ms. Error:`, lastError.message);
        
        await this.sleep(delay);
      }
    }

    throw lastError!;
  }

  private static isRetryableError(error: Error): boolean {
    const retryablePatterns = [
      'ECONNREFUSED',
      'ETIMEDOUT',
      'ENOTFOUND',
      'timeout',
      '429', // Rate limit
      '502', // Bad Gateway
      '503', // Service Unavailable
      '504'  // Gateway Timeout
    ];

    return retryablePatterns.some(pattern => 
      error.message.includes(pattern)
    );
  }

  private static sleep(ms: number): Promise<void> {
    return new Promise(resolve => setTimeout(resolve, ms));
  }
}

// Circuit Breaker pattern
export class CircuitBreaker {
  private state: 'CLOSED' | 'OPEN' | 'HALF_OPEN' = 'CLOSED';
  private failureCount = 0;
  private lastFailureTime = 0;
  private successCount = 0;

  constructor(private config: CircuitBreakerConfig) {}

  async execute<T>(operation: () => Promise<T>): Promise<T> {
    if (this.state === 'OPEN') {
      if (Date.now() - this.lastFailureTime > this.config.resetTimeout) {
        this.state = 'HALF_OPEN';
        this.successCount = 0;
        console.log('Circuit breaker: OPEN -> HALF_OPEN');
      } else {
        throw new Error('Circuit breaker is OPEN');
      }
    }

    try {
      const result = await operation();
      this.onSuccess();
      return result;
    } catch (error) {
      this.onFailure();
      throw error;
    }
  }

  private onSuccess(): void {
    this.failureCount = 0;
    
    if (this.state === 'HALF_OPEN') {
      this.successCount++;
      if (this.successCount >= 3) { // Wymagane 3 sukcesy aby zamknąć
        this.state = 'CLOSED';
        console.log('Circuit breaker: HALF_OPEN -> CLOSED');
      }
    }
  }

  private onFailure(): void {
    this.failureCount++;
    this.lastFailureTime = Date.now();

    if (this.failureCount >= this.config.failureThreshold) {
      this.state = 'OPEN';
      console.log('Circuit breaker: CLOSED -> OPEN');
    }
  }

  getState(): string {
    return this.state;
  }

  getStats(): { state: string; failures: number; lastFailure: number } {
    return {
      state: this.state,
      failures: this.failureCount,
      lastFailure: this.lastFailureTime
    };
  }
}

// Graceful degradation manager
export class GracefulDegradation {
  private static fallbacks: Map<string, () => any> = new Map();

  static registerFallback(service: string, fallback: () => any): void {
    this.fallbacks.set(service, fallback);
  }

  static async executeWithFallback<T>(
    service: string,
    operation: () => Promise<T>,
    fallbackValue?: T
  ): Promise<T> {
    try {
      return await operation();
    } catch (error) {
      console.warn(`Service ${service} failed, using fallback:`, error.message);
      
      // Użyj zarejestrowanego fallback
      const fallback = this.fallbacks.get(service);
      if (fallback) {
        return fallback();
      }

      // Użyj podanej wartości fallback
      if (fallbackValue !== undefined) {
        return fallbackValue;
      }

      // Ostateczny fallback - rzuć błąd
      throw new Error(`Service ${service} unavailable and no fallback provided`);
    }
  }
}

// Timeout wrapper
export class TimeoutManager {
  static withTimeout<T>(
    operation: () => Promise<T>,
    timeoutMs: number,
    timeoutMessage = 'Operation timed out'
  ): Promise<T> {
    return Promise.race([
      operation(),
      new Promise<never>((_, reject) => 
        setTimeout(() => reject(new Error(timeoutMessage)), timeoutMs)
      )
    ]);
  }
}

// Eksportuj gotowe konfiguracje
export const defaultRetryConfig: RetryConfig = {
  maxAttempts: 3,
  baseDelay: 1000,
  maxDelay: 10000,
  backoffMultiplier: 2
};

export const defaultCircuitBreakerConfig: CircuitBreakerConfig = {
  failureThreshold: 5,
  resetTimeout: 60000, // 1 minuta
  monitoringPeriod: 10000 // 10 sekund
};