import { google } from 'googleapis';

export interface CalendarEvent {
  summary: string;
  description?: string;
  start: {
    dateTime: string;
    timeZone: string;
  };
  end: {
    dateTime: string;
    timeZone: string;
  };
  reminders?: {
    useDefault: boolean;
    overrides?: Array<{
      method: 'email' | 'popup';
      minutes: number;
    }>;
  };
}

export interface CalendarCredentials {
  access_token: string;
  refresh_token?: string;
  scope: string;
  token_type: string;
  expiry_date?: number;
}

export class GoogleCalendarService {
  private oauth2Client: any;
  private calendar: any;

  constructor() {
    this.oauth2Client = new google.auth.OAuth2(
      import.meta.env.VITE_GOOGLE_CLIENT_ID,
      import.meta.env.VITE_GOOGLE_CLIENT_SECRET,
      import.meta.env.VITE_GOOGLE_REDIRECT_URI || 'http://localhost:5173/auth/callback'
    );

    this.calendar = google.calendar({ version: 'v3', auth: this.oauth2Client });
  }

  // Generuj URL autoryzacji
  getAuthUrl(): string {
    const scopes = [
      'https://www.googleapis.com/auth/calendar',
      'https://www.googleapis.com/auth/calendar.events'
    ];

    return this.oauth2Client.generateAuthUrl({
      access_type: 'offline',
      scope: scopes,
      prompt: 'consent'
    });
  }

  // Ustaw credentials
  setCredentials(credentials: CalendarCredentials): void {
    this.oauth2Client.setCredentials(credentials);
  }

  // Pobierz token z kodu autoryzacji
  async getTokenFromCode(code: string): Promise<CalendarCredentials> {
    const { tokens } = await this.oauth2Client.getToken(code);
    this.oauth2Client.setCredentials(tokens);
    return tokens as CalendarCredentials;
  }

  // Dodaj wydarzenie do kalendarza
  async addEvent(event: CalendarEvent, calendarId: string = 'primary'): Promise<any> {
    try {
      const response = await this.calendar.events.insert({
        calendarId,
        resource: event,
      });

      return {
        success: true,
        eventId: response.data.id,
        htmlLink: response.data.htmlLink,
        data: response.data
      };
    } catch (error) {
      console.error('Błąd podczas dodawania wydarzenia:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Pobierz nadchodzące wydarzenia
  async getUpcomingEvents(maxResults: number = 10): Promise<any> {
    try {
      const response = await this.calendar.events.list({
        calendarId: 'primary',
        timeMin: new Date().toISOString(),
        maxResults,
        singleEvents: true,
        orderBy: 'startTime',
      });

      return {
        success: true,
        events: response.data.items || []
      };
    } catch (error) {
      console.error('Błąd podczas pobierania wydarzeń:', error);
      return {
        success: false,
        error: error.message
      };
    }
  }

  // Sprawdź czy użytkownik jest zalogowany
  isAuthenticated(): boolean {
    const credentials = this.oauth2Client.credentials;
    return !!(credentials && credentials.access_token);
  }

  // Wyloguj użytkownika
  logout(): void {
    this.oauth2Client.setCredentials({});
  }
}

// Singleton instance
export const googleCalendar = new GoogleCalendarService();

// Funkcje pomocnicze do parsowania dat z języka naturalnego
export class DateParser {
  static parseNaturalDate(text: string): { start: Date; end: Date } | null {
    const now = new Date();
    const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    
    // Wzorce dla różnych formatów dat
    const patterns = [
      // "jutro o 14:00"
      {
        regex: /jutro o (\d{1,2}):(\d{2})/i,
        handler: (match: RegExpMatchArray) => {
          const tomorrow = new Date(today);
          tomorrow.setDate(tomorrow.getDate() + 1);
          tomorrow.setHours(parseInt(match[1]), parseInt(match[2]), 0, 0);
          const end = new Date(tomorrow);
          end.setHours(end.getHours() + 1); // Domyślnie 1 godzina
          return { start: tomorrow, end };
        }
      },
      // "dziś o 15:30"
      {
        regex: /dziś o (\d{1,2}):(\d{2})/i,
        handler: (match: RegExpMatchArray) => {
          const todayTime = new Date(today);
          todayTime.setHours(parseInt(match[1]), parseInt(match[2]), 0, 0);
          const end = new Date(todayTime);
          end.setHours(end.getHours() + 1);
          return { start: todayTime, end };
        }
      },
      // "w poniedziałek o 10:00"
      {
        regex: /w (poniedziałek|wtorek|środę|czwartek|piątek|sobotę|niedzielę) o (\d{1,2}):(\d{2})/i,
        handler: (match: RegExpMatchArray) => {
          const dayNames = {
            'poniedziałek': 1, 'wtorek': 2, 'środę': 3, 'czwartek': 4,
            'piątek': 5, 'sobotę': 6, 'niedzielę': 0
          };
          const targetDay = dayNames[match[1].toLowerCase() as keyof typeof dayNames];
          const currentDay = now.getDay();
          
          let daysToAdd = targetDay - currentDay;
          if (daysToAdd <= 0) daysToAdd += 7; // Następny tydzień
          
          const targetDate = new Date(today);
          targetDate.setDate(targetDate.getDate() + daysToAdd);
          targetDate.setHours(parseInt(match[2]), parseInt(match[3]), 0, 0);
          
          const end = new Date(targetDate);
          end.setHours(end.getHours() + 1);
          return { start: targetDate, end };
        }
      },
      // "za 2 godziny"
      {
        regex: /za (\d+) godzin[yę]?/i,
        handler: (match: RegExpMatchArray) => {
          const start = new Date(now);
          start.setHours(start.getHours() + parseInt(match[1]));
          const end = new Date(start);
          end.setHours(end.getHours() + 1);
          return { start, end };
        }
      }
    ];

    for (const pattern of patterns) {
      const match = text.match(pattern.regex);
      if (match) {
        return pattern.handler(match);
      }
    }

    return null;
  }

  static extractEventDetails(text: string): {
    title: string;
    description?: string;
    duration?: number;
    reminder?: number;
  } {
    // Wyciągnij tytuł (pierwsza część przed "o" lub "na")
    const titleMatch = text.match(/^([^o]+?)(?:\s+o\s+\d|$)/i);
    const title = titleMatch ? titleMatch[1].trim() : text.split(' ').slice(0, 3).join(' ');

    // Sprawdź czy jest określony czas trwania
    const durationMatch = text.match(/przez (\d+) (?:godzin[yę]?|minut)/i);
    let duration = 60; // Domyślnie 1 godzina w minutach
    
    if (durationMatch) {
      const value = parseInt(durationMatch[1]);
      duration = text.includes('minut') ? value : value * 60;
    }

    // Sprawdź przypomnienie
    const reminderMatch = text.match(/przypomnij (\d+) minut wcześniej/i);
    const reminder = reminderMatch ? parseInt(reminderMatch[1]) : 15; // Domyślnie 15 minut

    return {
      title: title.charAt(0).toUpperCase() + title.slice(1),
      description: `Wydarzenie dodane przez ALEX Coach`,
      duration,
      reminder
    };
  }
}