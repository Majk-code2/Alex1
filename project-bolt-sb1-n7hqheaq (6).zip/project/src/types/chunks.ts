// TypeScript interfaces dla systemu RAG
export interface Chunk {
  id: string;
  title: string;
  content: string;
  category: string;
  subcategory?: string;
  tags: string[];
  difficulty_level?: 'basic' | 'intermediate' | 'advanced';
  estimated_time?: number;
  trigger_words?: string[];
  anti_trigger_words?: string[];
  user_personas?: string[];
  prerequisites?: string[];
  related_chunks?: string[];
  priority: number; // 1-10, wyższe = ważniejsze
  lastUpdated: Date;
}

export interface SearchResult {
  chunk: Chunk;
  score: number; // 0-1, wyższe = lepsze dopasowanie
  matchedTerms: string[];
}

export interface ChunkDatabase {
  chunks: Chunk[];
  categories: string[];
  tags: string[];
  lastUpdated: Date;
}