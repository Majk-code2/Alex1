const Anthropic = require('@anthropic-ai/sdk');

const anthropic = new Anthropic({
  apiKey: process.env.ANTHROPIC_API_KEY,
});

const handler = async (event, context) => {
  // CORS headers
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'POST, OPTIONS',
  };

  // Handle preflight requests
  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: '',
    };
  }

  if (event.httpMethod !== 'POST') {
    return {
      statusCode: 405,
      headers,
      body: JSON.stringify({ error: 'Method not allowed' }),
    };
  }

  try {
    // Debug logging
    console.log('API Key present:', !!process.env.ANTHROPIC_API_KEY);
    console.log('API Key format:', process.env.ANTHROPIC_API_KEY?.substring(0, 10) + '...');

    const { message, context: messageContext } = JSON.parse(event.body);

    if (!message) {
      return {
        statusCode: 400,
        headers,
        body: JSON.stringify({ error: 'Brak wiadomości w zapytaniu.' }),
      };
    }

    // Check API key
    if (!process.env.ANTHROPIC_API_KEY) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          error: 'ANTHROPIC_API_KEY nie jest ustawiony w zmiennych środowiskowych Netlify',
          fix: 'Dodaj ANTHROPIC_API_KEY w ustawieniach Netlify'
        }),
      };
    }

    // System prompt
    let systemPrompt = "Jesteś ALEX - coach anty-prokrastynacyjny. Odpowiadaj krótko, praktycznie, po polsku. Dawaj konkretne kroki do działania. Bądź motywujący ale rzeczowy.";
    
    if (messageContext && messageContext.trim().length > 0) {
      systemPrompt += `\n\nMasz dostęp do następującej wiedzy specjalistycznej - użyj jej jeśli jest relevantna do pytania użytkownika:\n\n${messageContext}`;
    }

    const response = await anthropic.messages.create({
      model: "claude-3-5-sonnet-20241022",
      max_tokens: 1024,
      system: systemPrompt,
      temperature: 0.7,
      messages: [
        {
          "role": "user", 
          "content": message
        }
      ]
    });

    const assistantResponse = response.content?.[0]?.text || "Przepraszam, nie mogłem uzyskać odpowiedzi.";

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ 
        content: assistantResponse,
        model: response.model,
        usage: response.usage,
        stop_reason: response.stop_reason
      }),
    };

  } catch (error) {
    console.error('Błąd podczas komunikacji z Claude API:', error);
    
    let errorMessage = 'Wystąpił błąd podczas przetwarzania Twojej prośby.';
    let statusCode = 500;
    
    if (error.status === 401) {
      errorMessage = 'Nieprawidłowy klucz API Anthropic.';
      statusCode = 401;
    } else if (error.status === 429) {
      errorMessage = 'Przekroczono limit zapytań. Spróbuj ponownie za chwilę.';
      statusCode = 429;
    } else if (error.status === 400) {
      errorMessage = 'Nieprawidłowe zapytanie do API.';
      statusCode = 400;
    } else if (error.message?.includes('Connection error')) {
      errorMessage = 'Problem z połączeniem do Anthropic API.';
      statusCode = 503;
    }

    return {
      statusCode,
      headers,
      body: JSON.stringify({ 
        error: errorMessage,
        details: error.message,
        timestamp: new Date().toISOString()
      }),
    };
  }
};

// CommonJS export
exports.handler = handler;