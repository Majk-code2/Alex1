const handler = async (event, context) => {
  const headers = {
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Headers': 'Content-Type',
    'Access-Control-Allow-Methods': 'GET, OPTIONS',
  };

  if (event.httpMethod === 'OPTIONS') {
    return {
      statusCode: 200,
      headers,
      body: '',
    };
  }

  try {
    // Sprawdź czy klucz API jest ustawiony
    if (!process.env.ANTHROPIC_API_KEY) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          status: 'error',
          message: 'ANTHROPIC_API_KEY nie jest ustawiony',
          fix: 'Ustaw prawidłowy klucz API w zmiennych środowiskowych Netlify',
          environment: 'netlify'
        }),
      };
    }

    // Sprawdź format klucza
    if (!process.env.ANTHROPIC_API_KEY.startsWith('sk-ant-api') || process.env.ANTHROPIC_API_KEY.includes('your-')) {
      return {
        statusCode: 500,
        headers,
        body: JSON.stringify({ 
          status: 'error',
          message: 'ANTHROPIC_API_KEY ma niepoprawny format lub jest placeholderem',
          fix: 'Wygeneruj nowy klucz API na https://console.anthropic.com/',
          environment: 'netlify'
        }),
      };
    }

    return {
      statusCode: 200,
      headers,
      body: JSON.stringify({ 
        status: 'success',
        message: 'Netlify Functions backend is running',
        anthropic_configured: true,
        environment: 'netlify',
        timestamp: new Date().toISOString(),
        note: 'Running on Netlify Functions',
        api_key_present: !!process.env.ANTHROPIC_API_KEY,
        api_key_format: process.env.ANTHROPIC_API_KEY?.substring(0, 10) + '...'
      }),
    };

  } catch (error) {
    console.error('Health check error:', error);
    
    return {
      statusCode: 500,
      headers,
      body: JSON.stringify({ 
        status: 'error',
        message: 'Health check failed',
        details: error.message,
        environment: 'netlify'
      }),
    };
  }
};

// CommonJS export
exports.handler = handler;