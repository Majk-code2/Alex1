#!/usr/bin/env node

import { spawn } from 'child_process';
import fs from 'fs';

console.log('🔧 Uruchamianie TYLKO serwera backend (port 3002)...\n');

// Sprawdź .env
if (!fs.existsSync('.env')) {
  console.error('❌ Brak pliku .env!');
  console.error('Uruchom: npm run setup-env');
  process.exit(1);
}

// Sprawdź zawartość .env
const envContent = fs.readFileSync('.env', 'utf8');
if (envContent.includes('your-') || envContent.includes('sk-ant-api-your-key-here')) {
  console.error('❌ Plik .env zawiera placeholder values!');
  console.error('Edytuj .env-persistent i uruchom: npm run setup-env');
  process.exit(1);
}

console.log('✅ Plik .env wygląda OK');

// Uruchom tylko backend
console.log('🔧 Uruchamianie serwera backend na porcie 3002...');

const backend = spawn('node', ['server.js'], {
  stdio: 'inherit',
  shell: true,
  env: process.env
});

backend.on('error', (err) => {
  console.error('❌ Błąd backendu:', err.message);
});

backend.on('close', (code) => {
  if (code !== 0) {
    console.log(`⚠️  Backend zakończył się z kodem: ${code}`);
  }
});

// Obsługa zamykania
process.on('SIGINT', () => {
  console.log('\n🛑 Zamykanie serwera backend...');
  backend.kill('SIGTERM');
  process.exit(0);
});

console.log('\n📋 INSTRUKCJE:');
console.log('✅ Backend uruchomiony na porcie 3002');
console.log('📝 Aby uruchomić frontend (port 5173), otwórz NOWY terminal i wpisz:');
console.log('   npm run dev');
console.log('');
console.log('🔄 Aby zatrzymać backend, naciśnij Ctrl+C');
console.log('🌐 Backend API dostępne na: http://localhost:3002');