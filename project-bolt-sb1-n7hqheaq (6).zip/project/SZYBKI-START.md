# 🚀 SZYBKI START - ALEX Agent

## Jedna komenda - wszystko działa

```bash
npm run fix
```

**TO WSZYSTKO!** 🎯

## Co robi ta komenda:

1. ✅ Sprawdza i naprawia konfigurację
2. ✅ Czyści zajęte porty
3. ✅ Uruchamia backend (port 3002)
4. ✅ Testuje API
5. ✅ Uruchamia frontend (port 5173)

## Inne komendy (wszystkie robią to samo):

```bash
npm run dev:full
npm run dev:safe
npm run start
npm run quick-start
npm run fix
```

## Jeśli coś nie działa:

### 1. Sprawdź klucz API:
```bash
npm run check-env
```

### 2. Edytuj klucz API:
```bash
nano .env-persistent
```
Zamień `sk-ant-api03-your-key-here` na prawdziwy klucz z https://console.anthropic.com/

### 3. Uruchom ponownie:
```bash
npm run fix
```

## Kontrola ręczna (jeśli potrzebujesz):

```bash
# Tylko backend
npm run backend

# Tylko frontend (w nowym terminalu)
npm run frontend
```

## Porty:

- **Backend API:** http://localhost:3002
- **Frontend App:** http://localhost:5173

## Zatrzymanie:

```bash
Ctrl+C
```

---

**Teraz wszystko powinno działać od razu!** 🎉