#!/usr/bin/env node

/**
 * Monitor serwera deweloperskiego - automatycznie restartuje gdy spadnie
 */

import { spawn } from 'child_process';
import fs from 'fs';
import path from 'path';
import net from 'net';

let viteProcess = null;
let backendProcess = null;
let restartCount = 0;
let backendRestartCount = 0;
const MAX_RESTARTS = 5;

console.log('🚀 Uruchamiam monitor serwera deweloperskiego...');

function startVite() {
  console.log('📦 Uruchamiam Vite...');
  
  viteProcess = spawn('npm', ['run', 'dev:stable'], {
    stdio: 'inherit',
    shell: true,
    cwd: process.cwd()
  });

  viteProcess.on('close', (code) => {
    console.log(`⚠️  Vite zakończył się z kodem: ${code}`);
    
    if (code !== 0 && restartCount < MAX_RESTARTS) {
      restartCount++;
      console.log(`🔄 Restart ${restartCount}/${MAX_RESTARTS} za 3 sekundy...`);
      
      setTimeout(() => {
        startVite();
      }, 3000);
    } else if (restartCount >= MAX_RESTARTS) {
      console.log('❌ Przekroczono maksymalną liczbę restartów. Sprawdź błędy.');
      process.exit(1);
    }
  });

  viteProcess.on('error', (err) => {
    console.error('❌ Błąd Vite:', err);
  });
}

function startBackend() {
  console.log('🔧 Uruchamiam backend...');
  
  backendProcess = spawn('npm', ['run', 'server'], {
    stdio: 'inherit',
    shell: true,
    cwd: process.cwd()
  });

  backendProcess.on('close', (code) => {
    console.log(`⚠️  Backend zakończył się z kodem: ${code}`);
    
    if (code !== 0 && backendRestartCount < MAX_RESTARTS) {
      backendRestartCount++;
      console.log(`🔄 Restart backendu ${backendRestartCount}/${MAX_RESTARTS} za 3 sekundy...`);
      
      setTimeout(() => {
        startBackend();
      }, 3000);
    } else if (backendRestartCount >= MAX_RESTARTS) {
      console.log('❌ Przekroczono maksymalną liczbę restartów backendu. Sprawdź błędy.');
    }
  });

  backendProcess.on('error', (err) => {
    console.error('❌ Błąd backend:', err);
  });
}

// Graceful shutdown
process.on('SIGINT', () => {
  console.log('\n🛑 Zatrzymuję serwery...');
  
  if (viteProcess) {
    viteProcess.kill('SIGTERM');
  }
  
  if (backendProcess) {
    backendProcess.kill('SIGTERM');
  }
  
  setTimeout(() => {
    process.exit(0);
  }, 2000);
});

// Sprawdź czy port 5173 jest wolny
const server = net.createServer();

server.listen(5173, (err) => {
  if (err) {
    console.log('⚠️  Port 5173 jest zajęty. Próbuję zabić proces...');
    
    // Spróbuj zabić proces na porcie 5173
    const killProcess = spawn('npx', ['kill-port', '5173'], {
      stdio: 'pipe',
      shell: true
    });
    
    killProcess.on('close', (code) => {
      server.close();
      if (code !== 0) {
        console.log('⚠️  kill-port failed, trying fallback...');
        const fallbackKill = process.platform === 'win32' 
          ? spawn('cmd', ['/c', 'for /f "tokens=5" %a in (\'netstat -aon ^| find ":5173"\') do taskkill /f /pid %a'], { stdio: 'pipe', shell: true })
          : spawn('sh', ['-c', 'lsof -ti:5173 | xargs kill -9 2>/dev/null || true'], { stdio: 'pipe', shell: true });
        
        fallbackKill.on('close', () => {
          startVite();
          startBackend();
        });
      } else {
        startVite();
        startBackend();
      }
    });
    
    killProcess.on('error', (err) => {
      console.log(`⚠️  npx kill-port error: ${err.message}, trying fallback...`);
      const fallbackKill = process.platform === 'win32' 
        ? spawn('cmd', ['/c', 'for /f "tokens=5" %a in (\'netstat -aon ^| find ":5173"\') do taskkill /f /pid %a'], { stdio: 'pipe', shell: true })
        : spawn('sh', ['-c', 'lsof -ti:5173 | xargs kill -9 2>/dev/null || true'], { stdio: 'pipe', shell: true });
      
      fallbackKill.on('close', () => {
        server.close();
        startVite();
        startBackend();
      });
    });
  } else {
    server.close();
    startVite();
    startBackend();
  }
});

// Reset licznika restartów co 5 minut
setInterval(() => {
  if (restartCount > 0) {
    console.log('🔄 Reset licznika restartów');
    restartCount = 0;
  }
  if (backendRestartCount > 0) {
    console.log('🔄 Reset licznika restartów backendu');
    backendRestartCount = 0;
  }
}, 5 * 60 * 1000);