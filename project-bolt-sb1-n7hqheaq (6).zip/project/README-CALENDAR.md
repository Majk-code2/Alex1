# Integracja Google Calendar z ALEX

## Konfiguracja

### 1. Utwórz projekt w Google Cloud Console

1. Idź do [Google Cloud Console](https://console.cloud.google.com/)
2. Utwórz nowy projekt lub wybierz istniejący
3. Włącz Google Calendar API:
   - Idź do "APIs & Services" > "Library"
   - Wyszukaj "Google Calendar API"
   - Kliknij "Enable"

### 2. Utwórz OAuth 2.0 credentials

1. Idź do "APIs & Services" > "Credentials"
2. Kliknij "Create Credentials" > "OAuth client ID"
3. Wybierz "Web application"
4. Dodaj authorized redirect URIs:
   - `http://localhost:5173/auth/callback` (development)
   - `https://yourdomain.com/auth/callback` (production)
5. Skopiuj Client ID i Client Secret

### 3. Skonfiguruj zmienne środowiskowe

Dodaj do pliku `.env`:

```env
VITE_GOOGLE_CLIENT_ID=your-google-client-id-here
VITE_GOOGLE_CLIENT_SECRET=your-google-client-secret-here
VITE_GOOGLE_REDIRECT_URI=http://localhost:5173/auth/callback
```

## Funkcjonalności

### 1. Automatyczne wykrywanie intencji kalendarzowych

ALEX automatycznie wykrywa gdy użytkownik chce:
- Dodać wydarzenie: "spotkanie jutro o 14:00"
- Sprawdzić kalendarz: "co mam dziś zaplanowane?"
- Ustawić przypomnienie: "przypomnij mi o treningu"

### 2. Parsowanie języka naturalnego

Obsługiwane formaty dat:
- "jutro o 14:00"
- "dziś o 15:30"
- "w poniedziałek o 10:00"
- "za 2 godziny"
- "w piątek wieczorem"

### 3. Inteligentne sugestie

ALEX:
- Pyta o potwierdzenie przed dodaniem wydarzenia
- Automatycznie ustawia przypomnienia
- Pokazuje nadchodzące wydarzenia
- Generuje linki do Google Calendar

## Przykłady użycia

### Dodawanie wydarzeń

**Użytkownik:** "Mam spotkanie z klientem jutro o 15:00"
**ALEX:** "Wykryłem że chcesz zaplanować spotkanie. Czy mam dodać 'Spotkanie z klientem' do Twojego kalendarza na jutro o 15:00?"
**Użytkownik:** "Tak"
**ALEX:** "✅ Dodałem wydarzenie do kalendarza!"

### Sprawdzanie kalendarza

**Użytkownik:** "Co mam dziś zaplanowane?"
**ALEX:** "Sprawdzam Twój kalendarz..." [pokazuje panel kalendarza]

### Przypomnienia

**Użytkownik:** "Przypomnij mi o treningu w piątek o 18:00"
**ALEX:** "Ustawiam przypomnienie o treningu. Dostaniesz powiadomienie 15 minut wcześniej."

## Bezpieczeństwo

- Tokeny OAuth są przechowywane lokalnie w localStorage
- Komunikacja z Google API jest szyfrowana (HTTPS)
- Aplikacja ma dostęp tylko do kalendarza, nie do innych danych Google
- Użytkownik może w każdej chwili odłączyć integrację

## Rozwiązywanie problemów

### Błąd autoryzacji
- Sprawdź czy Client ID i Secret są poprawne
- Upewnij się że redirect URI jest dodany w Google Console
- Sprawdź czy Google Calendar API jest włączone

### Błędy parsowania dat
- Używaj jasnych formatów: "jutro o 14:00"
- Unikaj skomplikowanych wyrażeń czasowych
- Sprawdź strefę czasową w ustawieniach przeglądarki

### Problemy z tokenami
- Wyloguj się i zaloguj ponownie
- Wyczyść localStorage przeglądarki
- Sprawdź czy tokeny nie wygasły