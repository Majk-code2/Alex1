#!/usr/bin/env node

import { spawn, exec } from 'child_process';
import net from 'net';
import { promisify } from 'util';

const execAsync = promisify(exec);

console.log('🎨 Uruchamianie TYLKO serwera frontend (port 5173)...\n');

// Sprawdź czy backend działa na porcie 3002
function checkBackend() {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    
    socket.setTimeout(2000);
    
    socket.on('connect', () => {
      socket.destroy();
      resolve(true);
    });
    
    socket.on('timeout', () => {
      socket.destroy();
      resolve(false);
    });
    
    socket.on('error', () => {
      resolve(false);
    });
    
    socket.connect(3002, '127.0.0.1');
  });
}

// Funkcja do zabijania procesu na porcie 5173
async function killPortProcess(port) {
  try {
    console.log(`🔍 Sprawdzanie czy port ${port} jest zajęty...`);
    
    // Znajdź proces używający portu
    const { stdout } = await execAsync(`lsof -ti:${port}`);
    
    if (stdout.trim()) {
      const pid = stdout.trim();
      console.log(`⚠️  Port ${port} jest zajęty przez proces PID: ${pid}`);
      console.log(`🔄 Zabijanie procesu...`);
      
      await execAsync(`kill -9 ${pid}`);
      console.log(`✅ Proces na porcie ${port} został zakończony`);
      
      // Poczekaj chwilę, żeby port się zwolnił
      await new Promise(resolve => setTimeout(resolve, 1000));
    } else {
      console.log(`✅ Port ${port} jest wolny`);
    }
  } catch (error) {
    // Jeśli lsof nie znajdzie procesu, port jest prawdopodobnie wolny
    if (error.message.includes('No such file or directory') || error.stdout === '') {
      console.log(`✅ Port ${port} jest wolny`);
    } else {
      console.log(`⚠️  Nie udało się sprawdzić portu ${port}:`, error.message);
    }
  }
}

const backendRunning = await checkBackend();

if (!backendRunning) {
  console.warn('⚠️  UWAGA: Backend (port 3002) nie działa!');
  console.warn('📝 Uruchom backend w osobnym terminalu:');
  console.warn('   npm run backend');
  console.warn('');
  console.warn('🤔 Czy chcesz kontynuować uruchamianie frontendu? (y/n)');
  
  // Proste potwierdzenie (w rzeczywistym środowisku można użyć readline)
  console.warn('⏳ Kontynuuję za 5 sekund...');
  await new Promise(resolve => setTimeout(resolve, 5000));
} else {
  console.log('✅ Backend działa na porcie 3002');
}

// Zabij proces na porcie 5173 przed uruchomieniem frontendu
await killPortProcess(5173);

console.log('🎨 Uruchamianie serwera frontend na porcie 5173...');

const frontend = spawn('npm', ['run', 'dev'], {
  stdio: 'inherit',
  shell: true,
  env: process.env
});

frontend.on('error', (err) => {
  console.error('❌ Błąd frontendu:', err.message);
});

frontend.on('close', (code) => {
  if (code !== 0) {
    console.log(`⚠️  Frontend zakończył się z kodem: ${code}`);
  }
});

// Obsługa zamykania
process.on('SIGINT', () => {
  console.log('\n🛑 Zamykanie serwera frontend...');
  frontend.kill('SIGTERM');
  process.exit(0);
});

console.log('\n📋 INSTRUKCJE:');
console.log('✅ Frontend uruchomiony na porcie 5173');
console.log('🌐 Aplikacja dostępna na: http://localhost:5173');
console.log('🔄 Aby zatrzymać frontend, naciśnij Ctrl+C');