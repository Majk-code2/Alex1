# 🔧 INSTRUKCJE KONFIGURACJI ALEX AGENT

## Problem z kasowaniem pliku .env

Plik `.env` może być kasowany przez system. Rozwiązanie: używamy **trwałego pliku konfiguracyjnego**.

## Krok po kroku

### 1. Edytuj plik .env-persistent

```bash
# Otwórz plik w edytorze
nano .env-persistent
# lub
code .env-persistent
```

### 2. Zamień wszystkie placeholder values

**PRZED:**
```env
ANTHROPIC_API_KEY=sk-ant-api-your-key-here
SUPABASE_URL=your-supabase-project-url
```

**PO:**
```env
ANTHROPIC_API_KEY=sk-ant-api-03-TWOJ-PRAWDZIWY-KLUCZ
SUPABASE_URL=https://twoj-projekt.supabase.co
```

### 3. Uruchom konfigurację

```bash
npm run setup-env
```

### 4. Uruchom aplikację

```bash
npm run dev:safe
```

## Gdzie zdobyć klucze API

### ANTHROPIC_API_KEY (WYMAGANE)
1. Idź na https://console.anthropic.com/
2. Zaloguj się lub utwórz konto
3. Przejdź do API Keys
4. Utwórz nowy klucz
5. Skopiuj klucz (zaczyna się od `sk-ant-api-`)

### SUPABASE (OPCJONALNE - dla zapisywania danych)
1. Idź na https://supabase.com/dashboard
2. Utwórz nowy projekt
3. Przejdź do Settings > API
4. Skopiuj:
   - Project URL → `SUPABASE_URL` i `VITE_SUPABASE_URL`
   - anon public key → `VITE_SUPABASE_ANON_KEY`
   - service_role key → `SUPABASE_SERVICE_ROLE_KEY`

### GOOGLE CALENDAR (OPCJONALNE)
1. Idź na https://console.cloud.google.com/
2. Utwórz projekt
3. Włącz Google Calendar API
4. Utwórz OAuth 2.0 credentials
5. Skopiuj Client ID i Client Secret

## Sprawdzanie konfiguracji

```bash
# Sprawdź czy wszystko jest OK
npm run check-env

# Jeśli OK, uruchom aplikację
npm run dev:safe
```

## Rozwiązywanie problemów

### ❌ "Plik .env-persistent zawiera placeholder values"
- Edytuj `.env-persistent` i zamień wszystkie "your-..." na prawdziwe klucze

### ❌ "ANTHROPIC_API_KEY nie jest ustawiony"
- Sprawdź czy klucz w `.env-persistent` jest prawdziwy
- Klucz musi zaczynać się od `sk-ant-api-`

### ❌ "Port 3002 zajęty"
- Uruchom: `npx kill-port 3002`
- Następnie: `npm run dev:safe`

## Dlaczego .env-persistent?

- Plik `.env` może być kasowany przez system
- `.env-persistent` jest chroniony przed kasowaniem
- Automatycznie kopiuje się do `.env` przy każdym uruchomieniu
- Twoje klucze API są bezpieczne i nie znikają

## Bezpieczeństwo

- **NIE** udostępniaj pliku `.env-persistent` nikomu
- **NIE** commituj go do git (jeśli używasz)
- Klucze API traktuj jak hasła - trzymaj w tajemnicy