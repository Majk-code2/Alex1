/*
  # ALEX Agent Database Schema

  1. New Tables
    - `user_profiles`
      - `id` (uuid, primary key)
      - `user_id` (text, unique)
      - `profile_data` (jsonb)
      - `created_at` (timestamp)
      - `updated_at` (timestamp)
    - `conversations`
      - `id` (uuid, primary key)
      - `user_id` (text)
      - `message_id` (text)
      - `role` (text, user/assistant)
      - `content` (text)
      - `metadata` (jsonb)
      - `created_at` (timestamp)

  2. Security
    - Enable RLS on both tables
    - Add policies for public access (simplified for development)

  3. Performance
    - Add indexes for common queries
*/

-- 1. Create tables if they don't exist
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text UNIQUE NOT NULL,
  profile_data jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  message_id text NOT NULL,
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  content text NOT NULL,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- 2. Create indexes if they don't exist
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_conversations_user_id ON conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_conversations_created_at ON conversations(created_at DESC);

-- 3. Enable RLS (safe to run multiple times)
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;

-- 4. Drop existing policies if they exist, then recreate them
DO $$
BEGIN
  -- Drop and recreate user_profiles policies
  DROP POLICY IF EXISTS "Allow all operations on user_profiles" ON user_profiles;
  CREATE POLICY "Allow all operations on user_profiles" 
    ON user_profiles FOR ALL 
    USING (true);

  -- Drop and recreate conversations policies  
  DROP POLICY IF EXISTS "Allow all operations on conversations" ON conversations;
  CREATE POLICY "Allow all operations on conversations" 
    ON conversations FOR ALL 
    USING (true);
END $$;