#!/usr/bin/env node

import { spawn } from 'child_process';
import fs from 'fs';

console.log('🚀 ALEX Quick Start - Prosty launcher');

// Sprawdź .env
if (!fs.existsSync('.env')) {
  console.error('❌ Brak pliku .env!');
  console.error('Skopiuj: cp .env.example .env');
  console.error('Następnie edytuj .env i dodaj swoje klucze API');
  process.exit(1);
}

// Sprawdź zawartość .env
const envContent = fs.readFileSync('.env', 'utf8');
if (envContent.includes('your-') || envContent.includes('sk-ant-api-your-key-here')) {
  console.error('❌ Plik .env zawiera przykładowe wartości!');
  console.error('Edytuj .env i zamień wszystkie "your-..." na prawdziwe klucze');
  process.exit(1);
}

console.log('✅ Plik .env wygląda OK');

// Funkcja uruchamiająca proces
function startProcess(command, args, name) {
  console.log(`🔧 Uruchamiam ${name}...`);
  
  const process = spawn(command, args, {
    stdio: 'inherit',
    shell: true,
    env: { ...process.env }
  });

  process.on('error', (err) => {
    console.error(`❌ Błąd ${name}:`, err.message);
  });

  return process;
}

// Uruchom backend
const backend = startProcess('node', ['server.js'], 'Backend');

// Poczekaj 3 sekundy i uruchom frontend
setTimeout(() => {
  const frontend = startProcess('npm', ['run', 'dev'], 'Frontend');
  
  // Obsługa zamykania
  process.on('SIGINT', () => {
    console.log('\n🛑 Zamykanie...');
    backend.kill();
    frontend.kill();
    process.exit(0);
  });
}, 3000);

console.log('\n📋 Instrukcje:');
console.log('1. Poczekaj aż oba serwery się uruchomią');
console.log('2. Otwórz http://localhost:5173 w przeglądarce');
console.log('3. Aby zatrzymać, naciśnij Ctrl+C');