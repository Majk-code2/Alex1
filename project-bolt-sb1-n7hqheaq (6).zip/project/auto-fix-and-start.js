#!/usr/bin/env node

import { spawn } from 'child_process';
import fs from 'fs';
import net from 'net';
import dotenv from 'dotenv';

console.log('🚀 AUTO-FIX: Naprawiam wszystko i uruchamiam...\n');
console.log('📋 Sprawdzanie wymagań systemowych...');

// Check if required files exist
const requiredFiles = ['.env-persistent', 'server.js', 'package.json'];
for (const file of requiredFiles) {
  if (!fs.existsSync(file)) {
    console.error(`❌ BŁĄD: Brak wymaganego pliku: ${file}`);
    process.exit(1);
  }
}
console.log('✅ Wszystkie wymagane pliki istnieją');
// 1. SPRAWDŹ I NAPRAW .env
console.log('🔧 Krok 1: Sprawdzanie konfiguracji...');

if (!fs.existsSync('.env-persistent')) {
  console.error('❌ Brak pliku .env-persistent!');
  process.exit(1);
}

// Skopiuj .env-persistent do .env
const envContent = fs.readFileSync('.env-persistent', 'utf8');
fs.writeFileSync('.env', envContent);

// Load environment variables into process.env
dotenv.config();

// Sprawdź czy klucz API jest prawdziwy
const hasValidKey = envContent.includes('sk-ant-api03-') && !envContent.includes('your-key-here');
if (!hasValidKey) {
  console.error('❌ BŁĄD: Brak prawdziwego klucza API w .env-persistent');
  console.error('📝 Edytuj .env-persistent i wstaw prawdziwy klucz z https://console.anthropic.com/');
  process.exit(1);
}

console.log('✅ Konfiguracja OK');

// 2. ZABIJ WSZYSTKIE PROCESY NA PORTACH
console.log('🔧 Krok 2: Czyszczenie portów...');

async function killPort(port) {
  return new Promise((resolve) => {
    console.log(`🔄 Czyszczenie portu ${port}...`);
    // Try npx kill-port first, fallback to native methods
    const kill = spawn('npx', ['kill-port', port], { stdio: 'pipe', shell: true });
    
    let resolved = false;
    
    kill.on('close', (code) => {
      if (!resolved) {
        resolved = true;
        if (code === 0) {
          console.log(`✅ Port ${port} cleared`);
        } else {
          console.log(`⚠️ kill-port failed for ${port}, trying fallback...`);
          // Fallback method for different platforms
          const fallbackKill = process.platform === 'win32' 
            ? spawn('cmd', ['/c', `for /f "tokens=5" %a in ('netstat -aon ^| find ":${port}"') do taskkill /f /pid %a`], { stdio: 'pipe', shell: true })
            : spawn('sh', ['-c', `lsof -ti:${port} | xargs kill -9 2>/dev/null || true`], { stdio: 'pipe', shell: true });
          
          fallbackKill.on('close', () => {
            console.log(`✅ Fallback port clear attempted for ${port}`);
            resolve();
          });
          fallbackKill.on('error', () => resolve());
          return;
        }
        resolve();
      }
    });
    
    kill.on('error', (err) => {
      if (!resolved) {
        resolved = true;
        console.log(`⚠️ npx kill-port failed: ${err.message}, trying fallback...`);
        // Fallback method
        const fallbackKill = process.platform === 'win32' 
          ? spawn('cmd', ['/c', `for /f "tokens=5" %a in ('netstat -aon ^| find ":${port}"') do taskkill /f /pid %a`], { stdio: 'pipe', shell: true })
          : spawn('sh', ['-c', `lsof -ti:${port} | xargs kill -9 2>/dev/null || true`], { stdio: 'pipe', shell: true });
        
        fallbackKill.on('close', () => {
          console.log(`✅ Fallback port clear attempted for ${port}`);
          resolve();
        });
        fallbackKill.on('error', () => resolve());
      }
    });
    
    // Add timeout to prevent hanging
    setTimeout(() => {
      if (!resolved) {
        resolved = true;
        console.log(`⏰ Timeout clearing port ${port} - continuing anyway`);
        resolve();
      }
    }, 10000);
  });
}

await killPort(3002);
await killPort(5173);
await new Promise(resolve => setTimeout(resolve, 2000));

console.log('✅ Porty wyczyszczone');

// 3. URUCHOM BACKEND Z RETRY
console.log('🔧 Krok 3: Uruchamianie backend...');

let backendReady = false;
let backendProcess = null;

function startBackend() {
  return new Promise((resolve, reject) => {
    console.log('🔄 Starting backend server...');
    backendProcess = spawn('node', ['server.js'], {
      stdio: 'pipe',
      env: process.env,
      shell: true
    });

    let output = '';
    let hasStarted = false;
    
    backendProcess.stdout.on('data', (data) => {
      const text = data.toString();
      output += text;
      console.log('Backend:', text.trim());
      
      if ((text.includes('SERWER URUCHOMIONY POMYŚLNIE') || text.includes('listening on')) && !hasStarted) {
        hasStarted = true;
        backendReady = true;
        console.log('✅ Backend server started successfully');
        resolve();
      }
    });

    backendProcess.stderr.on('data', (data) => {
      const errorText = data.toString();
      console.error('Backend Error:', errorText);
      
      // Check for common startup errors
      if (errorText.includes('EADDRINUSE')) {
        console.error('❌ Port 3002 is already in use. Trying to kill processes...');
      } else if (errorText.includes('ANTHROPIC_API_KEY')) {
        console.error('❌ Missing or invalid ANTHROPIC_API_KEY in .env-persistent');
      }
    });

    backendProcess.on('close', (code) => {
      if (code !== 0 && !hasStarted) {
        console.error(`❌ Backend process exited with code ${code}`);
        reject(new Error(`Backend failed with code ${code}. Check the error messages above.`));
      }
    });

    backendProcess.on('error', (error) => {
      console.error('❌ Backend process error:', error.message);
      if (!hasStarted) {
        reject(error);
      }
    });

    // Timeout po 15 sekundach
    setTimeout(() => {
      if (!hasStarted) {
        console.error('❌ Backend startup timeout after 15 seconds');
        reject(new Error('Backend startup timeout - check configuration and logs above'));
      }
    }, 15000);
  });
}

try {
  await startBackend();
  console.log('✅ Backend uruchomiony');
} catch (error) {
  console.error('❌ Backend nie uruchomił się:', error.message);
  console.error('\n🔧 ROZWIĄZYWANIE PROBLEMÓW:');
  console.error('1. Sprawdź czy .env-persistent zawiera prawidłowy ANTHROPIC_API_KEY');
  console.error('2. Sprawdź czy port 3002 nie jest zajęty: lsof -i :3002');
  console.error('3. Sprawdź logi błędów powyżej');
  console.error('4. Spróbuj uruchomić backend ręcznie: npm run backend');
  process.exit(1);
}

// 4. SPRAWDŹ CZY BACKEND ODPOWIADA
console.log('🔧 Krok 4: Test API...');

async function testAPI() {
  for (let i = 0; i < 5; i++) {
    try {
      // Sprawdzenie klucza API przed testem
      if (i === 0) {
        console.log('🔑 Sprawdzam klucz API...');
        console.log('Klucz Anthropic:', process.env.ANTHROPIC_API_KEY ? 'Ustawiony' : 'BRAK');
        if (process.env.ANTHROPIC_API_KEY) {
          console.log('Długość klucza:', process.env.ANTHROPIC_API_KEY.length);
          console.log('Format klucza:', process.env.ANTHROPIC_API_KEY.substring(0, 10) + '...');
        }
      }
      
      console.log(`🔄 Test API - próba ${i + 1}/5...`);
      const response = await fetch('http://localhost:3002/api/health');
      
      if (!response.ok) {
        console.log(`❌ HTTP ${response.status}: ${response.statusText}`);
        throw new Error(`HTTP ${response.status}`);
      }
      
      const data = await response.json();
      console.log('📡 API Response:', data.status, data.message ? `- ${data.message}` : '');
      
      if (data.status === 'success' || data.status === 'error') {
        // Akceptuj odpowiedź nawet jeśli Anthropic API ma problemy
        console.log('✅ API działa');
        if (data.status === 'error' && data.message && data.message.includes('Connection error')) {
          console.warn('⚠️ Ostrzeżenie: Problem z połączeniem do Anthropic API');
          console.warn('📋 To może być problem z siecią - aplikacja będzie działać, ale chat może nie działać');
          console.warn('🔧 Sprawdź połączenie internetowe i https://status.anthropic.com/');
        }
        return true;
      }
    } catch (error) {
      console.log(`❌ Próba ${i + 1}/5 nieudana:`, error.message);
      await new Promise(resolve => setTimeout(resolve, 2000));
    }
  }
  return false;
}

const apiWorking = await testAPI();
if (!apiWorking) {
  console.error('❌ API nie odpowiada');
  if (backendProcess) backendProcess.kill();
  process.exit(1);
}

// 5. URUCHOM FRONTEND
console.log('🔧 Krok 5: Uruchamianie frontend...');

const frontendProcess = spawn('npm', ['run', 'dev'], {
  stdio: 'inherit',
  env: process.env,
  shell: true
});

frontendProcess.on('error', (err) => {
  console.error('❌ Błąd frontendu:', err);
});

// 6. OBSŁUGA ZAMYKANIA
process.on('SIGINT', () => {
  console.log('\n🛑 Zamykanie...');
  if (backendProcess) backendProcess.kill();
  if (frontendProcess) frontendProcess.kill();
  process.exit(0);
});

console.log('\n🎉 GOTOWE!');
console.log('📍 Backend: http://localhost:3002');
console.log('📍 Frontend: http://localhost:5173');
console.log('🔄 Aby zatrzymać: Ctrl+C');