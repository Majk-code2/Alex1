#!/usr/bin/env node

import dotenv from 'dotenv';
import Anthropic from '@anthropic-ai/sdk';

// Load environment variables
dotenv.config();

console.log('🔍 Sprawdzanie klucza API Anthropic...');

const apiKey = process.env.ANTHROPIC_API_KEY;

if (!apiKey) {
  console.error('❌ ANTHROPIC_API_KEY nie jest ustawiony w pliku .env');
  console.error('📝 Sprawdź plik .env-persistent i upewnij się, że zawiera prawidłowy klucz');
  process.exit(1);
}

if (apiKey.includes('your-') || apiKey === 'sk-ant-api03-your-key-here') {
  console.error('❌ ANTHROPIC_API_KEY zawiera placeholder - nie został zastąpiony prawdziwym kluczem');
  console.error('📝 Edytuj plik .env-persistent i wstaw prawdziwy klucz z https://console.anthropic.com/');
  process.exit(1);
}

if (!apiKey.startsWith('sk-ant-api')) {
  console.error('❌ ANTHROPIC_API_KEY ma niepoprawny format');
  console.error('📝 Klucz powinien zaczynać się od "sk-ant-api"');
  process.exit(1);
}

console.log('✅ Format klucza API wygląda poprawnie');
console.log('🧪 Testowanie połączenia z Anthropic API...');

try {
  const anthropic = new Anthropic({
    apiKey: apiKey,
  });

  let response;
  try {
    response = await anthropic.messages.create({
      model: "claude-sonnet-4-20250514",
      max_tokens: 1,
      messages: [
        {
          "role": "user", 
          "content": "Hi"
        }
      ]
    });
  } catch (connectionError) {
    if (connectionError.message && connectionError.message.includes('Connection error')) {
      console.error('❌ Błąd połączenia z Anthropic API:');
      console.error('🌐 Problem z połączeniem sieciowym do api.anthropic.com');
      console.error('📋 Możliwe przyczyny:');
      console.error('   • Brak połączenia z internetem');
      console.error('   • Firewall blokuje połączenia do api.anthropic.com');
      console.error('   • Proxy lub sieć korporacyjna blokuje dostęp');
      console.error('   • Tymczasowe problemy z serwerami Anthropic');
      console.error('   • Problem z konfiguracją DNS');
      console.error('');
      console.error('🔧 Rozwiązania:');
      console.error('   • Sprawdź połączenie internetowe');
      console.error('   • Skontaktuj się z administratorem sieci');
      console.error('   • Spróbuj ponownie za kilka minut');
      console.error('   • Sprawdź status API na https://status.anthropic.com/');
      console.error('   • Sprawdź konfigurację firewall/proxy');
      process.exit(1);
    } else if (connectionError.code === 'UND_ERR_SOCKET') {
      console.error('❌ Błąd socket podczas połączenia z Anthropic API:');
      console.error('🌐 Problem z połączeniem na poziomie socket');
      console.error('🔧 Rozwiązania:');
      console.error('   • Sprawdź połączenie internetowe');
      console.error('   • Sprawdź konfigurację firewall');
      console.error('   • Spróbuj ponownie za chwilę');
      process.exit(1);
    }
    throw connectionError;
  }

  console.log('✅ Połączenie z Anthropic API działa poprawnie!');
  console.log('📊 Model:', response.model);
  console.log('📊 Użyte tokeny:', response.usage);
  
} catch (error) {
  console.error('❌ Błąd połączenia z Anthropic API:');
  
  if (error.message && error.message.includes('Connection error')) {
    console.error('🌐 Błąd połączenia sieciowego z api.anthropic.com');
    console.error('📋 Możliwe przyczyny:');
    console.error('   • Brak połączenia z internetem');
    console.error('   • Firewall blokuje połączenia do api.anthropic.com');
    console.error('   • Proxy lub sieć korporacyjna blokuje dostęp');
    console.error('   • Tymczasowe problemy z serwerami Anthropic');
    console.error('');
    console.error('🔧 Rozwiązania:');
    console.error('   • Sprawdź połączenie internetowe');
    console.error('   • Skontaktuj się z administratorem sieci');
    console.error('   • Spróbuj ponownie za kilka minut');
    console.error('   • Sprawdź status API na https://status.anthropic.com/');
  } else if (error.status === 401) {
    console.error('🔑 Nieprawidłowy klucz API - sprawdź czy klucz jest aktywny');
    console.error('📝 Przejdź do https://console.anthropic.com/ i wygeneruj nowy klucz');
  } else if (error.status === 429) {
    console.error('⏱️  Przekroczono limit zapytań - spróbuj ponownie za chwilę');
  } else if (error.status === 400) {
    console.error('📝 Nieprawidłowe zapytanie do API');
  } else {
    console.error('🔍 Szczegóły błędu:', error.message);
    if (error.code) {
      console.error('🔍 Kod błędu:', error.code);
    }
  }
  
  process.exit(1);
}