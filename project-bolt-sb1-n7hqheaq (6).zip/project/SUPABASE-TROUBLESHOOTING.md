# 🔧 Rozwiązywanie problemów z Supabase

## Problem: "Serwer odrzucił połączenie"

### Szybka diagnostyka

```bash
# Sprawdź status Supabase
npm run check-supabase
```

### Najczęstsze przyczyny i rozwiązania

#### 1. 🚫 Projekt wstrzymany/nieaktywny

**Objawy:**
- "Connection refused"
- "Server not found"
- HTTP 404

**Rozwiązanie:**
1. Otwórz https://supabase.com/dashboard
2. Sprawdź status projektu `syislcrmxopvhzcfalft`
3. Jeśli wstrzymany - aktywuj lub utwórz nowy projekt

#### 2. 🔑 Niepoprawne klucze API

**Objawy:**
- HTTP 401 Unauthorized
- "Invalid API key"

**Rozwiązanie:**
1. Przejdź do Supabase Dashboard > Settings > API
2. Skopiuj nowe klucze:
   - Project URL → `VITE_SUPABASE_URL`
   - anon public → `VITE_SUPABASE_ANON_KEY`
3. Edytuj `.env-persistent`:
   ```env
   VITE_SUPABASE_URL=https://nowy-projekt.supabase.co
   VITE_SUPABASE_ANON_KEY=nowy-anon-key
   ```
4. Uruchom: `npm run setup-env && npm run fix`

#### 3. 🌐 Problem z siecią

**Objawy:**
- Timeout errors
- "Failed to fetch"

**Rozwiązanie:**
1. Sprawdź połączenie internetowe
2. Sprawdź firewall/proxy
3. Sprawdź status: https://status.supabase.com/

#### 4. 💳 Przekroczenie limitów

**Objawy:**
- HTTP 429 Too Many Requests
- Projekt automatycznie wstrzymany

**Rozwiązanie:**
1. Sprawdź usage w Supabase Dashboard
2. Upgrade plan lub poczekaj do resetu limitów
3. Optymalizuj zapytania

### Krok po kroku - Nowy projekt

Jeśli obecny projekt nie działa, utwórz nowy:

#### 1. Utwórz nowy projekt Supabase

1. Przejdź do https://supabase.com/dashboard
2. Kliknij "New Project"
3. Wybierz organizację
4. Nazwa: `alex-agent-v2`
5. Hasło bazy: `[wygeneruj silne hasło]`
6. Region: `Central EU (Frankfurt)`
7. Kliknij "Create new project"

#### 2. Skopiuj nowe klucze

Po utworzeniu projektu:
1. Przejdź do Settings > API
2. Skopiuj:
   - Project URL
   - anon public key
   - service_role key (dla backendu)

#### 3. Aktualizuj konfigurację

Edytuj `.env-persistent`:
```env
# Nowy projekt Supabase
VITE_SUPABASE_URL=https://nowy-projekt.supabase.co
VITE_SUPABASE_ANON_KEY=nowy-anon-key
SUPABASE_SERVICE_ROLE_KEY=nowy-service-role-key
```

#### 4. Utwórz tabele

```sql
-- Wykonaj w SQL Editor w Supabase Dashboard

-- Tabela profili użytkowników
CREATE TABLE IF NOT EXISTS user_profiles (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text UNIQUE NOT NULL,
  profile_data jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Tabela rozmów
CREATE TABLE IF NOT EXISTS conversations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id text NOT NULL,
  message_id text NOT NULL,
  role text NOT NULL CHECK (role IN ('user', 'assistant')),
  content text NOT NULL,
  metadata jsonb DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

-- Indeksy
CREATE INDEX IF NOT EXISTS idx_user_profiles_user_id ON user_profiles(user_id);
CREATE INDEX IF NOT EXISTS idx_conversations_user_id ON conversations(user_id);
CREATE INDEX IF NOT EXISTS idx_conversations_created_at ON conversations(created_at DESC);

-- RLS
ALTER TABLE user_profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE conversations ENABLE ROW LEVEL SECURITY;

-- Polityki (permissive dla development)
CREATE POLICY "Allow all operations on user_profiles" 
  ON user_profiles FOR ALL USING (true);

CREATE POLICY "Allow all operations on conversations" 
  ON conversations FOR ALL USING (true);
```

#### 5. Konfiguruj Google OAuth

1. W Supabase Dashboard > Authentication > Providers
2. Włącz Google provider
3. Dodaj Client ID i Secret z Google Cloud Console
4. Redirect URL: `https://nowy-projekt.supabase.co/auth/v1/callback`

#### 6. Test i uruchomienie

```bash
# Test nowej konfiguracji
npm run check-supabase

# Jeśli OK, uruchom aplikację
npm run fix
```

### Tryb offline (bez Supabase)

Jeśli Supabase nie działa, aplikacja automatycznie przełączy się na tryb offline:

✅ **Działa:**
- Chat z ALEX
- Wszystkie funkcje AI
- Lokalne przechowywanie w przeglądarce

❌ **Nie działa:**
- Logowanie przez Google
- Synchronizacja między urządzeniami
- Trwałe przechowywanie danych

**Aby używać w trybie offline:**
1. Kliknij "Kontynuuj jako gość"
2. Wszystkie funkcje ALEX będą dostępne
3. Dane będą przechowywane lokalnie

### Monitoring i alerty

Aplikacja ma wbudowany monitoring:
- Automatyczne sprawdzanie stanu Supabase co 30 sekund
- Alerty o problemach z połączeniem
- Graceful fallback na tryb offline

### Kontakt z supportem

Jeśli problemy się powtarzają:
1. Sprawdź logi w konsoli przeglądarki (F12)
2. Sprawdź status na https://status.supabase.com/
3. Skontaktuj się z supportem Supabase przez dashboard