# 🔧 Debug Netlify - Krok po kroku

## Problem: Aplikacja na Netlify nie łączy się z API

### 1. Sprawdź zmienne środowiskowe na Netlify

**KRYTYCZNE:** Przejdź do https://app.netlify.com/sites/rad-griffin-a37e97/settings/deploys

W sekcji **Environment variables** MUSI być:

```
ANTHROPIC_API_KEY = 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
```

### 2. Test endpointów

**Health Check:**
https://rad-griffin-a37e97.netlify.app/.netlify/functions/health

**Powinno zwrócić:**
```json
{
  "status": "success",
  "message": "Netlify Functions backend is running",
  "anthropic_configured": true
}
```

### 3. Jeśli health check nie działa:

1. **Sprawdź czy zmienna jest dodana:**
   - Idź do Netlify Dashboard
   - Site settings → Environment variables
   - Sprawdź czy `ANTHROPIC_API_KEY` jest na liście

2. **Jeśli brak zmiennej - dodaj:**
   - Kliknij "Add variable"
   - Key: `ANTHROPIC_API_KEY`
   - Value: `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`
   - Kliknij "Create variable"

3. **Redeploy:**
   - Przejdź do "Deploys" tab
   - Kliknij "Trigger deploy" → "Deploy site"
   - Poczekaj 2-3 minuty

### 4. Test po redeploy:

1. **Health check:** https://rad-griffin-a37e97.netlify.app/.netlify/functions/health
2. **Główna aplikacja:** https://rad-griffin-a37e97.netlify.app/
3. **Napisz wiadomość do ALEX**

### 5. Debug w przeglądarce:

1. Otwórz https://rad-griffin-a37e97.netlify.app/
2. Naciśnij F12 (Developer Tools)
3. Przejdź do zakładki "Console"
4. Napisz wiadomość do ALEX
5. Sprawdź czy są błędy w konsoli

### 6. Możliwe błędy i rozwiązania:

**Błąd:** `Failed to fetch`
**Rozwiązanie:** Brak zmiennej środowiskowej - dodaj i redeploy

**Błąd:** `ANTHROPIC_API_KEY nie jest ustawiony`
**Rozwiązanie:** Zmienna nie została poprawnie dodana - sprawdź pisownię

**Błąd:** `HTTP 401`
**Rozwiązanie:** Nieprawidłowy klucz API - sprawdź czy skopiowałeś cały klucz

### 7. Ostateczny test:

Po wykonaniu wszystkich kroków:
- Health check powinien zwracać `{"status":"success"}`
- Aplikacja powinna odpowiadać na wiadomości
- Konsola przeglądarki nie powinna pokazywać błędów

### 8. Jeśli nadal nie działa:

Przetestuj lokalnie:
```bash
npm run fix
```

Jeśli lokalnie działa, problem jest z konfiguracją Netlify.