#!/usr/bin/env node

import fs from 'fs';
import path from 'path';

console.log('🔧 Konfiguracja zmiennych środowiskowych...\n');

const persistentEnvPath = '.env-persistent';
const envPath = '.env';

// Sprawdź czy istnieje plik persistent
if (!fs.existsSync(persistentEnvPath)) {
  console.error('❌ Brak pliku .env-persistent!');
  console.error('Plik powinien zostać utworzony automatycznie.');
  process.exit(1);
}

// Przeczytaj zawartość
let envContent = fs.readFileSync(persistentEnvPath, 'utf8');

// Sprawdź czy zawiera placeholder values
const hasPlaceholders = envContent.includes('your-') || envContent.includes('sk-ant-api-your-key-here');

if (hasPlaceholders) {
  console.log('⚠️  UWAGA: Wykryto wartości placeholder w .env-persistent');
  console.log('\n📝 INSTRUKCJE KONFIGURACJI:');
  console.log('1. Edytuj plik .env-persistent');
  console.log('2. Zamień wszystkie "your-..." na prawdziwe klucze API');
  console.log('3. Uruchom ponownie: npm run setup-env');
  console.log('\n🔑 GDZIE ZDOBYĆ KLUCZE:');
  console.log('- ANTHROPIC_API_KEY: https://console.anthropic.com/');
  console.log('- SUPABASE: https://supabase.com/dashboard');
  console.log('- GOOGLE: https://console.cloud.google.com/');
  
  // Skopiuj mimo wszystko, żeby plik .env istniał
  fs.writeFileSync(envPath, envContent);
  console.log('\n✅ Plik .env został utworzony (z placeholder values)');
  console.log('❌ Aplikacja nie uruchomi się dopóki nie uzupełnisz prawdziwych kluczy!');
  process.exit(1);
}

// Usuń komentarze z instrukcjami przed skopiowaniem
const cleanContent = envContent
  .split('\n')
  .filter(line => !line.startsWith('# INSTRUKCJE:') && !line.startsWith('# 1.') && !line.startsWith('# 2.') && !line.startsWith('# 3.'))
  .join('\n');

// Skopiuj do .env
fs.writeFileSync(envPath, cleanContent);

console.log('✅ Plik .env został utworzony z .env-persistent');
console.log('✅ Wszystkie klucze API są skonfigurowane');
console.log('\n🚀 Możesz teraz uruchomić aplikację:');
console.log('npm run dev:safe');