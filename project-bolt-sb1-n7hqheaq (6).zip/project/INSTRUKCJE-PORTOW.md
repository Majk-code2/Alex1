# 🚀 Instrukcje kontroli portów - ALEX Agent

## Ręczne kontrolowanie portów

Teraz masz pełną kontrolę nad uruchamianiem portów 3002 i 5173!

### Opcja 1: Uruchom wszystko razem (jak wcześniej)
```bash
npm run dev:full
```

### Opcja 2: Kontrola ręczna (NOWA OPCJA)

#### Krok 1: Uruchom backend (port 3002)
```bash
npm run backend
```
✅ Backend uruchomi się na porcie 3002
🔧 API będzie dostępne na http://localhost:3002

#### Krok 2: Uruchom frontend (port 5173) - W NOWYM TERMINALU
```bash
npm run frontend
```
✅ Frontend uruchomi się na porcie 5173
🌐 Aplikacja będzie dostępna na http://localhost:5173

### Opcja 3: Tylko frontend (jeśli backend już działa)
```bash
npm run dev
```

## Zalety ręcznej kontroli

### ✅ Elastyczność
- Możesz restartować tylko frontend bez zatrzymywania backendu
- Możesz restartować tylko backend bez zatrzymywania frontendu
- Łatwiejsze debugowanie - osobne logi dla każdego serwera

### ✅ Stabilność
- Jeśli frontend crashuje, backend dalej działa
- Jeśli backend crashuje, możesz go zrestartować bez wpływu na frontend

### ✅ Rozwój
- Możesz pracować nad frontendem gdy backend jest stabilny
- Możesz testować API bez uruchamiania frontendu

## Przykładowy workflow

### Standardowe uruchomienie:
```bash
# Terminal 1
npm run backend

# Terminal 2 (po uruchomieniu backendu)
npm run frontend
```

### Restart tylko frontendu:
```bash
# W terminalu z frontendem
Ctrl+C
npm run frontend
```

### Restart tylko backendu:
```bash
# W terminalu z backendem
Ctrl+C
npm run backend
```

## Sprawdzanie statusu

### Sprawdź czy backend działa:
```bash
curl http://localhost:3002/api/health
```

### Sprawdź czy frontend działa:
Otwórz http://localhost:5173 w przeglądarce

## Rozwiązywanie problemów

### Backend nie startuje:
1. Sprawdź klucz API: `node check-api-key.js`
2. Sprawdź port: `lsof -i :3002`
3. Zabij proces: `npx kill-port 3002`

### Frontend nie łączy się z backendem:
1. Sprawdź czy backend działa: `curl http://localhost:3002/api/health`
2. Sprawdź proxy w vite.config.ts
3. Sprawdź czy oba serwery są na localhost

### Port 5173 zajęty:
```bash
npx kill-port 5173
npm run frontend
```

### Port 3002 zajęty:
```bash
npx kill-port 3002
npm run backend
```

## Komendy szybkie

```bash
# Wszystko razem
npm run dev:full

# Tylko backend
npm run backend

# Tylko frontend  
npm run frontend

# Sprawdź API
node check-api-key.js

# Zabij porty
npx kill-port 3002
npx kill-port 5173
```

Teraz masz pełną kontrolę nad portami! 🎯