#!/usr/bin/env node

import dotenv from 'dotenv';

dotenv.config();

console.log('🔍 SPRAWDZANIE STATUSU SUPABASE...\n');

const supabaseUrl = process.env.VITE_SUPABASE_URL;
const supabaseKey = process.env.VITE_SUPABASE_ANON_KEY;

console.log('📋 Konfiguracja:');
console.log('URL:', supabaseUrl || 'BRAK');
console.log('Key:', supabaseKey ? `${supabaseKey.substring(0, 20)}...` : 'BRAK');

if (!supabaseUrl || !supabaseKey) {
  console.error('\n❌ BŁĄD: Brak zmiennych Supabase w .env');
  console.error('\n📝 INSTRUKCJE:');
  console.error('1. Sprawdź czy .env-persistent zawiera:');
  console.error('   VITE_SUPABASE_URL=https://twoj-projekt.supabase.co');
  console.error('   VITE_SUPABASE_ANON_KEY=twoj-anon-key');
  console.error('2. Uruchom: npm run setup-env');
  process.exit(1);
}

// Sprawdź czy to nie są placeholder values
if (supabaseUrl.includes('your-') || supabaseKey.includes('your-')) {
  console.error('\n❌ BŁĄD: Zmienne zawierają placeholder values');
  console.error('Edytuj .env-persistent i wstaw prawdziwe wartości z Supabase Dashboard');
  process.exit(1);
}

console.log('\n🌐 Test 1: Sprawdzanie dostępności serwera...');
try {
  const response = await fetch(supabaseUrl);
  console.log(`Status: ${response.status} ${response.statusText}`);
  
  if (response.status === 200) {
    console.log('✅ Serwer Supabase odpowiada');
  } else {
    console.log('⚠️  Serwer odpowiada ale z błędem');
  }
} catch (error) {
  console.log('❌ Błąd połączenia:', error.message);
  console.log('\n🔧 Możliwe przyczyny:');
  console.log('- Brak połączenia z internetem');
  console.log('- Projekt Supabase wstrzymany');
  console.log('- Niepoprawny URL projektu');
  console.log('- Firewall blokuje połączenie');
}

console.log('\n🔑 Test 2: Sprawdzanie API endpoint...');
try {
  const response = await fetch(`${supabaseUrl}/rest/v1/`, {
    headers: {
      'apikey': supabaseKey,
      'Authorization': `Bearer ${supabaseKey}`
    }
  });
  
  console.log(`Status: ${response.status} ${response.statusText}`);
  
  if (response.status === 200) {
    console.log('✅ API endpoint działa poprawnie');
  } else if (response.status === 401) {
    console.log('❌ Nieprawidłowy klucz API');
  } else if (response.status === 404) {
    console.log('❌ Projekt nie został znaleziony');
  } else {
    console.log('⚠️  API endpoint ma problemy');
  }
} catch (error) {
  console.log('❌ Błąd API:', error.message);
}

console.log('\n🔐 Test 3: Sprawdzanie auth endpoint...');
try {
  const response = await fetch(`${supabaseUrl}/auth/v1/settings`, {
    headers: {
      'apikey': supabaseKey,
      'Authorization': `Bearer ${supabaseKey}`
    }
  });
  
  console.log(`Status: ${response.status} ${response.statusText}`);
  
  if (response.status === 200) {
    const data = await response.json();
    console.log('✅ Auth endpoint działa');
    console.log('Dostępni providerzy:', Object.keys(data.external || {}));
  } else {
    console.log('⚠️  Auth endpoint ma problemy');
  }
} catch (error) {
  console.log('❌ Błąd auth:', error.message);
}

console.log('\n📊 PODSUMOWANIE:');
console.log('1. Sprawdź czy wszystkie testy przeszły pomyślnie');
console.log('2. Jeśli są błędy, sprawdź:');
console.log('   - Status projektu na https://supabase.com/dashboard');
console.log('   - Czy projekt nie jest wstrzymany');
console.log('   - Czy klucze API są aktualne');
console.log('   - Status serwisu na https://status.supabase.com/');
console.log('\n3. Jeśli wszystko OK, uruchom aplikację: npm run fix');