# 🚨 NAPRAW 404 na Netlify

## Problem: "404 - Page not found"

Netlify nie może znaleźć strony, co oznacza problem z deploymentem.

## ✅ Rozwiązanie krok po kroku:

### 1. **Sprawdź status deployment**
1. Przejdź do: https://app.netlify.com/sites/rad-griffin-a37e97/deploys
2. Sprawdź czy ostatni deploy ma status **"Published"** (zielony)
3. Jeśli czerwony - kliknij na niego i sprawdź logi błędów

### 2. **Dodaj zmienne środowiskowe (KRYTYCZNE!)**
1. Przejdź do: https://app.netlify.com/sites/rad-griffin-a37e97/settings/deploys
2. Przewiń do **"Environment variables"**
3. Kliknij **"Add variable"**
4. Dodaj:
   - **Key:** `ANTHROPIC_API_KEY`
   - **Value:** `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`

### 3. **Trigger nowy deployment**
1. Przejdź do **"Deploys"** tab
2. Kliknij **"Trigger deploy"** → **"Deploy site"**
3. Poczekaj 2-3 minuty na zakończenie

### 4. **Sprawdź czy build się udał**
Po deployment sprawdź:
- Status powinien być **"Published"** (zielony)
- Brak błędów w logach

### 5. **Test endpointów**

**Health Check:**
https://rad-griffin-a37e97.netlify.app/.netlify/functions/health

**Główna strona:**
https://rad-griffin-a37e97.netlify.app/

### 6. **Jeśli nadal 404:**

**Opcja A: Sprawdź build command**
1. W ustawieniach Netlify sprawdź czy:
   - **Build command:** `npm run build`
   - **Publish directory:** `dist`

**Opcja B: Manual deploy**
1. Lokalnie uruchom: `npm run build`
2. Folder `dist` przeciągnij na Netlify dashboard

### 7. **Debug w czasie rzeczywistym:**

Otwórz: https://rad-griffin-a37e97.netlify.app/
- Jeśli widzisz aplikację ALEX = ✅ Działa!
- Jeśli 404 = ❌ Problem z deploymentem

### 8. **Ostateczny test:**

Po naprawie:
1. Otwórz aplikację
2. Napisz "hej" do ALEX
3. Powinien odpowiedzieć! 🎉

## 🆘 Jeśli nic nie pomaga:

Przetestuj lokalnie:
```bash
npm run fix
```

Jeśli lokalnie działa = problem z Netlify
Jeśli lokalnie nie działa = problem z kodem