# Przewodnik Deweloperski - Stabilny Serwer

## Problem z znikającym portem 5173

### Przyczyny:
1. **Błędy kompilacji TypeScript** - crashują serwer Vite
2. **Problemy z HMR (Hot Module Replacement)** - zbyt częste zmiany
3. **Konflikty portów** - inne procesy zajmują port 5173
4. **Błędy w kodzie** - szczególnie w importach/eksportach
5. **Problemy z proxy** - błędy połączenia z backendem

## Rozwiązania:

### 1. Użyj stabilnego trybu deweloperskiego:
```bash
# Zamiast npm run dev
npm run dev:safe
```

### 2. Sprawdź czy port jest wolny:
```bash
# Sprawdź co używa portu 5173
lsof -i :5173

# Zabij proces na porcie 5173
npx kill-port 5173
```

### 3. Ręczny restart z wymuszeniem:
```bash
npm run dev:stable
```

### 4. Monitor z automatycznym restartem:
```bash
npm run dev:monitor
```

## Najlepsze praktyki:

### ✅ DO:
- Zapisuj pliki pojedynczo, nie wszystkie naraz
- Sprawdzaj błędy TypeScript przed zapisaniem (`Ctrl+Shift+P` → "TypeScript: Check")
- Używaj `npm run dev:safe` zamiast `npm run dev`
- Restartuj serwer po dużych zmianach w konfiguracji

### ❌ DON'T:
- Nie zapisuj wielu plików jednocześnie
- Nie ignoruj błędów TypeScript
- Nie zmieniaj konfiguracji Vite podczas działania serwera
- Nie używaj `Ctrl+C` do zatrzymania - użyj `q` w terminalu

## Debugowanie:

### Sprawdź logi:
```bash
# Terminal 1: Backend
npm run server

# Terminal 2: Frontend z logami
npm run dev:stable
```

### Wyczyść cache:
```bash
# Wyczyść cache Vite
rm -rf node_modules/.vite
rm -rf dist

# Reinstaluj zależności
npm install
```

### Sprawdź konfigurację:
1. Upewnij się że `.env` jest poprawny
2. Sprawdź czy wszystkie importy są poprawne
3. Zweryfikuj konfigurację TypeScript

## Komendy ratunkowe:

```bash
# Kompletny reset
npm run dev:safe

# Jeśli nic nie działa
npx kill-port 5173 && npx kill-port 3002 && npm run dev:safe

# Sprawdź status portów
netstat -tulpn | grep :5173
netstat -tulpn | grep :3002
```

## Monitoring w czasie rzeczywistym:

Monitor automatycznie:
- Restartuje Vite gdy spadnie
- Zabija procesy blokujące porty
- Loguje wszystkie błędy
- Resetuje licznik restartów co 5 minut

Użyj: `npm run dev:safe` dla najlepszej stabilności.